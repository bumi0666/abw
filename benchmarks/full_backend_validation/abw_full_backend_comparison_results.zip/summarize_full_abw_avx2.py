from pathlib import Path
import json,statistics as st,math,csv,hashlib,zipfile,shutil
w=Path(__file__).resolve().parent;root=w.parent.parent;o=root/'outputs/abw_full_backend_comparison'
s=json.loads((o/'full_summary.json').read_text());p=json.loads((o/'protocol.json').read_text());done=json.loads((o/'completion.json').read_text());assert done['status']=='complete'
rows=s['inputs'];profiles=[json.loads(l) for l in (o/'frontend_profile.jsonl').read_text().splitlines()];assert len(profiles)==27
profile_rows=[]
for x in profiles:
 rr=x['result']['runs'];r=dict(name=x['name'],n=x['n'])
 for field in rr[0]:
  if field!='repeat':r[field]=st.median(t[field] for t in rr)
 r['sample_total_ms']=st.median(t['sample_allocation_ms']+t['sample_frequency_ms'] for t in rr)
 r['other_choose_ms']=st.median(t['choose_total_ms']-sum(t[f] for f in ['probe_ms','sample_allocation_ms','sample_frequency_ms','scan_ms','entropy_ms']) for t in rr)
 r['instrumented_over_normal']=st.median(t['instrumented_front_ms']/t['normal_front_ms'] for t in rr)
 profile_rows.append(r)
with (o/'frontend_phase_costs.csv').open('w',newline='') as f:wr=csv.DictWriter(f,fieldnames=list(profile_rows[0]));wr.writeheader();wr.writerows(profile_rows)
totals={f:sum(x[f] for x in profile_rows) for f in ['probe_ms','sample_allocation_ms','sample_frequency_ms','scan_ms','entropy_ms','other_choose_ms','count_purity_ms','normal_front_ms','instrumented_front_ms']}
s['profile_summary']=dict(sum_of_per_input_medians=totals,median_instrumented_over_normal=st.median(x['instrumented_over_normal'] for x in profile_rows),min_instrumented_over_normal=min(x['instrumented_over_normal'] for x in profile_rows),max_instrumented_over_normal=max(x['instrumented_over_normal'] for x in profile_rows))
for base in ['avx2','pdq','ABW_skip_pdq']:
 s['comparison_'+base]=dict(faster=sum(x['full_over_'+base]<1 for x in rows),slower=sum(x['full_over_'+base]>1 for x in rows),five_pct_faster=sum(x['full_over_'+base]<.95 for x in rows),five_pct_slower=sum(x['full_over_'+base]>1.05 for x in rows),best=min(rows,key=lambda x:x['full_over_'+base]),worst=max(rows,key=lambda x:x['full_over_'+base]))
(o/'full_summary.json').write_text(json.dumps(s,indent=2))
report='''# Full ABW->pdqsort versus AVX2 and frontend-cost diagnosis

## Scope

This same-run comparison measures the actual frozen v0.2 candidate's default
full ABW->pdqsort, AVX2 alone, pdqsort alone and the earlier skip-only ABW->pdq.
The default full call includes its own analysis/count/scatter/local temporary/
bucket sorts/copy/free. No workspace reuse. Skip-only uses the exact copied
front half and calls pdqsort on the untouched whole input when mixed. Its
original count pass still completes after purity failure. No source, dispatch,
threshold, histogram, seed or input changes. Historical percentages from other
runs are not subtracted to infer the mixed-path benefit; full/skip is measured
directly here. Direct output is not presumed to win on every input: the prior
pdq skip-only skin_label regression remains in its original report.

## Conditions

Windows11/i5-14500, LLVM-MinGW Clang23.1.5/libc++ UCRT, Boost1.90.0 and
x86-simd-sort v7.0 commit8a7208187d99f0cb67e38c57ab1c7c85aad07aca. Common
C++17 -O3 -DNDEBUG -mavx2 -mno-avx512f -mbmi -static -pthread. AVX2 only,
single-threaded, no OpenMP. Original unchanged66 inputs, no eligibility drops.
One binary/shared fixed input scratch/common noinline function-pointer timer.
Input load/restore outside time, complete API inside, full-array expected
equality after every call. Input/source/expected hashes checked before/after.
Three fresh processes/input, randomized input and comparator order, four
ABBA/BAAB blocks per comparison:198 processes and9,504 correct timed sorts.
Warm repeated calls; no cache-disturbance condition, external CPU test or
additional memory profile in this run. Original files and public code preserved.

Each pair has its own full-ABW call samples. Primary ratio is median3 of the
same-process paired-call-median ratios. Times shown are median3 process medians
within each pair; quotients may differ slightly from primary ratios. Equal-input
geometric means by existing real9/new real9/synthetic42/IPv4_6/all66. The all66
average is not a production input mix. Process ratios and every input remain
in the CSV. No discarded inputs/runs or timing-based tuning.

## Geometric mean full ABW time / comparator time

Below1 means full ABW is faster.

| Input group | N | /AVX2 | /pdqsort | /skip-only pdq |
|---|---:|---:|---:|---:|
'''
for g,q in s['groups'].items():report+='| '+g+f" | {q['n']} | "+' | '.join(f'{q[b]:.5f}' for b in ['avx2','pdq','ABW_skip_pdq'])+' |\n'
report+='\n## All66: full ABW versus AVX2 input table\n\n| Input | Path | AVX2 ms | Full ABW ms | Full/AVX2 | Three process ratios |\n|---|---|---:|---:|---:|---|\n'
for x in rows:report+='| '+x['name']+' | '+('direct' if x['direct'] else 'mixed' if x['mixed'] else 'native/skip')+f" | {x['avx2_ms']:.5f} | {x['full_paired_with_avx2_ms']:.5f} | {x['full_over_avx2']:.5f} | "+', '.join(f'{v:.4f}' for v in x['full_avx2_process_ratios'])+' |\n'
report+='\n## Same-run mixed-path contribution: full versus skip-only pdq\n\n| Input | Path | skip-only ms | full ms | Full/skip-only | Three process ratios |\n|---|---|---:|---:|---:|---|\n'
for x in rows:report+='| '+x['name']+' | '+('direct' if x['direct'] else 'mixed' if x['mixed'] else 'native/skip')+f" | {x['ABW_skip_pdq_ms']:.5f} | {x['full_paired_with_ABW_skip_pdq_ms']:.5f} | {x['full_over_ABW_skip_pdq']:.5f} | "+', '.join(f'{v:.4f}' for v in x['full_ABW_skip_pdq_process_ratios'])+' |\n'
report+='\n## Separate frontend phase diagnosis on27 mixed inputs\n\nThis diagnostic executes after the uninstrumented primary comparison, in a\nseparate executable. It measures probe, sample allocation/frequencies, width\nscan, entropy and count/purity. Three repeats alternate normal and instrumented\nfrontend calls; choices and untouched-input invariants agree. No backend sort\nruns in this diagnostic. Phase clocks never enter the primary API timings.\nThe original fixed frequency helper, sample positions, certificate and copied\ncount pass are retained. These component costs describe the diagnostic; they\nare not subtracted from primary end-to-end measurements. A zero width-scan cost\ncan mean the existing bit31 certificate omitted the scan.\n\n| Input | Normal front ms | Instrumented ms | Probe ms | Sample allocation+frequency ms | Width scan ms | Entropy ms | Count/purity ms | Instrumented/normal |\n|---|---:|---:|---:|---:|---:|---:|---:|---:|\n'
for x in profile_rows:report+='| '+x['name']+' | '+' | '.join(f'{x[f]:.6f}' for f in ['normal_front_ms','instrumented_front_ms','probe_ms','sample_total_ms','scan_ms','entropy_ms','count_purity_ms','instrumented_over_normal'])+' |\n'
report+='\nThe sum of per-input median component times (27 one-input diagnoses, not a\nsingle application call) is recorded in full_summary.json. This preserves both\nabsolute sizes and the normal/instrumented total comparison.\n'
report+='\n## Reproduction files\n\nRun from the original workspace root:\n\n```\npython work/abw_full_backend_check/run_full_abw_avx2_comparison.py\n```\n\nThe output directory must not already exist. The archive includes the measured\nsources/build commands, frozen ABW/front-end, pinned x86 source archive, raw\nsessions, phase records, protocol/input hashes and result CSVs. Boost, compiler\nand dataset binaries are not bundled. full_comparison_plan.json preserves the\nprepared plan; completion.json records execution completion. Public README\nupdates document these results; no main merge or release is part of this run.\n'
(o/'full_backend_report.md').write_text(report)
for f in w.glob('*'):
 if f.is_file() and f.suffix!='.exe':shutil.copyfile(f,o/f.name)
frozen=o/'frozen';frozen.mkdir(exist_ok=True)
for name in ['abw_reference.hpp','skip_only.hpp','source_provenance.json','x86-simd-sort-v7.0.zip']:shutil.copyfile(root/'work/abw_backends'/name,frozen/name)
shutil.copyfile(root/'work/abw_v020/environment.json',o/'environment.json');shutil.copyfile(root/'outputs/abw_v020_candidate/LICENSE',o/'ABW_LICENSE');shutil.copyfile(root/'work/abw_backends/x86-simd-sort-7.0/LICENSE.md',o/'x86_LICENSE.md')
manifest={f.relative_to(o).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in o.rglob('*') if f.is_file() and f.name!='package_manifest.json'};(o/'package_manifest.json').write_text(json.dumps(manifest,indent=2))
zpath=root/'outputs/abw_full_backend_comparison_results.zip'
with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED) as z:
 for f in o.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(o))
print(json.dumps(dict(groups=s['groups'],profile_summary=s['profile_summary'],comparisons={b:s['comparison_'+b] for b in ['avx2','pdq','ABW_skip_pdq']}),indent=2));print('Saved evidence',zpath,zpath.stat().st_size)
