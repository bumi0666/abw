"""Prepared comparison; execute after approval for the 66-input run."""
from pathlib import Path
import json,hashlib,subprocess,random,statistics as st,math,csv
w=Path(__file__).resolve().parent;root=w.parent.parent;o=root/'outputs/abw_full_backend_comparison'
p=json.loads((w/'full_comparison_plan.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
o.mkdir(exist_ok=False)
def verify():
 assert all(sha(root/f)==h for f,h in p['source_hashes'].items())
 for c in p['cases']:
  for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(root/c['input_directory']/(c['name']+ext))==c[key]
verify();(o/'protocol.json').write_text(json.dumps(p,indent=2))
for session in range(3):
 jobs=p['cases'].copy();random.Random(824231+session).shuffle(jobs)
 with (o/f'session{session}.jsonl').open('x') as f:
  for i,c in enumerate(jobs):
   d=root/c['input_directory'];q=subprocess.run([str(w/'full_abw_avx2_comparison.exe'),str(d/(c['name']+'.bin')),str(d/(c['name']+'.expected.bin')),str(678831+session)],capture_output=True,text=True,check=True);v=json.loads(q.stdout);assert v['verified'] and len(v['runs'])==48
   f.write(json.dumps(dict(name=c['name'],group=c['evaluation_group'],session=session,result=v))+'\n');f.flush();print(session+1,i+1,'/66',c['name'],flush=True)
raw=[json.loads(l) for k in range(3) for l in (o/f'session{k}.jsonl').read_text().splitlines()];rows=[]
for c in p['cases']:
 rr=[x for x in raw if x['name']==c['name']];first=rr[0]['result'];row=dict(name=c['name'],group=c['evaluation_group'],n=c['n'],direct=first['direct'],mixed=first['mixed'],route=first['route'],bits=first['bits'],shift=first['shift'])
 assert len({(x['result']['route'],x['result']['bits'],x['result']['shift'],x['result']['direct'],x['result']['mixed']) for x in rr})==1
 for pair,base in enumerate(['avx2','pdq','ABW_skip_pdq']):
  a=[];b=[];ratios=[]
  for x in rr:
   runs=[t for t in x['result']['runs'] if t['pair']==pair];a.append(st.median(t['ms'] for t in runs if t['method']==base));b.append(st.median(t['ms'] for t in runs if t['method']=='ABW_full_pdq'));ratios.append(b[-1]/a[-1])
  row[base+'_ms']=st.median(a);row['full_paired_with_'+base+'_ms']=st.median(b);row['full_over_'+base]=st.median(ratios);row['full_'+base+'_process_ratios']=ratios
 rows.append(row)
with (o/'full_input_results.csv').open('w',newline='') as f:wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
gm=lambda a:math.exp(st.mean(math.log(x) for x in a));groups={}
for label in ['development_real','new_real','real18','synthetic','ctu_ipv4','all66','direct','mixed','native_skip']:
 rs=[x for x in rows if label=='all66' or x['group']==label or label=='real18' and x['group'] in ['development_real','new_real'] or label=='direct' and x['direct'] or label=='mixed' and x['mixed'] or label=='native_skip' and not x['direct'] and not x['mixed']]
 groups[label]=dict(n=len(rs),**{base:gm([x['full_over_'+base] for x in rs]) for base in ['avx2','pdq','ABW_skip_pdq']})
(o/'full_summary.json').write_text(json.dumps(dict(groups=groups,inputs=rows),indent=2))
# Separate diagnostics after primary timing; clocks never enter the primary API.
with (o/'frontend_profile.jsonl').open('x') as f:
 for name in p['profile_inputs']:
  c=next(c for c in p['cases'] if c['name']==name);q=subprocess.run([str(w/'backend_frontend_profile.exe'),str(root/c['input_directory']/(name+'.bin'))],capture_output=True,text=True,check=True);v=json.loads(q.stdout);assert v['verified'] and len(v['runs'])==3;f.write(json.dumps(dict(name=name,n=c['n'],result=v))+'\n');f.flush();print('profile',name,flush=True)
verify();(o/'completion.json').write_text(json.dumps(dict(status='complete',processes=198,timed_sorts=9504,profile_inputs=27,profile_repetitions=3,hashes_and_full_output_pass=True,public_implementation_changed=False),indent=2));print(json.dumps(groups,indent=2));print('COMPLETE198 timing processes,9504 correct sorts and27 separate frontend diagnostics')
