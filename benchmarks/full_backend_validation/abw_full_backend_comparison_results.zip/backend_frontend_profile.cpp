#include "skip_only.hpp"
#include <windows.h>
#include <chrono>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <stdexcept>
using V=std::vector<uint32_t>;using Clock=std::chrono::steady_clock;
double elapsed(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}
struct Trace {double probe_ms=0,sample_allocation_ms=0,sample_frequency_ms=0,scan_ms=0,entropy_ms=0,choose_total_ms=0,count_purity_ms=0,total_ms=0;};
namespace instrumented {using namespace abw::detail;
inline decision traced_choose(const array_type& a, Trace& t) {
    decision d;
    if (a.size() < 100000) return d;
    auto stamp = Clock::now();
    const auto order = probe(a);
    t.probe_ms=elapsed(stamp);
    // Keep ordered/native exits unless sampled variation is nonzero and within 8 bits.
    if (order.ordered && (order.variation == 0 || order.variation > 255u)) return d;
    // Ordered low-byte exception: detailed sample frequency cannot affect dispatch.
    if (order.ordered) {
        stamp=Clock::now();
        value_type difference = 0;
        const value_type reference = a[0];
        for (std::size_t i = 1; i < a.size(); ++i) difference |= a[i] ^ reference;
        t.scan_ms=elapsed(stamp);
        if (!difference) { d.selected = strategy::skip; return d; }
        if (bit_width(difference) <= 8) {
            d.selected = strategy::active8; d.bits = 8; d.shift = 0;
        }
        return d;
    }

    const auto m = std::min<std::size_t>(a.size() - 1,
                                        a.size() < 1000000 ? 512 : 2048);
    stamp=Clock::now();
    array_type values(m);
    t.sample_allocation_ms=elapsed(stamp);
    stamp=Clock::now();
    const auto summary = collect_sample(a, values, m);
    t.sample_frequency_ms=elapsed(stamp);
    const bool duplicate = 1 - double(summary.distinct) / m >= .5 ||
                           double(summary.mode) / m >= .1;
    d.bits = duplicate ? 8 : 12;
    // An actual sampled bit-31 difference proves the full uint32 width is 32.
    // Only zero/nonzero and bit_width are used below; lower OR bits are unused.
    stamp=Clock::now();
    value_type difference = order.variation & 0x80000000u;
    if (!difference) {
        for (std::size_t i = 1; i < a.size(); ++i) difference |= a[i] ^ a[0];
    }
    t.scan_ms=elapsed(stamp);
    if (!difference) {
        d.selected = strategy::skip;
        return d;
    }
    const auto width = bit_width(difference);
    d.shift = width > d.bits ? width - d.bits : 0;
    if (width <= 8) {
        // Exact whole-array certificate; bypass entropy only for this direct path.
        d.bits = 8;
        d.shift = 0;
        d.selected = strategy::active8;
        return d;
    }
    // A sampled certificate alone cannot authorize partitioning an ordered input.
    if (order.ordered) return d;
    stamp=Clock::now();
    const value_type mask = (1u << d.bits) - 1;
    std::vector<std::size_t> counts(1u << d.bits);
    for (const auto value : values) ++counts[(value >> d.shift) & mask];
    double entropy = 0;
    for (const auto count : counts) {
        if (count) {
            const double p = double(count) / m;
            entropy -= p * std::log2(p);
        }
    }
    if (entropy >= (duplicate ? 1 : 4))
        d.selected = duplicate ? strategy::active8 : strategy::active12;
    t.entropy_ms=elapsed(stamp);
    return d;
}

}
struct State {abw::detail::decision d;bool direct;};
__attribute__((noinline))State normal(V&a){auto d=abw::detail::choose(a);bool direct=false;if(d.selected==abw::detail::strategy::active8||d.selected==abw::detail::strategy::active12)direct=skip_only::try_direct(a,d.bits,d.shift);return {d,direct};}
__attribute__((noinline))State traced(V&a,Trace&t){auto all=Clock::now(),stamp=Clock::now();auto d=instrumented::traced_choose(a,t);t.choose_total_ms=elapsed(stamp);bool direct=false;if(d.selected==abw::detail::strategy::active8||d.selected==abw::detail::strategy::active12){stamp=Clock::now();direct=skip_only::try_direct(a,d.bits,d.shift);t.count_purity_ms=elapsed(stamp);}t.total_ms=elapsed(all);return {d,direct};}
V load(const char*p){std::ifstream f(p,std::ios::binary|std::ios::ate);auto bytes=f.tellg();if(!f||bytes<0||bytes%4)throw std::runtime_error("input");V a(size_t(bytes)/4);f.seekg(0);f.read(reinterpret_cast<char*>(a.data()),bytes);if(!f)throw std::runtime_error("read");return a;}
bool same(State s,abw::detail::decision d){return !s.direct&&s.d.selected==d.selected&&s.d.bits==d.bits&&s.d.shift==d.shift;}
int main(int argc,char**argv){try{if(argc!=2)throw std::runtime_error("input");DWORD_PTR p,s;if(!GetProcessAffinityMask(GetCurrentProcess(),&p,&s)||!SetProcessAffinityMask(GetCurrentProcess(),p&(~p+1)))throw std::runtime_error("affinity");auto a=load(argv[1]),before=a;auto ref=abw::detail::choose(a);if(ref.selected!=abw::detail::strategy::active8&&ref.selected!=abw::detail::strategy::active12)throw std::runtime_error("not active");if(!same(normal(a),ref)||a!=before)throw std::runtime_error("not mixed/changed input");std::cout<<std::setprecision(15)<<"{\"verified\":true,\"runs\":[";for(int k=0;k<3;++k){Trace t;State plain,inst;double base;auto run_base=[&]{auto start=Clock::now();plain=normal(a);base=elapsed(start);};if(k%2){inst=traced(a,t);run_base();}else{run_base();inst=traced(a,t);}if(!same(plain,ref)||!same(inst,ref)||a!=before)throw std::runtime_error("instrumentation choice/input mismatch");if(k)std::cout<<",";std::cout<<"{\"repeat\":"<<k<<",\"normal_front_ms\":"<<base<<",\"instrumented_front_ms\":"<<t.total_ms<<",\"probe_ms\":"<<t.probe_ms<<",\"sample_allocation_ms\":"<<t.sample_allocation_ms<<",\"sample_frequency_ms\":"<<t.sample_frequency_ms<<",\"scan_ms\":"<<t.scan_ms<<",\"entropy_ms\":"<<t.entropy_ms<<",\"choose_total_ms\":"<<t.choose_total_ms<<",\"count_purity_ms\":"<<t.count_purity_ms<<"}";}std::cout<<"]}";}catch(const std::exception&e){std::cerr<<e.what();return 1;}}
