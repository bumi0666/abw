# Prepared full-ABW / AVX2 check

Primary comparison: full ABW->pdqsort versus AVX2 alone, pdqsort alone and
skip-only ABW->pdqsort, on identical66 inputs in the same executable.
Three fresh processes/input, four ABBA blocks per pair:198 processes/9504 sorts.
Expected5-8 minutes. Complete output/hash/route checks. No source/policy tuning.
Separate27 mixed-input diagnostics split probe, sample allocation/frequencies,
full-width scan, entropy and count/purity costs; three alternating normal versus
instrumented frontend calls/input. Main performance binary has no phase clocks.
Original count pass continues after the first mixed value as in the prior copy.

Both binaries compile with the existing LLVM-MinGW/Boost/x86-simd-sort v7.0
C++17 AVX2-only conditions. One short mixed-input correctness/plumbing check
passes for each executable. The full run awaits approval.

From the original workspace root:
python work/abw_full_backend_check/run_full_abw_avx2_comparison.py
The output directory must not already exist. See full_comparison_plan.json for
input and source hashes. Dependencies and inputs use their existing locations.
The archive preserves their frozen prior files and the pinned x86 source ZIP.
README performance wording will use the new same-run results after completion.
No main merge/release or source optimization is included.
