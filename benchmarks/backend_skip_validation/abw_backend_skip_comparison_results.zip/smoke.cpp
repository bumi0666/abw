#include "skip_only.hpp"
#include <boost/sort/spreadsort/spreadsort.hpp>
#include "x86simdsort-static-incl.h"
#include <iostream>
#include <random>
#include <stdexcept>
#if !defined(__AVX2__) || defined(__AVX512F__)
#error Expected AVX2 only
#endif
using V=std::vector<uint32_t>;
struct Pdq {void operator()(V&a)const{boost::sort::pdqsort(a.begin(),a.end());}};
struct Spread {void operator()(V&a)const{boost::sort::spreadsort::integer_sort(a.begin(),a.end());}};
struct Simd {void operator()(V&a)const{x86simdsortStatic::qsort<uint32_t>(a.data(),a.size());}};
size_t checked=0,direct=0,mixed=0,native=0;
template<class Backend>void verify(const V&a,const V&e,Backend backend){auto b=a,c=a;backend(b);bool used=skip_only::sort(c,backend);if(b!=e||c!=e)throw std::runtime_error("incorrect backend/wrapper");auto d=abw::detail::choose(a);if(d.selected==abw::detail::strategy::active8||d.selected==abw::detail::strategy::active12){auto x=a;bool ok=skip_only::try_direct(x,d.bits,d.shift);if(ok!=used||(!ok&&x!=a)||(ok&&x!=e))throw std::runtime_error("direct or fallback modified input");if(ok)++direct;else ++mixed;}else ++native;}
void check(const V&a){auto e=a;std::sort(e.begin(),e.end());verify(a,e,Pdq{});verify(a,e,Spread{});verify(a,e,Simd{});++checked;}
int main(){try{std::mt19937 r(562172);for(size_t n:{0u,1u,2u,7u,8u,15u,16u,31u,32u,63u,64u,127u,128u,99999u,100000u,100003u,1000000u})for(unsigned form=0;form<4;++form){V a(n);for(auto&v:a){auto x=uint32_t(r());v=form==0?x:form==1?x%8:form==2?0xa5a50000u|(x&255):0x80000000u|(x&65535);}check(a);}for(int form=0;form<4;++form){V a(100003);for(size_t i=0;i<a.size();++i)a[i]=form==0?uint32_t(i):form==1?uint32_t(a.size()-i):form==2?UINT32_MAX: uint32_t(i%8)*0x11111111u;check(a);}for(size_t pos:{0u,50001u,100002u}){V a(100003);for(auto&v:a)v=r()%8;a[pos]=0x80000000u;check(a);}std::cout<<"PASS inputs="<<checked<<" backends=3 full_output_checks="<<checked*6<<" direct="<<direct<<" mixed_fallback="<<mixed<<" native_skip="<<native<<" AVX2_only=true C++17=true\n";}catch(const std::exception&e){std::cerr<<e.what();return 1;}}
