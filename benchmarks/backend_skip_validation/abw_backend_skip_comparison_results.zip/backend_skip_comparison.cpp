#include "skip_only.hpp"
#include <boost/sort/spreadsort/spreadsort.hpp>
#include "x86simdsort-static-incl.h"
#include <windows.h>
#include <chrono>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <random>
#include <stdexcept>
#if !defined(__AVX2__) || defined(__AVX512F__) || defined(_OPENMP)
#error Expected single-thread AVX2 only
#endif
using V=std::vector<uint32_t>;using Clock=std::chrono::steady_clock;
struct Pdq{void operator()(V&a)const{boost::sort::pdqsort(a.begin(),a.end());}};
struct Spread{void operator()(V&a)const{boost::sort::spreadsort::integer_sort(a.begin(),a.end());}};
struct Simd{void operator()(V&a)const{x86simdsortStatic::qsort<uint32_t>(a.data(),a.size());}};
template<class Backend>void plain(V&a){Backend{}(a);}
template<class Backend>void wrapped(V&a){skip_only::sort(a,Backend{});}
using Fn=void(*)(V&);Fn fns[]={plain<Pdq>,wrapped<Pdq>,plain<Spread>,wrapped<Spread>,plain<Simd>,wrapped<Simd>};
const char*names[]={"pdq","ABW_skip_pdq","spread","ABW_skip_spread","avx2","ABW_skip_avx2"};
V load(const char*p){std::ifstream f(p,std::ios::binary|std::ios::ate);auto bytes=f.tellg();if(!f||bytes<0||bytes%4)throw std::runtime_error("input");V a(size_t(bytes)/4);f.seekg(0);f.read(reinterpret_cast<char*>(a.data()),bytes);if(!f)throw std::runtime_error("read");return a;}
__attribute__((noinline))double measure(Fn fn,const V&src,const V&expected,V&scratch){std::copy(src.begin(),src.end(),scratch.begin());auto t=Clock::now();fn(scratch);auto ms=std::chrono::duration<double,std::milli>(Clock::now()-t).count();if(scratch!=expected)throw std::runtime_error("full output mismatch");return ms;}
int main(int argc,char**argv){try{if(argc!=4)throw std::runtime_error("input expected seed");DWORD_PTR p,s;if(!GetProcessAffinityMask(GetCurrentProcess(),&p,&s)||!SetProcessAffinityMask(GetCurrentProcess(),p&(~p+1)))throw std::runtime_error("affinity");auto a=load(argv[1]),e=load(argv[2]);if(a.size()!=e.size())throw std::runtime_error("sizes");auto d=abw::detail::choose(a);bool active=d.selected==abw::detail::strategy::active8||d.selected==abw::detail::strategy::active12;bool direct=false;if(active){auto x=a;direct=skip_only::try_direct(x,d.bits,d.shift);if((direct&&x!=e)||(!direct&&x!=a))throw std::runtime_error("audit");}V scratch(a.size());for(auto fn:fns)measure(fn,a,e,scratch);std::mt19937 rng(unsigned(std::stoul(argv[3])));std::cout<<std::setprecision(15)<<"{\"verified\":true,\"route\":"<<int(d.selected)<<",\"bits\":"<<d.bits<<",\"shift\":"<<d.shift<<",\"direct\":"<<(direct?"true":"false")<<",\"mixed_fallback\":"<<(active&&!direct?"true":"false")<<",\"runs\":[";bool first=true;for(int block=0;block<4;++block){std::vector<int>pairs={0,1,2};std::shuffle(pairs.begin(),pairs.end(),rng);for(int pair:pairs){int base=2*pair,wrap=base+1;int order[4]={base,wrap,wrap,base};if(block%2){order[0]=wrap;order[1]=base;order[2]=base;order[3]=wrap;}for(int pos=0;pos<4;++pos){auto who=order[pos];auto ms=measure(fns[who],a,e,scratch);if(!first)std::cout<<",";first=false;std::cout<<"{\"block\":"<<block<<",\"pair\":"<<pair<<",\"position\":"<<pos<<",\"method\":\""<<names[who]<<"\",\"ms\":"<<ms<<"}";}}}std::cout<<"]}";}catch(const std::exception&e){std::cerr<<e.what();return 1;}}
