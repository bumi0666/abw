// Experimental skip-only wrapper; published ABW is unchanged.
#pragma once
#include "abw_reference.hpp"
namespace skip_only {
using V=std::vector<uint32_t>;
using value_type=uint32_t;
using array_type=V;
// This front half is copied verbatim from the frozen ABW candidate.
// Existing count/start/representative allocations are retained for isolation.
inline bool try_direct(V& a,unsigned bits,unsigned shift) {
    // choose() has proved that all bits above mask are common.
    if (shift == 0) {
        const std::size_t B = std::size_t(1) << bits;
        const value_type mask = static_cast<value_type>(B - 1);
        const value_type prefix = a[0] & ~mask;
        std::vector<std::size_t> counts(bits == 8 ? 4 * B : B);
        if (bits == 8) {
            std::size_t i = 0;
            for (; i + 3 < a.size(); i += 4) {
                ++counts[a[i] & mask];
                ++counts[B + (a[i + 1] & mask)];
                ++counts[2 * B + (a[i + 2] & mask)];
                ++counts[3 * B + (a[i + 3] & mask)];
            }
            for (; i < a.size(); ++i) ++counts[a[i] & mask];
            for (std::size_t b = 0; b < B; ++b)
                counts[b] += counts[B + b] + counts[2 * B + b] + counts[3 * B + b];
        } else {
            for (const auto value : a) ++counts[value & mask];
        }
        std::size_t position = 0;
        for (std::size_t b = 0; b < B; ++b) {
            if (counts[b]) {
                std::fill_n(a.begin() + position, counts[b], prefix | static_cast<value_type>(b));
                position += counts[b];
            }
        }
        return true;
    }

    const std::size_t bucket_count = std::size_t(1) << bits;
    const value_type mask = static_cast<value_type>(bucket_count - 1);
    std::vector<std::size_t> counts(bucket_count), starts(bucket_count + 1);
    array_type representative(bucket_count);
    bool single = true;
    std::size_t i = 0;
    for (; i < a.size(); ++i) {
        const auto value = a[i];
        const std::size_t bucket = (value >> shift) & mask;
        const auto old = counts[bucket]++;
        if (!old) representative[bucket] = value;
        else if (representative[bucket] != value) {
            single = false;
            ++i;
            break;
        }
    }
    for (; i < a.size(); ++i) ++counts[(a[i] >> shift) & mask];
    if (single) {
        std::size_t position = 0;
        for (std::size_t b = 0; b < bucket_count; ++b) {
            if (counts[b]) {
                std::fill_n(a.begin() + position, counts[b], representative[b]);
                position += counts[b];
            }
        }
        return true;
    }
    return false; // Mixed values: input is still untouched; no scatter or bucket sort.
}
template<class Backend>
inline bool sort(V& a,Backend backend) {
 const auto d=abw::detail::choose(a);
 if(d.selected==abw::detail::strategy::skip)return false;
 if(d.selected!=abw::detail::strategy::native && try_direct(a,d.bits,d.shift))return true;
 backend(a);return false;
}
} // namespace skip_only
