"""Prepared full66 comparison. Run only after approval for the longer test."""
from pathlib import Path
import json,hashlib,subprocess,random,statistics as st,math,csv,shutil
w=Path(__file__).resolve().parent;root=w.parent.parent;o=root/'outputs/abw_backends_comparison'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((w/'backend_comparison_plan.json').read_text());cases=p['cases']
o.mkdir(exist_ok=False)
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(root/c['input_directory']/(c['name']+ext))==c[key]
assert all(sha(root/f)==h for f,h in p['source_hashes'].items())
(o/'protocol.json').write_text(json.dumps(p,indent=2))
for session in range(3):
 jobs=cases.copy();random.Random(382311+session).shuffle(jobs)
 with (o/f'session{session}.jsonl').open('x') as f:
  for i,c in enumerate(jobs):
   d=root/c['input_directory'];q=subprocess.run([str(w/'backend_skip_comparison.exe'),str(d/(c['name']+'.bin')),str(d/(c['name']+'.expected.bin')),str(781281+session)],capture_output=True,text=True,check=True);v=json.loads(q.stdout);assert v['verified'] and len(v['runs'])==48
   f.write(json.dumps(dict(name=c['name'],group=c['evaluation_group'],session=session,result=v))+'\n');f.flush();print(session+1,i+1,'/66',c['name'],'direct',v['direct'],'mixed_fallback',v['mixed_fallback'],flush=True)
raw=[json.loads(l) for s in range(3) for l in (o/f'session{s}.jsonl').read_text().splitlines()];rows=[]
for c in cases:
 rr=[x for x in raw if x['name']==c['name']];assert len(rr)==3
 row=dict(name=c['name'],group=c['evaluation_group'],n=c['n'],direct=rr[0]['result']['direct'],mixed_fallback=rr[0]['result']['mixed_fallback'],route=rr[0]['result']['route'],bits=rr[0]['result']['bits'],shift=rr[0]['result']['shift'])
 for base,wrap in [('pdq','ABW_skip_pdq'),('spread','ABW_skip_spread'),('avx2','ABW_skip_avx2')]:
  ratios=[];bt=[];wt=[]
  for x in rr:
   runs=x['result']['runs'];a=st.median(t['ms'] for t in runs if t['method']==base);b=st.median(t['ms'] for t in runs if t['method']==wrap);ratios.append(b/a);bt.append(a);wt.append(b)
  row[base+'_ms']=st.median(bt);row[wrap+'_ms']=st.median(wt);row[wrap+'_over_backend']=st.median(ratios);row[wrap+'_process_ratios']=ratios
 rows.append(row)
with (o/'input_results.csv').open('w',newline='') as f:wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
gm=lambda a:math.exp(st.mean(math.log(x) for x in a));groups={}
for label in ['development_real','new_real','synthetic','ctu_ipv4','all66','direct','mixed_fallback','native_skip']:
 rs=[x for x in rows if label=='all66' or x['group']==label or label=='direct' and x['direct'] or label=='mixed_fallback' and x['mixed_fallback'] or label=='native_skip' and not x['direct'] and not x['mixed_fallback']]
 groups[label]=dict(n=len(rs),**{m:gm([x[m+'_over_backend'] for x in rs]) for m in ['ABW_skip_pdq','ABW_skip_spread','ABW_skip_avx2']})
(o/'summary.json').write_text(json.dumps(dict(groups=groups,inputs=rows),indent=2));print(json.dumps(groups,indent=2))
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(root/c['input_directory']/(c['name']+ext))==c[key]
assert all(sha(root/f)==h for f,h in p['source_hashes'].items())
print('COMPLETE198 processes/9504 timed sorts; full output/source/input checks passed')
