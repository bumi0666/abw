// SPDX-License-Identifier: MIT
// Copyright (c) 2026 bumi0666
#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <array>
#include <vector>
#include <boost/sort/pdqsort/pdqsort.hpp>
#if defined(_MSC_VER)
#include <intrin.h>
#endif

namespace abw {
namespace detail { struct workspace_access; }

// Caller-owned temporary storage. Do not use one workspace concurrently.
class workspace {
    std::vector<std::uint32_t> buffer_;
    friend struct detail::workspace_access;
public:
    workspace() = default;
    workspace(const workspace&) = delete;
    workspace& operator=(const workspace&) = delete;
    workspace(workspace&&) noexcept = default;
    workspace& operator=(workspace&&) noexcept = default;
    std::size_t capacity() const noexcept { return buffer_.capacity(); }
    std::size_t retained_bytes() const noexcept { return capacity() * sizeof(std::uint32_t); }
    void release() noexcept { std::vector<std::uint32_t>().swap(buffer_); }
};

namespace detail {
struct workspace_access {
    static std::vector<std::uint32_t>& prepare(workspace& ws, std::size_t n) {
        ws.buffer_.resize(n);
        return ws.buffer_;
    }
};
}

namespace detail {
using value_type = std::uint32_t;
using array_type = std::vector<value_type>;
static_assert(sizeof(std::size_t) >= 8, "ABW currently supports 64-bit targets");

enum class strategy { native, skip, active8, active12 };
struct decision {
    strategy selected = strategy::native;
    unsigned bits = 0;
    unsigned shift = 0;
};

struct rng {
    value_type state;
    explicit rng(value_type seed) : state(seed) {}
    value_type next() {
        state ^= state << 13;
        state ^= state >> 17;
        state ^= state << 5;
        return state;
    }
};

inline unsigned bit_width(value_type value) {
#if defined(_MSC_VER)
    unsigned long index;
    _BitScanReverse(&index, value);
    return static_cast<unsigned>(index + 1);
#else
    return 32u - static_cast<unsigned>(__builtin_clz(value));
#endif
}

// Called only after the unchanged minimum-size check in choose().
struct probe_result { bool ordered; value_type variation; };
inline probe_result probe(const array_type& a) {
    const auto m = std::min<std::size_t>(256, a.size() - 1);
    rng r(0x12577abc);
    std::size_t up = 0, down = 0;
    value_type variation = 0;
    const value_type reference = a[0];
    for (std::size_t j = 0; j < m; ++j) {
        const auto lo = j * (a.size() - 1) / m;
        const auto hi = (j + 1) * (a.size() - 1) / m;
        const auto i = lo + r.next() % std::max<std::size_t>(1, hi - lo);
        const auto x = a[i], y = a[i + 1];
        up += x < y;
        down += x > y;
        variation |= (x ^ reference) | (y ^ reference);
    }
    return {double(up) / m <= .1 || double(down) / m <= .1, variation};
}

// At most 2048 sampled values, so a 4096-slot table stays at <= 50% load.
// Zero count marks an empty slot; every uint32 key, including 0/UINT32_MAX, is valid.
struct fixed_frequency {
    static constexpr std::size_t capacity = 4096;
    std::array<value_type, capacity> keys; // Read only after its count is nonzero.
    std::array<std::uint16_t, capacity> counts{};
    std::size_t distinct = 0;
    static value_type hash(value_type x) {
        x ^= x >> 16; x *= 0x7feb352du;
        x ^= x >> 15; x *= 0x846ca68bu;
        return x ^ (x >> 16);
    }
    std::size_t increment(value_type value) {
        std::size_t slot = hash(value) & (capacity - 1);
        while (counts[slot] && keys[slot] != value) slot = (slot + 1) & (capacity - 1);
        if (!counts[slot]) { keys[slot] = value; ++distinct; }
        return ++counts[slot];
    }
};
struct sample_summary { std::size_t distinct; std::size_t mode; };
// Keep the 24 KiB table frame off the native/ordered fast paths.
#if defined(_MSC_VER)
__declspec(noinline)
#else
__attribute__((noinline))
#endif
inline sample_summary collect_sample(const array_type& a, array_type& values, std::size_t m) {
    fixed_frequency frequency;
    rng r(0x55ab76c1);
    std::size_t mode = 0;
    for (std::size_t j = 0; j < m; ++j) {
        const auto lo = j * (a.size() - 1) / m;
        const auto hi = (j + 1) * (a.size() - 1) / m;
        const auto value = a[lo + r.next() % std::max<std::size_t>(1, hi - lo)];
        values[j] = value;
        mode = (std::max)(mode, frequency.increment(value));
    }
    return {frequency.distinct, mode};
}

// Validated v0.1.2 policy: exact low-byte direct-output exception.
// Sample positions and the remaining E thresholds are retained.
inline decision choose(const array_type& a) {
    decision d;
    if (a.size() < 100000) return d;
    const auto order = probe(a);
    // Keep ordered/native exits unless sampled variation is nonzero and within 8 bits.
    if (order.ordered && (order.variation == 0 || order.variation > 255u)) return d;
    // Ordered low-byte exception: detailed sample frequency cannot affect dispatch.
    if (order.ordered) {
        value_type difference = 0;
        const value_type reference = a[0];
        for (std::size_t i = 1; i < a.size(); ++i) difference |= a[i] ^ reference;
        if (!difference) { d.selected = strategy::skip; return d; }
        if (bit_width(difference) <= 8) {
            d.selected = strategy::active8; d.bits = 8; d.shift = 0;
        }
        return d;
    }

    const auto m = std::min<std::size_t>(a.size() - 1,
                                        a.size() < 1000000 ? 512 : 2048);
    array_type values(m);
    const auto summary = collect_sample(a, values, m);
    const bool duplicate = 1 - double(summary.distinct) / m >= .5 ||
                           double(summary.mode) / m >= .1;
    d.bits = duplicate ? 8 : 12;
    // An actual sampled bit-31 difference proves the full uint32 width is 32.
    // Only zero/nonzero and bit_width are used below; lower OR bits are unused.
    value_type difference = order.variation & 0x80000000u;
    if (!difference) {
        for (std::size_t i = 1; i < a.size(); ++i) difference |= a[i] ^ a[0];
    }
    if (!difference) {
        d.selected = strategy::skip;
        return d;
    }
    const auto width = bit_width(difference);
    d.shift = width > d.bits ? width - d.bits : 0;
    if (width <= 8) {
        // Exact whole-array certificate; bypass entropy only for this direct path.
        d.bits = 8;
        d.shift = 0;
        d.selected = strategy::active8;
        return d;
    }
    // A sampled certificate alone cannot authorize partitioning an ordered input.
    if (order.ordered) return d;
    const value_type mask = (1u << d.bits) - 1;
    std::vector<std::size_t> counts(1u << d.bits);
    for (const auto value : values) ++counts[(value >> d.shift) & mask];
    double entropy = 0;
    for (const auto count : counts) {
        if (count) {
            const double p = double(count) / m;
            entropy -= p * std::log2(p);
        }
    }
    if (entropy >= (duplicate ? 1 : 4))
        d.selected = duplicate ? strategy::active8 : strategy::active12;
    return d;
}

// Storage selection is compile-time; no workspace branch in element loops.
struct owned_buffer {
    array_type values;
    explicit owned_buffer(std::size_t n) : values(n) {}
    array_type& get() noexcept { return values; }
};
struct borrowed_buffer {
    array_type& values;
    array_type& get() noexcept { return values; }
};
struct make_owned_buffer {
    owned_buffer operator()(std::size_t n) const { return owned_buffer(n); }
};
struct make_workspace_buffer {
    workspace& ws;
    borrowed_buffer operator()(std::size_t n) const {
        return {workspace_access::prepare(ws, n)};
    }
};

// Exact B execution path. Representative zero initialization is retained.
template<class MakeBuffer>
inline bool partition_and_sort_impl(array_type& a, unsigned bits, unsigned shift, MakeBuffer make_buffer) {
    // choose() has proved that all bits above mask are common.
    if (shift == 0) {
        const std::size_t B = std::size_t(1) << bits;
        const value_type mask = static_cast<value_type>(B - 1);
        const value_type prefix = a[0] & ~mask;
        std::vector<std::size_t> counts(bits == 8 ? 4 * B : B);
        if (bits == 8) {
            std::size_t i = 0;
            for (; i + 3 < a.size(); i += 4) {
                ++counts[a[i] & mask];
                ++counts[B + (a[i + 1] & mask)];
                ++counts[2 * B + (a[i + 2] & mask)];
                ++counts[3 * B + (a[i + 3] & mask)];
            }
            for (; i < a.size(); ++i) ++counts[a[i] & mask];
            for (std::size_t b = 0; b < B; ++b)
                counts[b] += counts[B + b] + counts[2 * B + b] + counts[3 * B + b];
        } else {
            for (const auto value : a) ++counts[value & mask];
        }
        std::size_t position = 0;
        for (std::size_t b = 0; b < B; ++b) {
            if (counts[b]) {
                std::fill_n(a.begin() + position, counts[b], prefix | static_cast<value_type>(b));
                position += counts[b];
            }
        }
        return true;
    }

    const std::size_t bucket_count = std::size_t(1) << bits;
    const value_type mask = static_cast<value_type>(bucket_count - 1);
    std::vector<std::size_t> counts(bucket_count), starts(bucket_count + 1);
    array_type representative(bucket_count);
    bool single = true;
    std::size_t i = 0;
    for (; i < a.size(); ++i) {
        const auto value = a[i];
        const std::size_t bucket = (value >> shift) & mask;
        const auto old = counts[bucket]++;
        if (!old) representative[bucket] = value;
        else if (representative[bucket] != value) {
            single = false;
            ++i;
            break;
        }
    }
    for (; i < a.size(); ++i) ++counts[(a[i] >> shift) & mask];
    if (single) {
        std::size_t position = 0;
        for (std::size_t b = 0; b < bucket_count; ++b) {
            if (counts[b]) {
                std::fill_n(a.begin() + position, counts[b], representative[b]);
                position += counts[b];
            }
        }
        return true;
    }
    for (std::size_t b = 0; b < bucket_count; ++b)
        starts[b + 1] = starts[b] + counts[b];
    auto cursor = starts;
    auto owner = make_buffer(a.size());
    auto& temporary = owner.get();
    for (const auto value : a) {
        const auto b = (value >> shift) & mask;
        temporary[cursor[b]++] = value;
    }
    for (std::size_t b = 0; b < bucket_count; ++b) {
        if (counts[b] > 1)
            boost::sort::pdqsort(temporary.begin() + starts[b],
                                temporary.begin() + starts[b + 1]);
    }
    std::copy(temporary.begin(), temporary.end(), a.begin());
    return false;
}
inline bool partition_and_sort(array_type& a, unsigned bits, unsigned shift) {
    return partition_and_sort_impl(a, bits, shift, make_owned_buffer{});
}
inline bool partition_and_sort_workspace(array_type& a, unsigned bits, unsigned shift, workspace& ws) {
    return partition_and_sort_impl(a, bits, shift, make_workspace_buffer{ws});
}

} // namespace detail

// Sort uint32_t keys in nondecreasing order. Allocations may throw.
// No stability or attached-record/payload support is provided.
inline void sort(std::vector<std::uint32_t>& values) {
    const auto d = detail::choose(values);
    if (d.selected == detail::strategy::native)
        boost::sort::pdqsort(values.begin(), values.end());
    else if (d.selected != detail::strategy::skip)
        detail::partition_and_sort(values, d.bits, d.shift);
}

// Repeated calls may retain caller-owned mixed-path temporary storage.
inline void sort(std::vector<std::uint32_t>& values, workspace& ws) {
    const auto d = detail::choose(values);
    if (d.selected == detail::strategy::native)
        boost::sort::pdqsort(values.begin(), values.end());
    else if (d.selected != detail::strategy::skip)
        detail::partition_and_sort_workspace(values, d.bits, d.shift, ws);
}
} // namespace abw
