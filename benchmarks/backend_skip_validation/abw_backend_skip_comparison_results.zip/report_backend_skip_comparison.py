from pathlib import Path
import json,math,statistics as st,csv,hashlib,zipfile,shutil
w=Path(__file__).resolve().parent;root=w.parent.parent;o=root/'outputs/abw_backends_comparison'
s=json.loads((o/'summary.json').read_text());p=json.loads((o/'protocol.json').read_text());rows=s['inputs'];raw=[json.loads(l) for k in range(3) for l in (o/f'session{k}.jsonl').read_text().splitlines()]
assert len(rows)==66 and len(raw)==198 and sum(len(x['result']['runs']) for x in raw)==9504
assert all(x['result']['verified'] for x in raw)
for c in p['cases']:
 rr=[x['result'] for x in raw if x['name']==c['name']]
 assert len({(x['route'],x['bits'],x['shift'],x['direct'],x['mixed_fallback']) for x in rr})==1
gm=lambda a:math.exp(st.mean(math.log(x) for x in a));methods=['ABW_skip_pdq','ABW_skip_spread','ABW_skip_avx2']
group_summary=s['groups'];real=[x for x in rows if x['group'] in ['development_real','new_real']];group_summary['real18']=dict(n=len(real),**{m:gm([x[m+'_over_backend'] for x in real]) for m in methods})
detail={}
for m in methods:
 base=dict(ABW_skip_pdq='pdq',ABW_skip_spread='spread',ABW_skip_avx2='avx2')[m]
 detail[m]=dict(faster=sum(x[m+'_over_backend']<1 for x in rows),slower=sum(x[m+'_over_backend']>1 for x in rows),faster_by_5pct=sum(x[m+'_over_backend']<.95 for x in rows),slower_by_5pct=sum(x[m+'_over_backend']>1.05 for x in rows),worst=max(rows,key=lambda x:x[m+'_over_backend']),best=min(rows,key=lambda x:x[m+'_over_backend']),real_gains=[dict(name=x['name'],ratio=x[m+'_over_backend'],base_ms=x[base+'_ms'],wrapped_ms=x[m+'_ms'],process_ratios=x[m+'_process_ratios']) for x in real if x[m+'_over_backend']<.95])
s.update(groups=group_summary,comparison_details=detail)
(o/'summary.json').write_text(json.dumps(s,indent=2))
report='''# Three-backend skip-only ABW comparison

## What this measures

Experimental copy of the frozen v0.2 candidate's preprocessing. Same sample
positions/seeds, order/entropy gates, exact width/certificate, zero-shift
histograms and nonzero-shift purity front half. It is not the full ABW mixed
partition algorithm. When exact direct output succeeds, values/counts are
written into the input. When any mixed bucket is found, the original input is
left unchanged and the backend sorts the whole array. Native/skip decisions
retain their existing behavior. No n-element temporary, scatter or bucket sort;
the original count/start/representative allocations in the copied front half
are retained. After the first mixed value only further purity comparisons stop;
the original count pass continues to the end before fallback. The measured
loss therefore describes this frozen front-half implementation, not a lower
bound for every possible skip-only wrapper. This experiment does not test workspace reuse. No threshold or
backend-specific dispatch tuning. Published ABW and GitHub remain unchanged.

## Implementations and conditions

Boost1.90.0 pdqsort and integer Spreadsort; x86-simd-sort v7.0 commit
8a7208187d99f0cb67e38c57ab1c7c85aad07aca, static uint32 qsort API. Exact official
source archive/hash is recorded. LLVM-MinGW Clang23.1.5/libc++ UCRT, C++17
-O3 -DNDEBUG -mavx2 -mno-avx512f -mbmi -static -pthread for all methods.
Preprocessor checks AVX2 enabled, AVX-512/OpenMP disabled. All sorters are
single-threaded. One local Windows11/i5-14500 machine, first allowed CPU
affinity. This is not Linux/cross-CPU validation.

All unchanged66 inputs: original real9, new real9, synthetic42, CTU IPv4 six.
No selection by results, shuffle of values, duplication or data transformation.
Source/input/expected hashes checked before and after. Source datasets,
extraction meaning, eligibility and hashes remain in the protocol's case list.
The old competition_methods fields in those reused input records are historical;
only the six methods described here execute. All six handle the same uint32
ascending key-only problem; no restricted-input omissions.

Same binary, fixed shared input scratch, common noinline function-pointer
timer. Restore outside timing; full frontend and backend API cost inside.
Full-array expected equality after every call. Per-input route/direct/fallback
audit outside timing verifies mixed inspection leaves the input unchanged.
One untimed warmup per method. Four ABBA/BAAB blocks per backend pair, pair order
shuffled. Three fresh-process sessions/input with randomized input order:198
processes and9,504 timed sorts. Warm repeated-call condition only; no cache
disturbance or workspace. No outlier removal, A/A control or significance claim.

Time ratio is wrapped/backend: same-pair call medians/process, median3 process
ratios/input, equal-input geometric mean by group. Displayed times are median3
process medians; their quotient can differ from the primary ratio. Below1 is
faster. Descriptive +/-5% counts are not statistical confidence intervals.
All66 equally weights42 synthetics and is not a production workload mixture.
Existing real18 and correlated IPv4 columns are reported separately. No measured
maximum is a bound for unseen inputs. Allocator/cache/assembly causes are not
inferred from timing alone. Additional peak heap/RSS is not measured here.

## Geometric mean wrapped/backend time ratios

| Input group | N | pdqsort wrapper | Spreadsort wrapper | AVX2 wrapper |
|---|---:|---:|---:|---:|
'''
for g in ['development_real','new_real','real18','synthetic','ctu_ipv4','all66','direct','mixed_fallback','native_skip']:
 q=group_summary[g];report+='| '+g+f" | {q['n']} | "+' | '.join(f'{q[m]:.5f}' for m in methods)+' |\n'
report+='\n## Input-level win/loss counts\n\n| Wrapper | Faster | Slower | >5% faster | >5% slower |\n|---|---:|---:|---:|---:|\n'
for m,q in detail.items():report+=f"| {m} | {q['faster']} | {q['slower']} | {q['faster_by_5pct']} | {q['slower_by_5pct']} |\n"
report+='\n## All input results\n\n| Input | Path | pdq ms | +wrapper ms | Ratio | Spread ms | +wrapper ms | Ratio | AVX2 ms | +wrapper ms | Ratio |\n|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n'
for x in rows:
 report+='| '+x['name']+' | '+('direct' if x['direct'] else 'mixed fallback' if x['mixed_fallback'] else 'native/skip')+' | '+' | '.join(f'{v:.5f}' for base,m in [('pdq',methods[0]),('spread',methods[1]),('avx2',methods[2])] for v in [x[base+'_ms'],x[m+'_ms'],x[m+'_over_backend']])+' |\n'
report+='\n## Largest regressions, with all process ratios\n\n| Wrapper | Input | Ratio | Backend ms | Wrapped ms | Three process ratios |\n|---|---|---:|---:|---:|---|\n'
for m,q in detail.items():
 base=dict(ABW_skip_pdq='pdq',ABW_skip_spread='spread',ABW_skip_avx2='avx2')[m]
 for x in sorted(rows,key=lambda x:x[m+'_over_backend'],reverse=True)[:5]:report+=f"| {m} | {x['name']} | {x[m+'_over_backend']:.5f} | {x[base+'_ms']:.5f} | {x[m+'_ms']:.5f} | "+', '.join(f'{v:.4f}' for v in x[m+'_process_ratios'])+' |\n'
report+='\n## Actual real18 gains above the descriptive5% band\n\n'
for m,q in detail.items():
 report+='### '+m+'\n\n'
 for x in q['real_gains']:report+=f"- {x['name']}: ratio {x['ratio']:.5f}, backend {x['base_ms']:.5f}ms, wrapped {x['wrapped_ms']:.5f}ms.\n"
 if not q['real_gains']:report+='None.\n'
report+='\n## Reproduction\n\nThe saved plan was frozen while prepared; its run_status is a historical\npre-run label. completion.json records actual completion. From the original\nworkspace root run `python work/abw_backends/run_backend_skip_comparison.py`\nafter restoring all hashed inputs and compiling with build_command/comparison_build\noptions; output directory must not already exist. It refuses overwriting results.\nThe evidence archive includes sources, pinned x86 source ZIP, hashes, all raw\nsessions and the report generator. Dataset binaries, Boost and compiler are not\nbundled. The executable uses Windows affinity APIs. Source/executable hashes\nidentify the measured build; no cross-platform performance promise.\n'
(o/'report.md').write_text(report)
completion=dict(status='complete',processes=198,timed_sorts=9504,full_output_checks_pass=True,source_input_hash_checks_pass=True,route_consistency_pass=True,public_code_changed=False,github_changed=False,groups=group_summary)
(o/'completion.json').write_text(json.dumps(completion,indent=2))
for f in ['skip_only.hpp','abw_reference.hpp','backend_skip_comparison.cpp','run_backend_skip_comparison.py','report_backend_skip_comparison.py','source_provenance.json','x86_tag_v7.json','comparison_build.json','build_command.json','smoke.cpp','build_result.json','smoke_result.json','harness_check.json','backend_comparison_plan.json']:
 shutil.copyfile(w/f,o/f)
shutil.copyfile(root/'work/abw_v020/environment.json',o/'environment.json');shutil.copyfile(w/'x86-simd-sort-v7.0.zip',o/'x86-simd-sort-v7.0.zip');shutil.copyfile(w/'x86-simd-sort-7.0/LICENSE.md',o/'x86_LICENSE.md');shutil.copyfile(root/'outputs/abw_v020_candidate/LICENSE',o/'ABW_LICENSE')
manifest={p.relative_to(o).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in o.rglob('*') if p.is_file() and p.name!='package_manifest.json'};(o/'package_manifest.json').write_text(json.dumps(manifest,indent=2))
zip_path=root/'outputs/abw_backend_skip_comparison_results.zip'
with zipfile.ZipFile(zip_path,'x',zipfile.ZIP_DEFLATED) as z:
 for f in o.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(o))
print(json.dumps(dict(groups=group_summary,details=detail),indent=2));print('Archive',zip_path,zip_path.stat().st_size)
