#define ABW_MEMPROFILE
#include "memory_profile.hpp"
#include <abw/abw.hpp>
#include <fstream>
#include <iostream>
#include <stdexcept>
using V=std::vector<std::uint32_t>;
V load(const char*p){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error("load");auto n=f.tellg();V a(std::size_t(n)/4);f.seekg(0);f.read(reinterpret_cast<char*>(a.data()),n);return a;}
int main(int argc,char**argv){try{if(argc!=3)return 2;auto a=load(argv[1]),expected=load(argv[2]);abwmem::begin();abw::sort(a);abwmem::end();if(a!=expected)throw std::runtime_error("incorrect");std::cout<<"{\"verified\":true,\"peak_requested_new_bytes\":"<<abwmem::peak<<",\"total_requested_new_bytes\":"<<abwmem::total<<",\"allocation_calls\":"<<abwmem::calls<<",\"live_after_sort\":"<<abwmem::live<<"}";}catch(const std::exception&e){std::cerr<<e.what();return 1;}}
