from pathlib import Path
import json,hashlib,random,subprocess,shutil
w=Path('work/abw_new_real_v012');o=Path('outputs/abw_new_real_v012');base=(w/'inputs').resolve();manifest=json.loads((w/'input_manifest.json').read_text());cases=manifest['cases'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[w/'include/abw/abw.hpp',w/'v011.hpp',w/'benchmark.cpp',w/'benchmark.exe',Path('work/ABW_realworld/vendor/cafs.hpp'),Path('work/ABW_realworld/vendor/cafs2.hpp')]
proto=dict(cases=cases,sessions=3,blocks_per_competitor=4,design=manifest['design'],build=json.loads((w/'build.json').read_text()),source_hashes={str(p):sha(p) for p in sources},environment='Intel Core i5-14500, Windows x64; first allowed CPU affinity; Clang23.1.5/libc++/UCRT, Boost1.90.0, C++20 O3 AVX2 BMI static pthread; one machine, no external CPU replication',measurement='same existing fixed u32 buffer/common noinline callsite; CAFS_i32 separate exact-value fixed buffer; ABBA/BAAB, pair order shuffled; loading/restoration/conversion/full equality and path audit outside timer; all sort-owned analysis, allocations, initialization, reconstruction, copies and free inside timer',eligibility='CAFS_i32 only <=INT32_MAX, Counting only 64MiB counters; source datetime converted exactly to naive whole-second coordinate without timezone assumption; no algorithm changes or filtering by performance',no_outlier_filtering=True)
(o/'protocol.json').write_text(json.dumps(proto,indent=2))
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(base/(c['name']+ext))==c[key]
for session in range(3):
 jobs=cases.copy();random.Random(527813+session).shuffle(jobs)
 with (o/f'session{session}.jsonl').open('x') as f:
  for i,c in enumerate(jobs):
   p=subprocess.run([str((w/'benchmark.exe').resolve()),str(base/(c['name']+'.bin')),str(base/(c['name']+'.expected.bin')),str(624581+session),str(int(c['cafs_i32_eligible'])),str(int(c['counting_eligible']))],capture_output=True,text=True,check=True);r=json.loads(p.stdout);assert r['verified'] and 'direct_output' in r and len(r['runs'])==(len(c['methods'])-1)*16
   f.write(json.dumps(dict(name=c['name'],group=c['group'],n=c['n'],session=session,result=r))+'\n');f.flush();print(session+1,i+1,'/9',c['name'],'direct',r['direct_output'],flush=True)
for p,h in proto['source_hashes'].items():assert sha(Path(p))==h
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(base/(c['name']+ext))==c[key]
print('COMPLETE: all inputs/sources unchanged, full equality each call',flush=True)
