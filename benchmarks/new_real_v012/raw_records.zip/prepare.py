from pathlib import Path
import sys,json,hashlib,zipfile,io,subprocess,shutil
import numpy as np
from decimal import Decimal
def exact_integer(token):
 d=Decimal(token.decode() if isinstance(token,bytes) else token)
 if not d.is_finite() or d!=d.to_integral_value():raise ValueError('non-integer source token')
 return int(d)
w=Path('work/abw_new_real_v012');sys.path.insert(0,str((w/'python_deps').resolve()))
import pyarrow.parquet as pq
o=Path('outputs/abw_new_real_v012');o.mkdir(exist_ok=True);inputs=w/'inputs';inputs.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sources=json.loads((w/'sources.json').read_text());cases=[];excluded=[]
def emit(name,arr,source,column,meaning,extraction,raw_rows=None,missing=0):
 a=np.asarray(arr);assert np.issubdtype(a.dtype,np.integer) and a.ndim==1 and a.size
 if a.min()<0 or a.max()>2**32-1:
  excluded.append(dict(name=name,reason='values outside uint32',min=int(a.min()),max=int(a.max())));return
 a=a.astype('<u4');p=inputs/(name+'.bin');a.tofile(p);ep=inputs/(name+'.expected.bin');np.sort(a).tofile(ep)
 c=dict(name=name,group='new_real',source=source,column=column,meaning=meaning,extraction=extraction,raw_rows=int(raw_rows or a.size),nulls_omitted=missing,n=int(a.size),unique=int(np.unique(a).size),min=int(a.min()),max=int(a.max()),sha256=sha(p),expected_sha256=sha(ep),bytes=p.stat().st_size,replicated=False,order='published row order preserved',cafs_i32_eligible=int(a.max())<=2**31-1,counting_eligible=(int(a.max())-int(a.min())+1)*8<=64*1024*1024)
 c['duplicate_fraction']=1-c['unique']/c['n'];c['methods']=['v012','v011','pdq','spread','CAFS_u32']+(['CAFS_i32'] if c['cafs_i32_eligible'] else [])+(['counting'] if c['counting_eligible'] else []);cases.append(c)
 print(name,c['n'],c['unique'],c['min'],c['max'],flush=True)
z=zipfile.ZipFile(w/'downloads/skin.zip');skin=np.loadtxt(io.BytesIO(z.read('Skin_NonSkin.txt')),dtype=np.int64)
for name,j,desc in [('skin_red',2,'Red channel intensity from sampled face-image pixels'),('skin_label',3,'Skin/non-skin class code')]:emit(name,skin[:,j],'skin',['B','G','R','label'][j],desc,'Parse original integer token, retain every published row; no new pixel sampling')
z=zipfile.ZipFile(w/'downloads/chest.zip');member='Activity Recognition from Single Chest-Mounted Accelerometer/1.csv';chest=np.loadtxt(io.BytesIO(z.read(member)),delimiter=',',dtype=np.int64,converters=exact_integer)
for name,j,desc in [('chest_sequence',0,'Participant 1 sequential sample number'),('chest_x',1,'Participant 1 uncalibrated x acceleration in original integer sensor units'),('chest_activity',4,'Participant 1 activity label; code 0 retained if present')]:emit(name,chest[:,j],'chest',['sequence','x','y','z','activity'][j],desc,'Full participant 1 CSV, selected by identifier before timing; exact integer parse, no calibration/filtering/concatenation')
tab=pq.read_table(w/'downloads/yellow_tripdata_2023-01.parquet',columns=['VendorID','payment_type','PULocationID','tpep_pickup_datetime'])
for col,name,meaning in [('VendorID','taxi_vendor','TPEP provider identifier'),('payment_type','taxi_payment','Payment method code'),('PULocationID','taxi_pickup_zone','Pickup taxi-zone identifier'),('tpep_pickup_datetime','taxi_pickup_time','Meter-engagement local date/time, timezone-unspecified whole-second coordinate')]:
 ar=tab[col];missing=ar.null_count;ar=ar.drop_null();a=ar.to_numpy()
 extraction='Exact nonnegative integer column conversion to uint32, no remapping; null omission only if required'
 if col=='tpep_pickup_datetime':
  ticks=a.astype('datetime64[us]').astype(np.int64)
  if np.any(ticks%1000000):excluded.append(dict(name=name,reason='timestamp has fractional seconds; excluded without rounding'));continue
  a=ticks//1000000
  extraction='All source microsecond timestamps are whole seconds. Encode exact naive wall-clock seconds since 1970-01-01 00:00:00; no timezone inferred or UTC claim, rounding, modulo, clipping or offset subtraction. Sorting preserves datetime order; not a general uint32 microsecond timestamp API.'
 emit(name,a,'taxi',col,meaning,extraction,tab.num_rows,missing)
manifest=dict(cases=cases,excluded=excluded,sources=sources,design=json.loads((w/'design.json').read_text()),numpy=np.__version__,pyarrow=sys.modules['pyarrow'].__version__)
(w/'input_manifest.json').write_text(json.dumps(manifest,indent=2));(o/'input_manifest.json').write_text(json.dumps(manifest,indent=2))
# Frozen headers: v0.1.2 public header must match the tested release file.
pub=Path('outputs/abw/include/abw/abw.hpp');assert sha(pub)=='ee50cb2be4060f4253c5693b944afedd7f97afcdb4e7ee79a19fe2e7a6b6675e'
inc=w/'include/abw';inc.mkdir(parents=True,exist_ok=True);shutil.copyfile(pub,inc/'abw.hpp')
old=Path('outputs/abw_competition_v012/include/abw/abw.hpp').read_text().replace('namespace abw {','namespace v011 {')
(w/'v011.hpp').write_text(old)
src=Path('work/abw_competition_v012/benchmark.cpp').read_text().replace('#include "candidate.hpp"','#include "v011.hpp"').replace('&candidate::sort,&abw::sort','&abw::sort,&v011::sort').replace('"candidate","v011"','"v012","v011"').replace('auto b=abw::detail::choose(a);auto c=candidate::detail::choose(a);','auto b=v011::detail::choose(a);auto c=abw::detail::choose(a);')
# Path audit outside timing; sort kernels are unchanged.
src=src.replace('std::cout<<std::setprecision(15)', 'auto audit=a; bool direct=false; if(c.selected==abw::detail::strategy::active8 || c.selected==abw::detail::strategy::active12) direct=abw::detail::partition_and_sort(audit,c.bits,c.shift); else abw::sort(audit); if(audit!=e) throw std::runtime_error("audit incorrect"); std::cout<<std::setprecision(15)')
src=src.replace('"{\\\"verified\\\":true,', '"{\\\"direct_output\\\":"<<(direct?"true":"false")<<",\\\"verified\\\":true,')
(w/'benchmark.cpp').write_text(src)
compiler=Path('work/F_toolchain/llvm-mingw-20261104-ucrt-x86_64/bin/clang++.exe').resolve();cmd=[str(compiler),'-std=c++20','-O3','-DNDEBUG','-mavx2','-mbmi','-static','-pthread','-I'+str((w/'include').resolve()),'-I'+str(Path('work/F_vendor/boost_1_90_0').resolve()),'-I'+str(Path('work/ABW_realworld/vendor').resolve()),str((w/'benchmark.cpp').resolve()),'-o',str((w/'benchmark.exe').resolve())]
p=subprocess.run(cmd,capture_output=True,text=True,check=True);(w/'build.json').write_text(json.dumps(dict(command=cmd,stdout=p.stdout,stderr=p.stderr),indent=2));print('Built unchanged public release harness; excluded',excluded,flush=True)
