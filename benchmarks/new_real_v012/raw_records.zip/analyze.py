from pathlib import Path
import json,csv,math,statistics as st
w=Path('work/abw_new_real_v012');o=Path('outputs/abw_new_real_v012');manifest=json.loads((w/'input_manifest.json').read_text());cases=manifest['cases'];raw=[json.loads(l) for p in sorted(o.glob('session[012].jsonl')) for l in p.read_text().splitlines()];assert len(raw)==27
methods=['v012','v011','pdq','spread','CAFS_u32','CAFS_i32','counting'];med={};sessions=[];pairs=[]
for row in raw:
 c=next(c for c in cases if c['name']==row['name']);r=row['result'];assert r['verified']
 for m in c['methods']:
  v=st.median(x['ms'] for x in r['runs'] if x['method']==m);med[c['name'],row['session'],m]=v;sessions.append(dict(name=c['name'],session=row['session'],method=m,ms=v))
 for m in c['methods'][1:]:
  for b in range(4):
   block=[x for x in r['runs'] if x['pair']==m and x['block']==b];a=st.mean(x['ms'] for x in block if x['method']=='v012');v=st.mean(x['ms'] for x in block if x['method']==m);pairs.append(dict(name=c['name'],session=row['session'],method=m,block=b,v012_ms=a,other_ms=v,speedup=v/a))
rows=[];routes={0:'native',1:'skip',2:'active8',3:'active12'}
for c in cases:
 name=c['name'];src=next(x['result'] for x in raw if x['name']==name);q=dict(name=name,source=c['source'],n=c['n'],unique=c['unique'],min=c['min'],max=c['max'],duplicate_fraction=c['duplicate_fraction'],route=routes[src['candidate_route']],baseline_route=routes[src['baseline_route']],bits=src['candidate_bits'],shift=src['candidate_shift'],direct=src['direct_output'])
 for m in c['methods']:
  q[m]=st.median(med[name,s,m] for s in range(3));q['speedup_'+m+'_vs_pdq']=st.median(med[name,s,'pdq']/med[name,s,m] for s in range(3));q['v012_over_'+m]=st.median(med[name,s,'v012']/med[name,s,m] for s in range(3))
 q['winner']=min(c['methods'],key=lambda m:q[m]);q['clear_fastest_vs_competitors']=all(q['v012_over_'+m]<.95 for m in c['methods'] if m not in ['v012','v011']);rows.append(q)
gm=lambda a:math.exp(st.mean(math.log(x) for x in a))
metrics={m:dict(eligible=sum(m in x for x in rows),gm_speedup_pdq=gm([x['speedup_'+m+'_vs_pdq'] for x in rows if m in x]),gm_v012_over_method=gm([x['v012_over_'+m] for x in rows if m in x]),wins=sum(x['v012_over_'+m]<.95 for x in rows if m in x),ties=sum(.95<=x['v012_over_'+m]<=1.05 for x in rows if m in x),losses=sum(x['v012_over_'+m]>1.05 for x in rows if m in x)) for m in methods}
subgroups={}
for label,ss in [('direct',[x for x in rows if x['direct']]),('not_direct',[x for x in rows if not x['direct']])]+[(s,[x for x in rows if x['source']==s]) for s in ['skin','chest','taxi']]:
 subgroups[label]=dict(n=len(ss),gm_speedup_pdq=gm([x['speedup_v012_vs_pdq'] for x in ss]),gm_time_vs_v011=gm([x['v012_over_v011'] for x in ss]))
summary=dict(metrics=metrics,subgroups=subgroups,direct_count=sum(x['direct'] for x in rows),timed_calls=sum(len(x['result']['runs']) for x in raw),processes=len(raw),max_vs_pdq=max(rows,key=lambda x:x['v012_over_pdq'])['name'],max_vs_v011=max(rows,key=lambda x:x['v012_over_v011'])['name'],nominal_v012_winners=[x['name'] for x in rows if x['winner']=='v012'],clear_fastest_vs_non_ABW=[x['name'] for x in rows if x['clear_fastest_vs_competitors']])
for path,data in [('input_results.csv',rows),('session_medians.csv',sessions),('paired_blocks.csv',pairs)]:
 keys=list(dict.fromkeys(k for x in data for k in x))
 with (o/path).open('w',newline='') as f:wr=csv.DictWriter(f,fieldnames=keys);wr.writeheader();wr.writerows(data)
(o/'summary.json').write_text(json.dumps(summary,indent=2))
text='''# ABW v0.1.2: new public-data validation

2026-11-13. Released implementation frozen; no optimization, policy tuning,
GitHub edits or new release. Sources/columns were selected in design.json before
timing. Original row order and values retained, no input replication or shuffle.
Nine columns from three public datasets, none used in the earlier Covertype,
Census or NASA experiments. This is a small new-workload validation on the same
CPU, not an independent hardware replication or random sample of all workloads.

## Data and extraction

'''
for s in manifest['sources']:
 text+=f"- **{s['id']}**: [{s['page']}]({s['page']}); [{s['file']}]({s['url']}); {s['license']}. Download SHA-256 `{s['sha256']}` ({s['bytes']:,} bytes).\n"
text+='''
UCI Skin is a published sample of B/G/R pixels from FERET/PAL face images, not a
new image-processing run or original raster scan. Red and class columns are kept
in released text-file order. UCI Chest uses the complete participant 1 file chosen
by identifier, not fastest participant. Sensor x is the original uncalibrated
integer reading, not a rounded continuous float. Sequence tokens include
scientific notation: Decimal parses them exactly, preserving source duplicates.
This sequence is not an artificially repaired unique ID. Activity code 0 retained.

TLC January 2023 Yellow Taxi uses full published Parquet columns with zero nulls
in the selected fields. All microsecond timestamp values were checked divisible
by 1,000,000, then represented exactly as timezone-unspecified wall-clock seconds
since 1970-01-01. No local-to-UTC interpretation, truncation, modulo, offset
subtraction or clipping. This tests chronological key sorting at source second
resolution; ABW does not gain a uint64/microsecond datetime API. Records as early
as 2009 remain, rather than filtering to the advertised month. Numeric integer
columns safely fit uint32 without remapping. No rows or columns were excluded.
No data arrays are redistributed in the reproduction archive. UCI licenses are
recorded as stated by UCI; original face-image rights are not relicensed here.
TLC is public data under [NYC.gov Terms of Use](https://www.nyc.gov/main/terms-of-use),
not asserted CC BY. [TLC dictionary](https://www.nyc.gov/assets/tlc/downloads/pdf/data_dictionary_trip_records_yellow.pdf)
provides field meanings; current provider code names need not describe historical vendors.

| Column | N | Unique | Min | Max | Duplicate fraction | v0.1.2 route | Bits/shift | Direct |
|---|---:|---:|---:|---:|---:|---|---|---|
'''
for x in rows:text+=f"| {x['name']} | {x['n']:,} | {x['unique']:,} | {x['min']} | {x['max']} | {x['duplicate_fraction']:.6f} | {x['route']} | {x['bits']}/{x['shift']} | {x['direct']} |\n"
text+='''
## Measurement

Same Intel i5-14500 / Windows x64 / first allowed CPU affinity, LLVM-MinGW
Clang 23.1.5, Boost 1.90.0. All methods same C++20 -O3 -DNDEBUG -mavx2 -mbmi
-static -pthread options to support pinned CAFS (commit
13488afef446ae88e7ad631ec6f862def896094a). v0.1.2 is a byte-identical public
header snapshot; v0.1.1 differs from its original header only in namespace.
Same fixed uint32 scratch and common noinline function-pointer timer for unsigned
methods; CAFS i32 uses separate fixed signed scratch with exactly identical values.
All nine columns fit INT32_MAX. Conversion/load/input restoration/warmup/path
audit/full-array equality excluded; all sort-owned scans, allocation/init,
histogram merge, scatter, sort, reconstruction/copy/free included. No timing
instrumentation in kernels. Full-array correctness checked every measured call.
Four ABBA/BAAB blocks per competitor, shuffled pair order; three fresh processes
per column. Same three original 100k warmup families and one actual-input warmup
per method. No outlier filtering. Sessions are repeated measurements, not new
datasets or new machines. Input and source hashes verified before and after.

CAFS u32 supported scalar API and specialized AVX2 i32 API both have pdq fallback.
Counting is the unchanged simple uint64 dense histogram including runtime min/max
and initialization, only where counter range fits the original 64 MiB cap.
Timestamp requires 3.56 GB of counters and is excluded from Counting, not counted
as a loss. Counting totals therefore cover eight columns, other totals nine.

Tables: median of method calls per process, then median of three process medians.
Ratios: median same-process median-time ratio, then geometric mean over eligible
columns. Ratios need not equal ratios of displayed time medians. ABW anchor times
pool calls across competitor pairs. Block-paired data are retained separately.
Descriptive 5% wins/ties/losses are not statistical significance claims.

'''
text+=f"**{summary['timed_calls']:,} timed sorts in {len(raw)} processes; every full-array check passed.**\n\n"
text+='| Method | Eligible columns | Geometric mean speedup vs pdq | v0.1.2/method time | v0.1.2 wins/ties/losses |\n|---|---:|---:|---:|---|\n'
for m,v in metrics.items():text+=f"| {m} | {v['eligible']} | {v['gm_speedup_pdq']:.4f} | {v['gm_v012_over_method']:.4f} | {v['wins']}/{v['ties']}/{v['losses']} |\n"
text+='\n## Every input time (ms)\n\n| Input | v0.1.2 | v0.1.1 | pdq | Spread | CAFS u32 | CAFS i32 | Counting | Lowest median |\n|---|---:|---:|---:|---:|---:|---:|---:|---|\n'
for x in rows:text+='| '+x['name']+' | '+' | '.join(f"{x[m]:.5f}" if m in x else 'not eligible' for m in methods)+' | '+x['winner']+' |\n'
text+='\n## Subgroups\n\n| Subgroup | N columns | v0.1.2 speedup vs pdq | v0.1.2/v0.1.1 time |\n|---|---:|---:|---:|\n'
for label,v in subgroups.items():text+=f"| {label} | {v['n']} | {v['gm_speedup_pdq']:.4f} | {v['gm_time_vs_v011']:.4f} |\n"
(o/'report.md').write_text(text,encoding='utf-8')
print(json.dumps(summary,indent=2));print('\nINPUTS');print(json.dumps(rows,indent=2))
