from pathlib import Path
import urllib.request,hashlib,json,concurrent.futures,datetime
w=Path('work/abw_new_real_v012');d=w/'downloads';d.mkdir(parents=True,exist_ok=True)
sources=[
dict(id='skin',url='https://archive.ics.uci.edu/static/public/229/skin+segmentation.zip',file='skin.zip',page='https://archive.ics.uci.edu/dataset/229/skin+segmentation',license='CC BY 4.0 (UCI dataset page)',columns=['R','label']),
dict(id='chest',url='https://archive.ics.uci.edu/ml/machine-learning-databases/00287/Activity%20Recognition%20from%20Single%20Chest-Mounted%20Accelerometer.zip',file='chest.zip',page='https://archive.ics.uci.edu/dataset/287/activity+recognition+from+single+chest+mounted+acceleromete',license='CC BY 4.0 (UCI dataset page)',columns=['subject 1 sequential number','subject 1 x acceleration','subject 1 activity label']),
dict(id='taxi',url='https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_2023-01.parquet',file='yellow_tripdata_2023-01.parquet',page='https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page',license='NYC public TLC trip records; NYC.gov Terms of Use, no separate CC license asserted',columns=['VendorID','payment_type','PULocationID','tpep_pickup_datetime'])]
design=dict(fixed_before_timing=True,release='v0.1.2',sources=sources,policy='No code/policy/input tuning, no replication/shuffle/reordering, full columns in published order; subject 1 chosen by identifier before measuring; exact integer conversion only; omit nulls per column retaining order and disclose counts, no rounding/clipping. Timestamp must be whole seconds and uint32; otherwise exclude column, no substitute chosen by speed.',fallback='If chest unavailable, use Skin B and G in addition to R/label, with TLC four columns (eight total). No generated poker hands or simulations counted as real data.',measurement='Reuse common-callsite fixed-buffer ABBA/BAAB competition harness, three fresh processes per input; unchanged Counting 64MiB cap and CAFS i32 representability rule; source and input hashes; all full-array correctness checks.')
(w/'design.json').write_text(json.dumps(design,indent=2))
def fetch(s):
 p=d/s['file']
 try:
  if not p.exists():
   with urllib.request.urlopen(urllib.request.Request(s['url'],headers={'User-Agent':'ABW-reproducible-research/0.1.2'}),timeout=60) as f,p.open('wb') as out:
    while chunk:=f.read(1024*1024):out.write(chunk)
  b=p.read_bytes();s.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),download_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='ok');print(s['id'],len(b),'bytes',flush=True)
 except Exception as e:s.update(status='failed',error=str(e));print(s['id'],str(e),flush=True)
 return s
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(fetch,sources))
(w/'sources.json').write_text(json.dumps(results,indent=2))
