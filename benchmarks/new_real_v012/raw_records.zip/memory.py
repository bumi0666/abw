from pathlib import Path
import subprocess,json,shutil
w=Path('work/abw_new_real_v012');o=Path('outputs/abw_new_real_v012');shutil.copyfile('work/ABW_realworld/memory_profile.hpp',w/'memory_profile.hpp')
cmd=json.loads((w/'build.json').read_text())['command'];cmd[-3]=str((w/'memory.cpp').resolve());cmd[-1]=str((w/'memory.exe').resolve());subprocess.run(cmd,check=True,capture_output=True)
rows=[]
for c in json.loads((w/'input_manifest.json').read_text())['cases']:
 p=subprocess.run([str((w/'memory.exe').resolve()),str((w/'inputs'/(c['name']+'.bin')).resolve()),str((w/'inputs'/(c['name']+'.expected.bin')).resolve())],check=True,capture_output=True,text=True);rows.append(dict(name=c['name'],**json.loads(p.stdout)))
(o/'memory.json').write_text(json.dumps(dict(scope='Separate instrumented ABW-only processes, requested C++ new/new[] peak during sort, includes analysis/dispatch; excludes preexisting input/expected buffers, allocator overhead, stack and RSS. Not used for timing.',build=cmd,rows=rows),indent=2))
print('ABW requested-heap audit complete; all outputs correct')
