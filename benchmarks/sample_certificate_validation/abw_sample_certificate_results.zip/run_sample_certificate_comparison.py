"""Prepared AVX2 comparison. Long run requires prior user approval."""
from pathlib import Path
import json,hashlib,subprocess,random,statistics as st,math,csv
w=Path(__file__).resolve().parent;root=w.parent.parent;o=root/'outputs/abw_sample_certificate_comparison'
p=json.loads((w/'sample_certificate_plan.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
o.mkdir(exist_ok=False)
def verify():
 assert all(sha(root/f)==h for f,h in p['source_hashes'].items())
 for c in p['cases']:
  for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(root/c['input_directory']/(c['name']+ext))==c[key]
verify();(o/'protocol.json').write_text(json.dumps(p,indent=2))
for session in range(3):
 jobs=p['cases'].copy();random.Random(314719+session).shuffle(jobs)
 with (o/f'session{session}.jsonl').open('x') as f:
  for i,c in enumerate(jobs):
   d=root/c['input_directory'];q=subprocess.run([str(w/'sample_certificate_comparison.exe'),str(d/(c['name']+'.bin')),str(d/(c['name']+'.expected.bin')),str(824871+session)],capture_output=True,text=True,check=True);v=json.loads(q.stdout);assert v['verified'] and len(v['runs'])==32
   f.write(json.dumps(dict(name=c['name'],group=c['evaluation_group'],session=session,result=v))+'\n');f.flush();print(session+1,i+1,'/66',c['name'],'witness',v['sample_witness'],flush=True)
raw=[json.loads(l) for k in range(3) for l in (o/f'session{k}.jsonl').read_text().splitlines()];rows=[]
for c in p['cases']:
 rr=[x for x in raw if x['name']==c['name']];first=rr[0]['result'];row=dict(name=c['name'],group=c['evaluation_group'],n=c['n'],direct=first['direct'],mixed=first['mixed_fallback'],sample_witness=first['sample_witness'],witness_examined=first['witness_examined'],route=first['route'],bits=first['bits'],shift=first['shift'])
 assert len({(x['result']['route'],x['result']['bits'],x['result']['shift'],x['result']['direct'],x['result']['mixed_fallback'],x['result']['sample_witness']) for x in rr})==1
 for pair,base in enumerate(['avx2','old_skip_avx2']):
  a=[];b=[];ratios=[]
  for x in rr:
   runs=[t for t in x['result']['runs'] if t['pair']==pair];a.append(st.median(t['ms'] for t in runs if t['method']==base));b.append(st.median(t['ms'] for t in runs if t['method']=='certified_skip_avx2'));ratios.append(b[-1]/a[-1])
  row[base+'_ms']=st.median(a);row['candidate_paired_with_'+base+'_ms']=st.median(b);row['candidate_over_'+base]=st.median(ratios);row['candidate_'+base+'_process_ratios']=ratios
 rows.append(row)
with (o/'sample_certificate_input_results.csv').open('w',newline='') as f:wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
gm=lambda a:math.exp(st.mean(math.log(x) for x in a));groups={}
for label in ['development_real','new_real','real18','synthetic','ctu_ipv4','all66','direct','mixed','native_skip','witness','no_witness']:
 rs=[x for x in rows if label=='all66' or x['group']==label or label=='real18' and x['group'] in ['development_real','new_real'] or label=='direct' and x['direct'] or label=='mixed' and x['mixed'] or label=='native_skip' and not x['direct'] and not x['mixed'] or label=='witness' and x['sample_witness'] or label=='no_witness' and not x['sample_witness']]
 groups[label]=dict(n=len(rs),**{base:gm([x['candidate_over_'+base] for x in rs]) for base in ['avx2','old_skip_avx2']})
(o/'sample_certificate_summary.json').write_text(json.dumps(dict(groups=groups,inputs=rows),indent=2));verify();(o/'completion.json').write_text(json.dumps(dict(status='complete',processes=198,timed_sorts=6336,hashes_full_output_and_choices_pass=True,public_implementation_changed=False),indent=2));print(json.dumps(groups,indent=2));print('COMPLETE198 processes/6336 correct timed sorts')
