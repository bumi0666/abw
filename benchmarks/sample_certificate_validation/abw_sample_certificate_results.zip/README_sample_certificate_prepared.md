# Prepared sample-certificate AVX2 comparison

Compile and short tests pass. Full66 comparison awaits approval (3-5 minutes).
Methods: AVX2 alone, frozen skip-only AVX2, exact-sample-certificate skip-only AVX2.
198 processes/6336 timed sorts, unchanged66 inputs, same prior ABBA layout.
No new threshold, sample positions, array scan or allocation. Mixed full ABW policy
is unchanged. This experiment targets skip-only frontend cost, not IPv4 mixed
partition losses. See sample_certificate_plan.json and source/test records.

Run from original workspace root after approval:
python work/abw_sample_certificate/run_sample_certificate_comparison.py
New output directory must not already exist. Dependencies use their old paths.
