#include "sample_mixed_certificate.hpp"
#include <boost/sort/spreadsort/spreadsort.hpp>
#include "x86simdsort-static-incl.h"
#include <fstream>
#include <iostream>
#include <map>
#include <random>
#include <stdexcept>
#if !defined(__AVX2__) || defined(__AVX512F__) || defined(_OPENMP)
#error AVX2 only, single thread
#endif
using V=std::vector<uint32_t>;
struct Pdq {void operator()(V&a)const{boost::sort::pdqsort(a.begin(),a.end());}};
struct Spread {void operator()(V&a)const{boost::sort::spreadsort::integer_sort(a.begin(),a.end());}};
struct Simd {void operator()(V&a)const{x86simdsortStatic::qsort<uint32_t>(a.data(),a.size());}};
V load(const char*p){std::ifstream f(p,std::ios::binary|std::ios::ate);auto n=f.tellg();if(!f||n<0||n%4)throw std::runtime_error("input");V a(size_t(n)/4);f.seekg(0);f.read(reinterpret_cast<char*>(a.data()),n);if(!f)throw std::runtime_error("read");return a;}
size_t checked=0,hits=0,misses=0;
void audit(const V&a){auto d=abw::detail::choose(a);sample_certificate::Proof proof;auto c=sample_certificate::choose(a,proof);if(d.selected!=c.selected||d.bits!=c.bits||d.shift!=c.shift)throw std::runtime_error("decision");bool active=d.selected==abw::detail::strategy::active8||d.selected==abw::detail::strategy::active12;bool expected=false;if(active&&d.shift!=0){size_t m=std::min<size_t>(a.size()-1,a.size()<1000000?512:2048);V v(m);abw::detail::collect_sample(a,v,m);std::map<uint32_t,uint32_t> representatives;auto mask=(1u<<d.bits)-1;for(auto x:v){auto b=(x>>d.shift)&mask;auto entry=representatives.emplace(b,x);if(!entry.second&&entry.first->second!=x)expected=true;}if(proof.found){if(proof.first==proof.second||((proof.first>>d.shift)&mask)!=proof.bucket||((proof.second>>d.shift)&mask)!=proof.bucket||std::find(v.begin(),v.end(),proof.first)==v.end()||std::find(v.begin(),v.end(),proof.second)==v.end())throw std::runtime_error("witness");}}if(expected!=proof.found)throw std::runtime_error("independent sample check");if(proof.found)++hits;}
 template<class Backend>void verify(const V&a,const V&e,Backend backend){auto b=a,c=a,d=a;backend(b);bool old=skip_only::sort(c,backend);bool now=sample_certificate::sort(d,backend);if(b!=e||c!=e||d!=e||old!=now)throw std::runtime_error("output/direct result");}
void check(const V&a){audit(a);auto e=a;std::sort(e.begin(),e.end());verify(a,e,Pdq{});verify(a,e,Spread{});verify(a,e,Simd{});auto d=abw::detail::choose(a);if(d.selected==abw::detail::strategy::active8||d.selected==abw::detail::strategy::active12){auto x=a;bool direct=skip_only::try_direct(x,d.bits,d.shift);sample_certificate::Proof p;sample_certificate::choose(a,p);if(!direct&&!p.found)++misses;}++checked;}
int main(int argc,char**argv){try{std::mt19937 r(562172);for(size_t n:{0u,1u,2u,7u,8u,15u,16u,31u,32u,63u,64u,127u,128u,99999u,100000u,100003u,1000000u})for(unsigned form=0;form<4;++form){V a(n);for(auto&v:a){auto x=uint32_t(r());v=form==0?x:form==1?x%8:form==2?0xa5a50000u|(x&255):0x80000000u|(x&65535);}check(a);}for(int form=0;form<4;++form){V a(100003);for(size_t i=0;i<a.size();++i)a[i]=form==0?uint32_t(i):form==1?uint32_t(a.size()-i):form==2?UINT32_MAX: uint32_t(i%8)*0x11111111u;check(a);}for(size_t pos:{0u,50001u,100002u}){V a(100003);for(auto&v:a)v=r()%8;a[pos]=0x80000000u;check(a);}V rare(100003);for(size_t i=0;i<rare.size();++i)rare[i]=uint32_t(r()%8)*0x11111111u;for(size_t pos:{0u,50001u,100002u}){auto a=rare;a[pos]^=1;check(a);}V extreme(100003);for(auto&v:extreme){auto z=r()%3;v=z==0?0:z==1?UINT32_MAX:UINT32_MAX-1;}check(extreme);size_t audited=0;for(int j=1;j<argc;++j){audit(load(argv[j]));++audited;}std::cout<<"PASS full_inputs="<<checked<<" full_output_checks="<<checked*9<<" metadata_inputs="<<audited<<" proof_hits="<<hits<<" proof_misses_on_mixed="<<misses<<" all_decisions_equal=true UINT32_MAX_and_rare_mixed=true\n";}catch(const std::exception&e){std::cerr<<e.what();return 1;}}
