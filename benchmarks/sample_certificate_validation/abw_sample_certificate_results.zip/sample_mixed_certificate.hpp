// Experimental exact sample witness; frozen public ABW is unchanged.
#pragma once
#include "skip_only.hpp"
namespace sample_certificate {
using namespace abw::detail;
struct Proof {bool found=false;std::size_t bucket=0,examined=0;uint32_t first=0,second=0;};
inline decision choose(const array_type& a, Proof& proof) {
    proof=Proof{};
    decision d;
    if (a.size() < 100000) return d;
    const auto order = probe(a);
    // Keep ordered/native exits unless sampled variation is nonzero and within 8 bits.
    if (order.ordered && (order.variation == 0 || order.variation > 255u)) return d;
    // Ordered low-byte exception: detailed sample frequency cannot affect dispatch.
    if (order.ordered) {
        value_type difference = 0;
        const value_type reference = a[0];
        for (std::size_t i = 1; i < a.size(); ++i) difference |= a[i] ^ reference;
        if (!difference) { d.selected = strategy::skip; return d; }
        if (bit_width(difference) <= 8) {
            d.selected = strategy::active8; d.bits = 8; d.shift = 0;
        }
        return d;
    }

    const auto m = std::min<std::size_t>(a.size() - 1,
                                        a.size() < 1000000 ? 512 : 2048);
    array_type values(m);
    const auto summary = collect_sample(a, values, m);
    const bool duplicate = 1 - double(summary.distinct) / m >= .5 ||
                           double(summary.mode) / m >= .1;
    d.bits = duplicate ? 8 : 12;
    // An actual sampled bit-31 difference proves the full uint32 width is 32.
    // Only zero/nonzero and bit_width are used below; lower OR bits are unused.
    value_type difference = order.variation & 0x80000000u;
    if (!difference) {
        for (std::size_t i = 1; i < a.size(); ++i) difference |= a[i] ^ a[0];
    }
    if (!difference) {
        d.selected = strategy::skip;
        return d;
    }
    const auto width = bit_width(difference);
    d.shift = width > d.bits ? width - d.bits : 0;
    if (width <= 8) {
        // Exact whole-array certificate; bypass entropy only for this direct path.
        d.bits = 8;
        d.shift = 0;
        d.selected = strategy::active8;
        return d;
    }
    // A sampled certificate alone cannot authorize partitioning an ordered input.
    if (order.ordered) return d;
    const value_type mask = (1u << d.bits) - 1;
    std::vector<std::size_t> counts(1u << d.bits);
    for (const auto value : values) ++counts[(value >> d.shift) & mask];
    double entropy = 0;
    for (const auto count : counts) {
        if (count) {
            const double p = double(count) / m;
            entropy -= p * std::log2(p);
        }
    }
    if (entropy >= (duplicate ? 1 : 4))
        d.selected = duplicate ? strategy::active8 : strategy::active12;
    // Reuse the now-consumed entropy histogram; no new allocation or full scan.
    // Zero-shift buckets are already exact values, so no collision is possible.
    if ((d.selected == strategy::active8 || d.selected == strategy::active12) && d.shift != 0) {
        std::fill(counts.begin(), counts.end(), std::size_t(0));
        for (const auto value : values) {
            ++proof.examined;
            const std::size_t bucket = (value >> d.shift) & mask;
            const std::size_t encoded = std::size_t(value) + 1;
            auto& slot = counts[bucket];
            if (!slot) slot = encoded;
            else if (slot != encoded) {
                proof.found = true; proof.bucket = bucket;
                proof.first = static_cast<value_type>(slot - 1); proof.second = value;
                break;
            }
        }
    }

    return d;
}

template<class Backend>
inline bool sort(array_type& a,Backend backend) {
    Proof proof;const auto d=choose(a,proof);
    if(d.selected==strategy::skip)return false;
    if(d.selected==strategy::native || proof.found){backend(a);return false;}
    if(skip_only::try_direct(a,d.bits,d.shift))return true;
    backend(a);return false;
}
} // namespace sample_certificate
