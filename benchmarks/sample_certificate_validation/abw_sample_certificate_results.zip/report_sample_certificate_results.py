from pathlib import Path
import json,statistics as st,math,csv,zipfile,hashlib,shutil
w=Path(__file__).resolve().parent;root=w.parent.parent;o=root/'outputs/abw_sample_certificate_comparison'
p=json.loads((o/'protocol.json').read_text());s=json.loads((o/'sample_certificate_summary.json').read_text());rows=s['inputs'];done=json.loads((o/'completion.json').read_text());assert done['status']=='complete'
raw=[json.loads(l) for k in range(3) for l in (o/f'session{k}.jsonl').read_text().splitlines()];assert len(raw)==198 and sum(len(x['result']['runs']) for x in raw)==6336
for row in rows:
 rr=[x for x in raw if x['name']==row['name']];ratios=[]
 for x in rr:
  runs=x['result']['runs'];a=st.median(t['ms'] for t in runs if t['method']=='avx2');b=st.median(t['ms'] for t in runs if t['method']=='old_skip_avx2');ratios.append(b/a)
 row['old_over_avx2']=st.median(ratios);row['old_avx2_process_ratios']=ratios
gm=lambda a:math.exp(st.mean(math.log(x) for x in a));groups=s['groups']
for label in groups:
 rs=[x for x in rows if label=='all66' or x['group']==label or label=='real18' and x['group'] in ['development_real','new_real'] or label=='direct' and x['direct'] or label=='mixed' and x['mixed'] or label=='native_skip' and not x['direct'] and not x['mixed'] or label=='witness' and x['sample_witness'] or label=='no_witness' and not x['sample_witness']]
 groups[label]['old_over_avx2']=gm([x['old_over_avx2'] for x in rs])
s['worst_vs_old']=sorted(rows,key=lambda x:x['candidate_over_old_skip_avx2'],reverse=True)[:5];s['worst_vs_avx2']=sorted(rows,key=lambda x:x['candidate_over_avx2'],reverse=True)[:5]
s['nominal_vs_old']=dict(faster=sum(x['candidate_over_old_skip_avx2']<1 for x in rows),slower=sum(x['candidate_over_old_skip_avx2']>1 for x in rows));s['nominal_vs_avx2']=dict(faster=sum(x['candidate_over_avx2']<1 for x in rows),slower=sum(x['candidate_over_avx2']>1 for x in rows))
(o/'sample_certificate_summary.json').write_text(json.dumps(s,indent=2))
with (o/'sample_certificate_input_results.csv').open('w',newline='') as f:wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
report='''# Exact sample mixed-bucket certificate: AVX2 skip-only comparison

## What changed

Experimental copy only. Same frozen ABW decision, sample positions/seeds,
thresholds and selected bit interval. After the original entropy decision,
if the selected active interval has nonzero shift, reuse the already collected
sample and the now-consumed entropy histogram. Clear that histogram and store
size_t(value)+1 as the first value per bucket, with0 denoting empty. The existing
64-bit size_t contract safely represents UINT32_MAX+1. Two different actual
sample values in one final bucket prove exact direct output is impossible.
Then call the whole-input AVX2 backend immediately, without the full count/
purity pass. No extra allocation, sample draw, whole-input scan or threshold.

Zero-shift buckets already identify exact values, so do not run the proof there.
Native/skip paths retain their decisions; entropy rejection does not run the
extra proof. Missing sample evidence retains the original full count/purity
verification. The existing width scan is still performed where required to
determine the final bucket interval. Full mixed ABW->pdq, its policy and
workspace implementation are unchanged. This experiment targets skip-only
fallback cost; it does not change IPv4's full-partition policy.

## Checks and measurement

Pre-run safety:79 inputs/711 full-output comparisons across pdq, Spreadsort,
AVX2 and old/new wrappers. Independent std::map bucket witness checks,
UINT32_MAX, boundary lengths, rare mixed values not seen in samples (3 cases)
and all66 original strategy/bit-interval comparisons pass. Missing evidence
correctly falls back to the original full inspection.

Windows11/i5-14500; LLVM-MinGW Clang23.1.5/libc++ UCRT; Boost1.90.0,
x86-simd-sort v7.0 commit8a7208187d99f0cb67e38c57ab1c7c85aad07aca. Common
C++17 -O3 -DNDEBUG -mavx2 -mno-avx512f -mbmi -static -pthread. Single-thread,
AVX2 only. Same unchanged66 inputs: real9+new real9+synthetic42+IPv4_6.
Same binary, shared fixed uint32 scratch/common noinline pointer timer. Load,
restore and audits outside timing; complete frontend/backend API costs inside.
Every sorted array is checked against the full hashed expected array. Four
ABBA/BAAB blocks per pair, shuffled comparator order, three fresh-process
sessions/input:198 processes/6,336 timed sorts. Warm repeated-call condition.
Source/executable/input/expected hashes pass before and after; choices, direct
output and evidence are stable across processes. No input filtering or tuning.

Primary ratios: same-pair call medians/process, median3 process ratios/input,
equal-input geometric mean. Original skip-only/backend ratios are computed
from each method's same-process medians in the two pairs, then median3; they
are separately labeled. Times are median3 process medians within each pair.
All-input ratios weight42 synthetics equally with each other column. No
workload prevalence or other-platform claim is attached to this average.

## Geometric mean time ratios

Below1 means faster. Old and candidate refer to skip-only AVX2 wrappers.

| Group | N | Old/AVX2 | Candidate/AVX2 | Candidate/old |
|---|---:|---:|---:|---:|
'''
for label,q in groups.items():report+='| '+label+f" | {q['n']} | {q['old_over_avx2']:.5f} | {q['avx2']:.5f} | {q['old_skip_avx2']:.5f} |\n"
report+='\n## All66 input times and paired ratios\n\n| Input | Path | Sample witness | AVX2 ms | Candidate paired/AVX2 ms | Candidate/AVX2 | Old ms | Candidate paired/old ms | Candidate/old |\n|---|---|---|---:|---:|---:|---:|---:|---:|\n'
for x in rows:report+='| '+x['name']+' | '+('direct' if x['direct'] else 'mixed fallback' if x['mixed'] else 'native/skip')+f" | {x['sample_witness']} | {x['avx2_ms']:.5f} | {x['candidate_paired_with_avx2_ms']:.5f} | {x['candidate_over_avx2']:.5f} | {x['old_skip_avx2_ms']:.5f} | {x['candidate_paired_with_old_skip_avx2_ms']:.5f} | {x['candidate_over_old_skip_avx2']:.5f} |\n"
report+='\n## Largest regressions retained\n\n| Comparator | Input | Candidate/comparator | Three process ratios |\n|---|---|---:|---|\n'
for base,key in [('old_skip_avx2','worst_vs_old'),('avx2','worst_vs_avx2')]:
 for x in s[key]:report+=f"| {base} | {x['name']} | {x['candidate_over_'+base]:.5f} | "+', '.join(f'{v:.4f}' for v in x['candidate_'+base+'_process_ratios'])+' |\n'
report+='\n## Separate sample-bucket diagnosis of the full mixed policy\n\nThe pre-run diagnostic used exactly the final selected bits/shift and existing\nsample on the27 mixed inputs from the earlier full-ABW run:22 faster than skip,\n5 slower. Maximum sample occupancy ranges overlap: winners0.195-67.822%\n(median0.415%), losers21.094-83.594% (median80.518%). IPv4 destinations occupy\n80.5-83.6%, sources57.0-67.8%. All six use8-bit buckets/shift24 and entropy\ncutoff1. The destination skew is directly observed; no threshold was added.\nMixed evidence is found on all27. See sample_bucket_diagnosis.csv and JSON\nfor exact witness values and the linked earlier full/skip timings. This is\nseparate from the performance effects of the skip-only certificate.\n'
report+='\n## Reproduction\n\nFrom the original workspace root after compiling using comparison_build.json:\n\n```\npython work/abw_sample_certificate/run_sample_certificate_comparison.py\n```\n\nThe output directory must not already exist. The archive includes raw sessions,\nall-input CSV, frozen headers, exact certificate source, build commands, short\nsafety tests/results, source/input hashes, earlier bucket diagnosis and pinned\nx86 source ZIP. Boost/compiler/dataset binaries are not bundled. Plan status\nis the frozen prepared state; completion.json records the completed run.\nPublic ABW remains unchanged and no release is issued by this experiment.\n'
(o/'sample_certificate_report.md').write_text(report)
for f in w.glob('*'):
 if f.is_file() and f.suffix!='.exe':shutil.copyfile(f,o/f.name)
for f in (root/'outputs/abw_sample_certificate').glob('*'):
 if f.is_file():shutil.copyfile(f,o/f.name)
frozen=o/'frozen';frozen.mkdir(exist_ok=True)
for n in ['abw_reference.hpp','skip_only.hpp','source_provenance.json','x86-simd-sort-v7.0.zip']:shutil.copyfile(root/'work/abw_backends'/n,frozen/n)
shutil.copyfile(root/'work/abw_v020/environment.json',o/'environment.json');shutil.copyfile(root/'outputs/abw_v020_candidate/LICENSE',o/'ABW_LICENSE');shutil.copyfile(root/'work/abw_backends/x86-simd-sort-7.0/LICENSE.md',o/'x86_LICENSE.md')
manifest={f.relative_to(o).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in o.rglob('*') if f.is_file() and f.name!='package_manifest.json'};(o/'package_manifest.json').write_text(json.dumps(manifest,indent=2))
path=root/'outputs/abw_sample_certificate_results.zip'
with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED) as z:
 for f in o.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(o))
print(json.dumps(dict(groups=groups,worst_vs_old=s['worst_vs_old'],nominal_vs_old=s['nominal_vs_old'],nominal_vs_avx2=s['nominal_vs_avx2']),indent=2));print('Archive',path,path.stat().st_size)
