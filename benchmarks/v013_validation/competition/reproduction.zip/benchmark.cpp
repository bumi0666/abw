#include <abw/abw.hpp>
#include "BD.hpp"
#include <boost/sort/spreadsort/spreadsort.hpp>
#include "cafs2.hpp"
#include <windows.h>
#include <chrono>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <random>
#include <stdexcept>
#include <string>
#include <limits>
using U=uint32_t;using V=std::vector<U>;using I=std::vector<int32_t>;using Clock=std::chrono::steady_clock;
V load(const char*p){std::ifstream f(p,std::ios::ate|std::ios::binary);if(!f)throw std::runtime_error("load");auto n=f.tellg();if(n<0||n%4)throw std::runtime_error("size");V a(size_t(n)/4);f.seekg(0);f.read(reinterpret_cast<char*>(a.data()),n);if(!f)throw std::runtime_error("read");return a;}
void pdq(V&a){boost::sort::pdqsort(a.begin(),a.end());}void spread(V&a){boost::sort::spreadsort::integer_sort(a.begin(),a.end());}
void cafsu(V&a){cafs2::cafs_sort(a,[](auto&v){boost::sort::pdqsort(v.begin(),v.end());});}void cafsi(I&a){cafs2::cafs_sort(a,[](auto&v){boost::sort::pdqsort(v.begin(),v.end());});}
void counting(V&a){if(a.empty())return;auto mm=std::minmax_element(a.begin(),a.end());U lo=*mm.first,hi=*mm.second;uint64_t range=uint64_t(hi)-lo+1;if(range*8>67108864)throw std::runtime_error("counting cap");std::vector<uint64_t>counts(size_t(range),0);for(U v:a)counts[size_t(v-lo)]++;auto it=a.begin();for(size_t j=0;j<counts.size();j++){std::fill_n(it,counts[j],U(uint64_t(lo)+j));it+=counts[j];}}
using Fn=void(*)(V&);
Fn functions[]={&variant_D::sort,&abw::sort,&pdq,&spread,&cafsu,nullptr,&counting};
const char*names[]={"BD","v012","pdq","spread","CAFS_u32","CAFS_i32","counting"};
template<class T>__attribute__((noinline)) double measured(void(*fn)(std::vector<T>&),const std::vector<T>&src,const V&expected,std::vector<T>&scratch){std::copy(src.begin(),src.end(),scratch.begin());auto t=Clock::now();fn(scratch);double ms=std::chrono::duration<double,std::milli>(Clock::now()-t).count();if(!std::equal(scratch.begin(),scratch.end(),expected.begin(),[](T x,U y){return uint32_t(x)==y;}))throw std::runtime_error("incorrect");return ms;}
int main(int argc,char**argv){try{if(argc!=6)throw std::runtime_error("input expected seed signed_ok count_ok");DWORD_PTR p,s;if(!GetProcessAffinityMask(GetCurrentProcess(),&p,&s)||!SetProcessAffinityMask(GetCurrentProcess(),p&(~p+1)))throw std::runtime_error("affinity");auto a=load(argv[1]),e=load(argv[2]);if(a.size()!=e.size())throw std::runtime_error("sizes");bool signedok=std::stoi(argv[4])!=0,countok=std::stoi(argv[5])!=0;auto mm=std::minmax_element(a.begin(),a.end());if(signedok&&*mm.second>U(INT32_MAX))throw std::runtime_error("signed unsupported");if(countok&&(uint64_t(*mm.second)-*mm.first+1)*8>67108864)throw std::runtime_error("counting unsupported");V scratch(a.size());I isrc,iscratch;if(signedok){isrc.assign(a.begin(),a.end());iscratch.resize(a.size());}auto uptr=scratch.data();auto iptr=iscratch.data();std::vector<int>others={1,2,3,4};if(signedok)others.push_back(5);if(countok)others.push_back(6);
 // Same preexisting small warmup families; values are representable for both CAFS APIs.
 for(int kind=0;kind<3;kind++){V w(100000),sw(100000);std::mt19937 rr(183+kind);for(size_t j=0;j<w.size();j++)w[j]=kind==0?rr()%1024:kind==1?U(j):rr()%8;auto ex=w;std::sort(ex.begin(),ex.end());I iw(w.begin(),w.end()),si(w.size());measured(functions[0],w,ex,sw);for(int m:others){if(m==5)measured(&cafsi,iw,ex,si);else measured(functions[m],w,ex,sw);}}
 auto call=[&](int m){double ms=m==5?measured(&cafsi,isrc,e,iscratch):measured(functions[m],a,e,scratch);if(scratch.data()!=uptr||iscratch.data()!=iptr)throw std::runtime_error("buffer moved");return ms;};call(0);for(int m:others)call(m);
 auto b=abw::detail::choose(a);auto c=variant_D::detail::choose(a);
 if(int(b.selected)!=int(c.selected))throw std::runtime_error("sort route changed");
 bool active=b.selected==abw::detail::strategy::active8||b.selected==abw::detail::strategy::active12;
 if(active&&(b.bits!=c.bits||b.shift!=c.shift))throw std::runtime_error("active bit interval changed");
 bool baseline_direct=false,candidate_direct=false;
 {auto audit=a;if(active)baseline_direct=abw::detail::partition_and_sort(audit,b.bits,b.shift);else abw::sort(audit);if(audit!=e)throw std::runtime_error("baseline audit");std::copy(a.begin(),a.end(),audit.begin());if(active)candidate_direct=variant_D::detail::partition_and_sort(audit,c.bits,c.shift);else variant_D::sort(audit);if(audit!=e||baseline_direct!=candidate_direct)throw std::runtime_error("candidate audit");}
 bool changed_branch=false;if(a.size()>=100000){auto probe=abw::detail::probe(a);changed_branch=probe.ordered&&probe.variation&&probe.variation<=255;}
std::mt19937 rng(unsigned(std::stoul(argv[3])));
 std::cout<<std::setprecision(15)<<"{\"baseline_bits\":"<<b.bits<<",\"baseline_shift\":"<<b.shift<<",\"baseline_direct\":"<<(baseline_direct?"true":"false")<<",\"candidate_direct\":"<<(candidate_direct?"true":"false")<<",\"changed_branch\":"<<(changed_branch?"true":"false")<<",\"verified\":true,\"u32_buffer_mod4096\":"<<(uintptr_t(uptr)%4096)<<",\"i32_buffer_mod4096\":"<<(uintptr_t(iptr)%4096)<<",\"baseline_route\":"<<int(b.selected)<<",\"candidate_route\":"<<int(c.selected)<<",\"candidate_bits\":"<<c.bits<<",\"candidate_shift\":"<<c.shift<<",\"runs\":[";bool first=true;
 for(int block=0;block<4;block++){std::shuffle(others.begin(),others.end(),rng);for(int m:others){int order[4]={0,m,m,0};if(block%2){order[0]=m;order[1]=0;order[2]=0;order[3]=m;}for(int pos=0;pos<4;pos++){int who=order[pos];double ms=call(who);if(!first)std::cout<<",";first=false;std::cout<<"{\"block\":"<<block<<",\"pair\":\""<<names[m]<<"\",\"position\":"<<pos<<",\"method\":\""<<names[who]<<"\",\"ms\":"<<ms<<"}";}}}std::cout<<"]}";
 }catch(const std::exception&e){std::cerr<<e.what();return 1;}return 0;}
