from pathlib import Path
import json,hashlib,shutil,subprocess,re
w=Path('work/abw_v013_bd_competition');o=Path('outputs/abw_v013_bd_competition');w.mkdir(exist_ok=True);o.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pub=Path('outputs/abw/include/abw/abw.hpp');assert sha(pub)=='ee50cb2be4060f4253c5693b944afedd7f97afcdb4e7ee79a19fe2e7a6b6675e'
inc=w/'include/abw';inc.mkdir(parents=True,exist_ok=True);shutil.copyfile(pub,inc/'abw.hpp');shutil.copyfile('work/abw_v013_hash/D.hpp',w/'BD.hpp')
src=Path('work/abw_v013_competition/benchmark.cpp').read_text().replace('#include "B.hpp"','#include "BD.hpp"').replace('variant_B::','variant_D::').replace('"B","v012"','"BD","v012"')
(w/'benchmark.cpp').write_text(src,encoding='utf-8')
cmd=json.loads(Path('work/abw_v013_competition/build.json').read_text())['command'];cmd=[x.replace(str(Path('work/abw_v013_competition').resolve()),str(w.resolve())) for x in cmd]
q=subprocess.run(cmd,capture_output=True,text=True,check=True);(w/'build.json').write_text(json.dumps(dict(command=cmd,stdout=q.stdout,stderr=q.stderr,cafs_commit='13488afef446ae88e7ad631ec6f862def896094a',flags_equal_prior_competition=True),indent=2))
runner=Path('work/abw_v013_competition/run.py').read_text().replace('abw_v013_competition','abw_v013_bd_competition').replace("['B','v012'","['BD','v012'").replace("w/'B.hpp'","w/'BD.hpp'").replace("'work/abw_v013_first/B.hpp'","'work/abw_v013_hash/D.hpp'").replace("'benchmark.cpp','B.hpp'","'benchmark.cpp','BD.hpp'").replace('Only frozen B candidate','Only frozen B+D candidate').replace('B/competitor','BD/competitor')
runner=runner.replace("['prepare.py','run.py'", "['setup.py','run.py'")
(w/'run.py').write_text(runner,encoding='utf-8')
analyzer=Path('work/abw_v013_competition/analyze.py').read_text().replace('abw_v013_competition','abw_v013_bd_competition').replace('B_','BD_')
analyzer=re.sub(r'\bB\b','BD',analyzer)
analyzer=analyzer.replace('Frozen BD only','Frozen B+D only').replace("B source bytes equal the previous accepted B.","B+D bytes equal the previously tested D.hpp.").replace('BD source bytes equal the previous accepted BD.','B+D source bytes equal the previously tested D.hpp.')
(w/'analyze.py').write_text(analyzer,encoding='utf-8')
print('Built byte-identical B+D with unchanged seven-sorter harness/options/seeds')
