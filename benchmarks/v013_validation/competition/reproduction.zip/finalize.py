from pathlib import Path
import json,csv,hashlib,shutil,zipfile
w=Path('work/abw_v013_bd_competition');o=Path('outputs/abw_v013_bd_competition')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proto=json.loads((o/'protocol.json').read_text())
metrics=json.loads((o/'summary.json').read_text())
rows=list(csv.DictReader((o/'input_results.csv').open()))
by={x['name']:x for x in rows}
raw=[json.loads(l) for s in range(3) for l in (o/f'session{s}.jsonl').read_text().splitlines()]
assert len(raw)==180 and sum(len(x['result']['runs']) for x in raw)==13920
assert all(x['result']['verified'] and x['result']['baseline_route']==x['result']['candidate_route'] and x['result']['baseline_direct']==x['result']['candidate_direct'] for x in raw)
assert all(sha(Path(p))==h for p,h in proto['source_hashes'].items())
assert (w/'BD.hpp').read_bytes()==Path('work/abw_v013_hash/D.hpp').read_bytes()
for c in proto['cases']:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:
  assert sha(Path(c['input_directory'])/(c['name']+ext))==c[key]
text='''
## Final decision: recommend frozen B+D for v0.1.3 integration

The final seven-method competition retains the approximately 2% improvement
target: whole60 B+D/v0.1.2 geometric mean time ratio **0.97308**, a **2.69%**
decrease. Same-pair medians give0.97279 (2.72% decrease) and block-paired0.97316
(2.68% decrease). Original real9 decreases2.36%, new real9 2.28%, synthetic42
2.85%. These are this run's matched results; no historical aggregate is pooled.
The choice is to retain B+D without any further optimization or threshold tuning.
Public header integration, platform CI and release were not performed here.

### Competitive interpretation

Against pdqsort, B+D reaches1.8526x on original real9,1.4995x on new real9,
1.4794x on synthetic42 and1.5333x overall. CAFS u32 remains faster overall:
B+D's time is2.96% longer, reduced from v0.1.2's5.82% gap on the same60.
B+D is1.85% faster on original real9,7.41% slower on new real9 and3.09%
slower on synthetic42 than CAFS u32. Against CAFS i32 it is4.47% slower on
the supported24; that subset must not be compared with all60 as if identical.

B+D has the lowest displayed median on9/18 real inputs (4 original,5 new)
and18/42 synthetic inputs. Many are near ties. With the descriptive >5% margin
against every eligible non-ABW implementation, real winners are Covertype cover,
elevation, Census industry, sex, Skin red and Taxi vendor. Including near-identical
v0.1.2, only elevation and Skin red meet that real-input margin. These counts
describe this local sample, not statistical superiority across CPUs.

### Regression checks (all measurements retained)

The prior NASA bytes4.8% loss was D versus B-only. This run compares B+D with
released v0.1.2, so it does not directly repeat that exact contrast. The loss
does not recur versus the current release: main ratio0.97585 (-2.42%), pair-only
0.97646, block-paired0.98778. Its three primary process ratios are1.01938,
0.97585,0.96759; pair-only1.00141,0.97646,0.95307. The input is still slower
than CAFS (u32 ratio1.10594, i32 ratio1.70112), so this is not a repaired
competitive weakness.

Maximum primary regression versus v0.1.2 is10M sorted: **+3.61%**, process
ratios1.03611,0.97516,1.05008. The pair-only median is+5.24% (process ratios
1.06995,0.99762,1.05243), block-paired+3.44%. Slowdown is present in2/3
processes; retain it as a small observed regression. This input uses the native
route and skips both changed analysis paths. No cause is established, and no
same-function A/A control was added to this competition. Do not attribute the
loss to hash-table work or dismiss it as measured noise.

Other previously flagged cases:1M narrow duplicates primary+2.06%, pair-only
-0.60%, block-paired-0.15% (no consistent prior6.8% loss);1M partial primary
-0.77%, pair-only-2.05%;1M lower-only primary-2.34%, pair-only-0.21%.
Taxi pickup zone is the largest new-real primary loss at+1.72%, pair-only
+1.80%, block-paired+3.83%; process direction varies. No input has a primary
median regression above5%; pair-only sorted exceeds5% as disclosed above.
This is not a claim that every input or process improves.

The direct-path sample-analysis gains remain clear: Covertype elevation main
time reduction13.21%, Skin red11.57%, both improve in all three processes.
The B-only bypass inputs improve3.95% (cover),2.58% (Skin label),4.42%
(Chest activity),3.13% (Taxi vendor). No new dispatch strategy is used.

### Scope, memory and limitations

All180 process audits preserve route, actual active bits/shift and direct/mixed
result. Full timed arrays match expected arrays on all13,920 calls. No unused
native metadata differences occurred on these60 inputs. The raw `changed_branch`
flag labels only B's four ordered-low-byte bypass inputs; D replaces frequency
analysis on40 inputs, not four. It is not a total-candidate-change flag.

D trades unordered_map node allocation for a fixed4096-slot table:16KiB uint32
keys plus8KiB uint16 counts in a separate noinline sample helper. The original
sample-values vector remains. The added24KiB stack payload is relevant to
small-stack callers; linear probing has a collision-dependent worst case. The
prior D exact-frequency/collision tests are retained as separate evidence, not
new measurements in this run. No fresh peak-memory profile, new collision
policy, cross-CPU validation of B+D, or statistical equivalence claim is made.

## Regression detail: process ratios

Ratios below are B+D/v0.1.2 (lower is better), in session0/1/2 order.

| Input | Primary process ratios | Same-pair process ratios |
|---|---|---|
'''
targets=['nasa_bytes','synthetic_10000000_sorted','synthetic_1000000_duplicates_narrow','synthetic_1000000_partial','synthetic_1000000_lower_only','taxi_pickup_zone']
for name in targets:
 x=by[name]
 text+=f"| {name} | {', '.join(f'{v:.5f}' for v in json.loads(x['BD_over_v012_sessions']))} | {', '.join(f'{v:.5f}' for v in json.loads(x['BD_pairmedian_v012_sessions']))} |\n"
text+='\n## Largest remaining competitive losses\n\n| Input | B+D/pdq time | B+D/CAFS u32 time | Lowest displayed median |\n|---|---:|---:|---|\n'
for x in sorted(rows,key=lambda x:float(x['BD_over_CAFS_u32']),reverse=True)[:8]:
 text+=f"| {x['name']} | {float(x['BD_over_pdq']):.4f} | {float(x['BD_over_CAFS_u32']):.4f} | {x['winner']} |\n"
text+='''
## Reproduction and artifacts

Raw `session0/1/2.jsonl`, per-call times, process medians, paired blocks,
per-input results, summary, complete source/input SHA-256 protocol, compiler
command and source snapshots are included. No raw record was filtered/edited.
The input arrays and Boost/toolchain are not bundled. Restore the original
real/synthetic inputs and new-real9 from the public repository documentation;
validate against all60 hashes before timing. Source provenance and manifests
are copied into input_provenance/. All original order/values/seeds are retained.

Original Windows workspace commands (fresh outputs required):

```powershell
python work/abw_v013_bd_competition/setup.py
python work/abw_v013_bd_competition/run.py
python work/abw_v013_bd_competition/analyze.py
python work/abw_v013_bd_competition/finalize.py
```

setup.py reconstructs this candidate comparison from the included prior B-only
competition scripts/source/build, released header and accepted D.hpp. Recreate
their original paths (reference_paths.json) or adapt paths only. Preserve source
bytes, flags, eligibility, seeds and timing boundaries. The build command also
permits compiling benchmark.cpp directly with the included headers and CAFS,
external Boost1.90.0 and LLVM-MinGW. This harness is Windows-specific.

The measured runner completed all180 jobs and post-run source/input hash checks,
then its artifact-copy step referred to absent prepare.py. That packaging-only
reference was corrected to setup.py; all source/hash audits were independently
rechecked during finalization. No timing rerun or raw-data edit was needed.
The initial analyzer report is supplemented by this authored assessment.
No follow-up timing run or additional optimizer was introduced.
'''
p=o/'report.md';report=p.read_text(encoding='utf-8')
report=report.replace('C++20). This differs from the C++17 ABI-only first BD/P experiments; this run\'s\ncurrent BD/v0.1.2 comparison is the evidence, not pooled historical timings.',"C++20). This run's matched BD/v0.1.2 comparison is the evidence; no\nhistorical timings are pooled.")
report=report.replace('## Changed branch (same dispatch)','## B ordered-bypass inputs (not all D-affected inputs; same dispatch)')
p.write_text(report+text,encoding='utf-8')
for name in ['setup.py','run.py','analyze.py','finalize.py','benchmark.cpp','BD.hpp','build.json']:
 shutil.copyfile(w/name,o/name)
shutil.copytree(w/'include',o/'include',dirs_exist_ok=True)
refs={'work/abw_v013_competition/benchmark.cpp':'prior_competition_reference.cpp','work/abw_v013_competition/build.json':'prior_competition_build.json','work/abw_v013_competition/run.py':'prior_competition_run.py','work/abw_v013_competition/analyze.py':'prior_competition_analyze.py','work/abw_v013_hash/D.hpp':'prior_D_reference.hpp','outputs/abw_v013_first/protocol.json':'prior60_manifest_reference.json'}
for src,name in refs.items():shutil.copyfile(src,o/name)
(o/'reference_paths.json').write_text(json.dumps(refs,indent=2))
v=o/'vendor';v.mkdir(exist_ok=True)
for name in ['cafs.hpp','cafs2.hpp','cafs_LICENSE','cafs_README.md']:shutil.copyfile(Path('work/ABW_realworld/vendor')/name,v/name)
for name in ['LICENSE','THIRD_PARTY_NOTICES.md']:shutil.copyfile(Path('outputs/abw')/name,o/name)
prov=o/'input_provenance';prov.mkdir(exist_ok=True)
for src,name in [('work/ABW_realworld/benchmark_manifest.json','original51_manifest.json'),('work/abw_new_real_v012/input_manifest.json','new9_manifest.json')]:shutil.copyfile(src,prov/name)
(o/'validation.json').write_text(json.dumps(dict(inputs=60,processes=180,timed_correct_sorts=13920,all_routes_active_intervals_and_direct_results_match=True,native_metadata_differences=[x['name'] for x in rows if x['metadata_diff']=='True'],source_and_input_hashes_verified=True,BD_frozen=True,public_header_unchanged=True,no_github_or_release_changes=True,no_additional_followup=True,verdict='Recommend frozen B+D integration; disclose sorted-input regression and single-CPU limit'),indent=2))
files={p.relative_to(o).as_posix():sha(p) for p in o.rglob('*') if p.is_file() and p.name!='package_manifest.json'}
(o/'package_manifest.json').write_text(json.dumps(files,indent=2))
archive=Path('outputs/abw_v013_bd_competition_repro.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in o.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(o))
with zipfile.ZipFile(archive) as z:
 for name,h in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
print('PASS:180 processes/13920 correct sorts, frozen sources/input hashes and ZIP hashes;',archive.stat().st_size,'bytes')
