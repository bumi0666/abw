from pathlib import Path
import json,csv,math,statistics as st
o=Path('outputs/abw_v013_bd_competition');proto=json.loads((o/'protocol.json').read_text());cases=proto['cases'];raw=[json.loads(l) for p in sorted(o.glob('session[012].jsonl')) for l in p.read_text().splitlines()];assert len(raw)==180
methods=['BD','v012','pdq','spread','CAFS_u32','CAFS_i32','counting'];med={};sm=[];pairs=[];pr={};pm={}
for x in raw:
 name=x['name'];s=x['session'];c=next(c for c in cases if c['name']==name);v=x['result'];assert v['verified'] and v['baseline_route']==v['candidate_route'] and v['baseline_direct']==v['candidate_direct']
 for m in c['methods']:
  t=st.median(z['ms'] for z in v['runs'] if z['method']==m);med[name,s,m]=t;sm.append(dict(name=name,group=x['group'],session=s,method=m,ms=t))
 for m in c['methods'][1:]:
  aa=[z['ms'] for z in v['runs'] if z['pair']==m and z['method']=='BD'];bb=[z['ms'] for z in v['runs'] if z['pair']==m and z['method']==m];pm[name,s,m]=st.median(aa)/st.median(bb)
  ratios=[]
  for block in range(4):
   a=st.mean(z['ms'] for z in v['runs'] if z['pair']==m and z['block']==block and z['method']=='BD');b=st.mean(z['ms'] for z in v['runs'] if z['pair']==m and z['block']==block and z['method']==m);ratios.append(a/b);pairs.append(dict(name=name,session=s,method=m,block=block,BD_ms=a,other_ms=b,time_ratio=a/b))
  pr[name,s,m]=st.median(ratios)
rows=[]
for c in cases:
 name=c['name'];v=next(x['result'] for x in raw if x['name']==name);q=dict(name=name,group=c['evaluation_group'],n=c['n'],changed_branch=v['changed_branch'],route=v['candidate_route'],direct=v['candidate_direct'],baseline_bits=v['baseline_bits'],baseline_shift=v['baseline_shift'],BD_bits=v['candidate_bits'],BD_shift=v['candidate_shift'],metadata_diff=(v['baseline_bits'],v['baseline_shift'])!=(v['candidate_bits'],v['candidate_shift']))
 for m in c['methods']:
  q[m+'_ms']=st.median(med[name,s,m] for s in range(3));q[m+'_speedup_pdq']=st.median(med[name,s,'pdq']/med[name,s,m] for s in range(3));q['BD_over_'+m]=st.median(med[name,s,'BD']/med[name,s,m] for s in range(3));q['v012_over_'+m]=st.median(med[name,s,'v012']/med[name,s,m] for s in range(3))
  if m!='BD':q['BD_pairmedian_over_'+m]=st.median(pm[name,s,m] for s in range(3));q['BD_blockpaired_over_'+m]=st.median(pr[name,s,m] for s in range(3))
 q['BD_over_v012_sessions']=[med[name,s,'BD']/med[name,s,'v012'] for s in range(3)];q['BD_pairmedian_v012_sessions']=[pm[name,s,'v012'] for s in range(3)];q['BD_v012_delta_ms']=st.median(med[name,s,'BD']-med[name,s,'v012'] for s in range(3));q['winner']=min(c['methods'],key=lambda m:q[m+'_ms']);q['clear_best_all']=all(q['BD_over_'+m]<.95 for m in c['methods'] if m!='BD');q['clear_best_non_ABW']=all(q['BD_over_'+m]<.95 for m in c['methods'] if m not in ['BD','v012']);rows.append(q)
gm=lambda v:math.exp(st.mean(math.log(x) for x in v));metrics={}
for label,ss in [(g,[x for x in rows if x['group']==g]) for g in ['development_real','new_real','synthetic']]+[('all60',rows)]:
 z={}
 for m in methods:
  sub=[x for x in ss if m+'_ms' in x];z[m]=dict(eligible=len(sub),gm_speedup_pdq=gm([x[m+'_speedup_pdq'] for x in sub]),gm_BD_time_over_method=gm([x['BD_over_'+m] for x in sub]),gm_v012_time_over_method=gm([x['v012_over_'+m] for x in sub]),BD_wins_ties_losses=[sum(x['BD_over_'+m]<.95 for x in sub),sum(.95<=x['BD_over_'+m]<=1.05 for x in sub),sum(x['BD_over_'+m]>1.05 for x in sub)])
  if m!='BD':z[m].update(gm_pairmedian_BD_time_over_method=gm([x['BD_pairmedian_over_'+m] for x in sub]),gm_blockpaired_BD_time_over_method=gm([x['BD_blockpaired_over_'+m] for x in sub]))
 worst=max(ss,key=lambda x:x['BD_over_v012']);z['worst_vs_v012']=dict(name=worst['name'],ratio=worst['BD_over_v012'],delta_ms=worst['BD_v012_delta_ms'],pair_ratio=worst['BD_pairmedian_over_v012'],blockpaired_ratio=worst['BD_blockpaired_over_v012']);z['nominal_BD_winners']=[x['name'] for x in ss if x['winner']=='BD'];z['clear_BD_all_winners']=[x['name'] for x in ss if x['clear_best_all']];z['clear_BD_non_ABW_winners']=[x['name'] for x in ss if x['clear_best_non_ABW']];metrics[label]=z
for name,data in [('input_results.csv',rows),('session_medians.csv',sm),('paired_blocks.csv',pairs)]:
 keys=list(dict.fromkeys(k for x in data for k in x))
 with (o/name).open('w',newline='') as f:wr=csv.DictWriter(f,fieldnames=keys);wr.writeheader();wr.writerows(data)
(o/'summary.json').write_text(json.dumps(metrics,indent=2))
report='''# ABW v0.1.3 BD candidate: final competition comparison

Date: 2026-11-13. Frozen B+D only versus byte-identical public v0.1.2 and unchanged
Boost pdqsort/Spreadsort, pinned CAFS u32/i32 and Counting. No C/C-prime, algorithm
or threshold changes. All development9 + new9 + synthetic42 retained; no new
datasets or diagnostic inputs. No GitHub/public-header/release changes.

## Conditions

Original competition harness reused: one binary, one fixed uint32 scratch and
common noinline function-pointer timer. CAFS i32 uses separate fixed int32
scratch with the exact same representable values, conversion outside timer.
Candidate BD anchored ABBA/BAAB against each competitor, four blocks each,
randomized pair order; three fresh processes per input. Original warmups.
Loading/restoration/conversion/equality/route audits outside timer; all actual
sort scans, sample allocation, histogram initialization/merge, scatter/sort,
reconstruction/copy and free inside. Uninstrumented full-call times, no outlier
filtering or timing-based exclusions.

Same local Intel i5-14500 Windows x64 first-allowed-CPU affinity, LLVM-MinGW
Clang23.1.5/libc++/UCRT, Boost1.90.0. Original competition C++20 -O3 -DNDEBUG
-mavx2 -mbmi -static -pthread flags retained for all methods (CAFS requires
C++20). This differs from the C++17 ABI-only first BD/P experiments; this run's
current BD/v0.1.2 comparison is the evidence, not pooled historical timings.
CAFS commit13488afef446ae88e7ad631ec6f862def896094a, supported scalar u32 and
specialized i32 APIs with unchanged pdq fallback. Counting is the original dense
uint64 histogram, runtime min/max and initialization inside timer, 64MiB cap.
CAFS i32 unsupported when values exceed INT32_MAX; no compression/remapping.

B+D source bytes equal the previously tested D.hpp. v0.1.2 source bytes equal the
released public header. BD must preserve v0.1.2's executable sort route, active
bits/shift and direct/mixed result. Unused native bits/shift metadata may differ
and are separately recorded. Every timed output equals the complete expected
array. Source and input/expected SHA-256 checked before/after; one CPU only.

## Estimators

Times: median method calls within process, then median of three process medians.
Primary speedups and time ratios: median same-process method-median ratios,
then geometric mean over eligible inputs. BD's main median pools its anchored
calls across competitors, matching prior competition tables. A small BD/v0.1.2
effect also has two same-pair views: ratio of the BD/v0.1.2 pair's own call
medians, and median block ratios of two-call means. All views are retained;
none is substituted after seeing the outcome. Ratios need not equal displayed
median-time quotients. Descriptive 5% bands are not significance tests.

Nominal winner = lowest displayed median among all eligible methods including
v0.1.2. Clear best = main time ratio below0.95 against every eligible method.
Clear non-ABW best excludes the near-identical v0.1.2; these categories must
not be conflated. Unsupported methods are not losses; subset denominators below.

'''
report+=f"**{sum(len(x['result']['runs']) for x in raw):,} timed sorts in180 fresh processes; all full-array, route and direct/mixed checks passed.**\n\n"
report+='## Geometric mean speedup versus pdqsort\n\n| Method | Development9 | New9 | Synthetic eligible subset (N) | All eligible subset (N) |\n|---|---:|---:|---:|---:|\n'
for m in methods:report+=f"| {m} | {metrics['development_real'][m]['gm_speedup_pdq']:.4f} | {metrics['new_real'][m]['gm_speedup_pdq']:.4f} | {metrics['synthetic'][m]['gm_speedup_pdq']:.4f} ({metrics['synthetic'][m]['eligible']}) | {metrics['all60'][m]['gm_speedup_pdq']:.4f} ({metrics['all60'][m]['eligible']}) |\n"
report+='\nDo not compare CAFS i32/Counting subset averages with the all60 ABW average as if the input sets matched. See their paired time ratios on the same subsets in summary.json.\n\n## BD/v0.1.2 time ratios\n\n| Group | Primary pooled-anchor | Pair-only medians | Block-paired |\n|---|---:|---:|---:|\n'
for g in metrics:
 q=metrics[g]['v012'];report+=f"| {g} | {q['gm_BD_time_over_method']:.5f} | {q['gm_pairmedian_BD_time_over_method']:.5f} | {q['gm_blockpaired_BD_time_over_method']:.5f} |\n"
report+='\n## Changed branch (same dispatch)\n\n| Input | v0.1.2 ms | BD ms | BD/v0.1.2 | Pair-only ratio | Block-paired ratio |\n|---|---:|---:|---:|---:|---:|\n'
for x in rows:
 if x['changed_branch']:report+=f"| {x['name']} | {x['v012_ms']:.5f} | {x['BD_ms']:.5f} | {x['BD_over_v012']:.4f} | {x['BD_pairmedian_over_v012']:.4f} | {x['BD_blockpaired_over_v012']:.4f} |\n"
report+='\n## Every input time (ms)\n\n| Input | BD | v0.1.2 | pdq | Spread | CAFS u32 | CAFS i32 | Counting | Lowest median |\n|---|---:|---:|---:|---:|---:|---:|---:|---|\n'
for x in rows:report+='| '+x['name']+' | '+' | '.join(f"{x[m+'_ms']:.5f}" if m+'_ms' in x else 'unsupported' for m in methods)+' | '+x['winner']+' |\n'
report+='\n## Nominal and clear winners\n\n'
for g,q in metrics.items():report+=f"- {g}: nominal BD winners = {', '.join(q['nominal_BD_winners']) or 'none'}; clear versus all = {', '.join(q['clear_BD_all_winners']) or 'none'}; clear versus non-ABW = {', '.join(q['clear_BD_non_ABW_winners']) or 'none'}.\n"
(o/'report.md').write_text(report,encoding='utf-8')
print(json.dumps(metrics,indent=2));print('CHANGED BRANCH');print(json.dumps([x for x in rows if x['changed_branch'] or x['BD_over_v012']>1.05],indent=2))
