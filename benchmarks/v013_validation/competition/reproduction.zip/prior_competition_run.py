from pathlib import Path
import hashlib,json,subprocess,random,shutil,platform,os
w=Path('work/abw_v013_competition');o=Path('outputs/abw_v013_competition');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cases=json.loads(Path('outputs/abw_v013_first/protocol.json').read_text())['cases'];assert len(cases)==60
for c in cases:c['methods']=['B','v012','pdq','spread','CAFS_u32']+(['CAFS_i32'] if c['cafs_i32_eligible'] else [])+(['counting'] if c['counting_eligible'] else [])
assert (w/'B.hpp').read_bytes()==Path('work/abw_v013_first/B.hpp').read_bytes()
sources=[w/'include/abw/abw.hpp',w/'B.hpp',w/'benchmark.cpp',w/'benchmark.exe',Path('work/ABW_realworld/vendor/cafs.hpp'),Path('work/ABW_realworld/vendor/cafs2.hpp'),Path('outputs/abw/include/abw/abw.hpp')]
proto=dict(cases=cases,sessions=3,blocks_per_competitor=4,timed_sorts=sum((len(c['methods'])-1)*16*3 for c in cases),source_hashes={str(p):sha(p) for p in sources},build=json.loads((w/'build.json').read_text()),environment=dict(cpu='Intel Core i5-14500',platform=platform.platform(),python=platform.python_version(),logical_cpus=os.cpu_count(),affinity='first allowed CPU',toolchain='same LLVM-MinGW Clang23.1.5/libc++/UCRT, Boost1.90.0, C++20 O3 NDEBUG AVX2 BMI static pthread'),scope='Only frozen B candidate vs released v0.1.2 and original competition implementations; no C/Cprime, diagnostics, tuning, exclusions based on performance, raw-record edits, GitHub edits or release.',measurement='Original fixed u32 buffer/common noinline templated function-pointer timer; CAFS i32 uses separate exact-value signed scratch; B/competitor ABBA/BAAB, 4 blocks, pair order randomized, 3 fresh processes/input. Restore/load/conversion/warmups/full equality/route audits excluded; all sort-owned analysis/scans/alloc/init/sort/reconstruct/scatter/copy/free included.',eligibility='Original CAFS i32 exact nonnegative int32 representability and Counting dense uint64 counters within64MiB. Counting min/max and initialization inside timer; unsupported omitted with denominators.',no_outlier_filtering=True)
(o/'protocol.json').write_text(json.dumps(proto,indent=2));print('Fixed inputs/sources; timed sorts',proto['timed_sorts'],flush=True)
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(Path(c['input_directory'])/(c['name']+ext))==c[key]
for session in range(3):
 jobs=cases.copy();random.Random(739152+session).shuffle(jobs)
 with (o/f'session{session}.jsonl').open('x') as f:
  for j,c in enumerate(jobs):
   d=Path(c['input_directory']);p=subprocess.run([str((w/'benchmark.exe').resolve()),str(d/(c['name']+'.bin')),str(d/(c['name']+'.expected.bin')),str(954712+session),str(int(c['cafs_i32_eligible'])),str(int(c['counting_eligible']))],capture_output=True,text=True,check=True);v=json.loads(p.stdout)
   assert v['verified'] and len(v['runs'])==(len(c['methods'])-1)*16 and v['baseline_route']==v['candidate_route'] and v['baseline_direct']==v['candidate_direct']
   f.write(json.dumps(dict(name=c['name'],group=c['evaluation_group'],n=c['n'],session=session,result=v))+'\n');f.flush();print(session+1,j+1,'/60',c['name'],flush=True)
assert all(sha(Path(p))==h for p,h in proto['source_hashes'].items())
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(Path(c['input_directory'])/(c['name']+ext))==c[key]
for name in ['prepare.py','run.py','benchmark.cpp','B.hpp','build.json']:shutil.copyfile(w/name,o/name)
shutil.copytree(w/'include',o/'include',dirs_exist_ok=True)
print('COMPLETE: all full-array/choice/direct checks passed; all source/input hashes unchanged',flush=True)
