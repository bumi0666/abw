"""Replay final66 on Windows x64 with LLVM-MinGW; never overwrite measured raw data."""
from pathlib import Path
import argparse,json,hashlib,subprocess,random,itertools,shutil,platform,sys
root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--inputs',required=True,help='Flat directory of the 66 .bin and .expected.bin pairs');ap.add_argument('--boost',required=True);ap.add_argument('--cxx',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False);inputs=Path(a.inputs).resolve()
p=json.loads((root/'protocol.json').read_text());cases=p['cases']
def sha(f):
 with f.open('rb') as h:return hashlib.file_digest(h,'sha256').hexdigest()
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(inputs/(c['name']+ext))==c[key],c['name']
cmd=[str(Path(a.cxx).resolve()),'-std=c++20','-O3','-DNDEBUG','-mavx2','-mbmi','-static','-pthread','-I'+str(root/'include'),'-I'+str(Path(a.boost).resolve()),'-I'+str(root/'vendor'),str(root/'benchmark.cpp'),'-o',str(out/'benchmark.exe')]
subprocess.run(cmd,check=True)
p.update(replay=True,replay_environment=platform.platform(),replay_command=cmd,replay_executable_sha256=sha(out/'benchmark.exe'))
(out/'protocol.json').write_text(json.dumps(p,indent=2))
for session in range(p['sessions']):
 jobs=list(itertools.product(p['modes'],cases));random.Random(928321+session).shuffle(jobs)
 with (out/f'session{session}.jsonl').open('x') as f:
  for i,(mode,c) in enumerate(jobs):
   q=subprocess.run([str(out/'benchmark.exe'),str(inputs/(c['name']+'.bin')),str(inputs/(c['name']+'.expected.bin')),str(562172+session),str(int(c['cafs_i32_eligible'])),str(int(c['counting_eligible'])),mode],capture_output=True,text=True,check=True)
   v=json.loads(q.stdout);assert v['verified'] and v['capacity_after_release']==0 and len(v['runs'])==(len(c['competition_methods'])-1)*16
   f.write(json.dumps(dict(name=c['name'],group=c['evaluation_group'],mode=mode,session=session,n=c['n'],result=v))+'\n');f.flush();print(session+1,i+1,mode,c['name'],flush=True)
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(inputs/(c['name']+ext))==c[key]
subprocess.run([sys.executable,str(root/'analyze.py'),str(out)],check=True)
print('Replay complete:',out)
