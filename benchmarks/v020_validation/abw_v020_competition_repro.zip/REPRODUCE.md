# Reproduction

The frozen sources, raw sessions, per-input CSV, analysis and CI diagnostics are
included. No previous raw experiment was modified. Protocol hashes every input,
expected array, source and measured executable. Results describe this exact
candidate, not an auto-updating main branch.

For Windows x64 LLVM-MinGW replay, put the66 unchanged input/expected pairs
in one flat directory. See reference manifests for filenames, hashes, source
URLs/licenses, exact extraction and eligibility. Original source downloads,
large input binaries, Boost headers and compiler are not in this small bundle.
dataset_tools preserves prior extraction/generation scripts; their original
work/... directory assumptions and numpy/pyarrow/Node dependencies remain.
CTU fetch_extract.py requires Windows curl for TLS and the original expected
work/abw_ipv4_certificate/inputs layout; it refuses overwriting extracted files.
Use a fresh extraction directory and verify hashes. The protocol's absolute
compiler paths document the measured machine; replay accepts explicit paths.

```
python replay.py --inputs C:/data/abw66 --boost C:/deps/boost_1_90_0 --cxx C:/llvm-mingw/bin/clang++.exe --out C:/results/abw66-replay
python report.py C:/results/abw66-replay
```

replay.py builds all methods with the recorded common C++20 options and runs
three sessions/two conditions, then analyzes them. It requires a new output
directory and refuses different input hashes. For the original published data,
`python analyze.py .` recomputes CSV/summary from the existing three JSONL files.
`python report.py .` regenerates the report from bundled results; pass a replay
directory instead of `.` to report new results.
The benchmark uses Windows affinity APIs. Portable Linux correctness and small
repeated-call diagnostics are built by the candidate's CMake/Actions instead.

For library correctness on any supported toolchain:
```
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DABW_BOOST_INCLUDE_DIR=/path/to/boost_1_90_0
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```
Run these from the candidate repository, not this evidence-only archive.
No timing value is a CI pass/fail gate. See API.md for workspace ownership and
memory lifetime; compare default/fresh/reused rows separately.
