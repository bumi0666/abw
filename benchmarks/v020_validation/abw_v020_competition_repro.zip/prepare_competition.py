from pathlib import Path
import json,subprocess,shutil
w=Path('work/abw_v020');prior=Path('work/abw_workspace_full_competition');r=Path('outputs/abw_v020_candidate');o=Path('outputs/abw_v020_competition');o.mkdir(exist_ok=True)
shutil.copyfile(prior/'A.hpp',w/'A.hpp')
s=(prior/'benchmark.cpp').read_text()
s=s.replace('Fn functions[]={&reused,&fresh,&baseline::sort,&pdq,&spread,&cafsu,nullptr,&counting}', 'void candidate(V&a){abw::sort(a);}\nFn functions[]={&reused,&fresh,&candidate,&baseline::sort,&pdq,&spread,&cafsu,nullptr,&counting}')
s=s.replace('"W_reuse","W_fresh","v013","pdq"','"W_reuse","W_fresh","v020_default","v013","pdq"')
s=s.replace('others={1,2,3,4,5};if(signedok)others.push_back(6);if(countok)others.push_back(7)','others={1,2,3,4,5,6};if(signedok)others.push_back(7);if(countok)others.push_back(8)')
s=s.replace('m==6','m==7')
(w/'benchmark.cpp').write_text(s)
cmd=json.loads((prior/'build.json').read_text())['command']
cmd=[x.replace(str(prior.resolve()),str(w.resolve())) for x in cmd]
cmd=[x.replace(str((w/'include').resolve()),str((r/'include').resolve())) for x in cmd]
q=subprocess.run(cmd,capture_output=True,text=True);(w/'build.json').write_text(json.dumps(dict(command=cmd,stdout=q.stdout,stderr=q.stderr,cafs_commit='13488afef446ae88e7ad631ec6f862def896094a'),indent=2));assert q.returncode==0,q.stderr
s=(prior/'run.py').read_text().replace('work/abw_workspace_full_competition','work/abw_v020').replace('outputs/abw_workspace_full_competition','outputs/abw_v020_competition')
s=s.replace("assert len(cases)==60", "assert len(cases)==60\nipv4=json.loads(Path('outputs/abw_ipv4_certificate/input_manifest.json').read_text())['cases']\nfor c in ipv4:c.update(input_directory='work/abw_ipv4_certificate/inputs',evaluation_group='ctu_ipv4',cafs_i32_eligible=False,counting_eligible=False)\ncases+=ipv4;assert len(cases)==66")
s=s.replace("'W_fresh','v013'","'W_fresh','v020_default','v013'")
a=s.index("assert (w/'include/abw/abw.hpp')");b=s.index('\nsources=',a);s=s[:a]+s[b:]
s=s.replace("w/'include/abw/abw.hpp'","Path('outputs/abw_v020_candidate/include/abw/abw.hpp')")
s=s.replace('sessions=4','sessions=3').replace('range(4)','range(3)').replace('*16*8','*16*6')
s=s.replace("scope='Full unchanged60", "scope='Integrated public candidate; exact certificate + shared partition core + workspace. Full unchanged66")
s=s.replace('Frozen caller-owned workspace prototype only, no IPv4 certificate or API/policy/threshold/histogram changes, no performance-based input selection, no GitHub/release changes.', 'No dispatch/threshold/histogram changes; no performance-based input selection; no main/release changes.')
s=s.replace('same prior eight-method','same prior competition').replace('Same prior eight-method','Same prior competition').replace('four fresh processes','three fresh processes').replace('median4 processes','median3 processes').replace('original9/new9/synthetic42/all60','original9/new9/synthetic42/CTU_IPv4_6/all60/all66')
s=s.replace("print('Frozen60 inputs;480 processes;'","print('Frozen66 inputs;396 processes;'").replace("'/120'","'/132'").replace('COMPLETE480 processes','COMPLETE396 processes')
s=s.replace("['prepare.py','run.py','benchmark.cpp','A.hpp','build.json']","['prepare_competition.py','run.py','benchmark.cpp','A.hpp','build.json']")
s=s.replace("shutil.copytree(w/'include',o/'include',dirs_exist_ok=True)","shutil.copytree(Path('outputs/abw_v020_candidate/include'),o/'include',dirs_exist_ok=True)")
(w/'run.py').write_text(s)
print('Built frozen final66 nine-method competition; three sessions, two modes, exact shared header')
