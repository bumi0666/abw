from pathlib import Path
import json,shutil,hashlib,subprocess
w=Path('work/abw_v020');r=Path('outputs/abw_v020_candidate');w.mkdir(exist_ok=True)
assert not r.exists(),'Use a fresh candidate directory'
shutil.copytree('outputs/abw',r)
prototype=Path('work/abw_workspace/include/abw/abw.hpp').read_text()
old=Path('outputs/abw/include/abw/abw.hpp').read_text();assert old.replace('namespace abw {','namespace variant_D {',1)==Path('work/abw_v013_hash/D.hpp').read_text()
s=prototype
scan='''    value_type difference = 0;
    for (std::size_t i = 1; i < a.size(); ++i) difference |= a[i] ^ a[0];'''
replacement='''    // An actual sampled bit-31 difference proves the full uint32 width is 32.
    // Only zero/nonzero and bit_width are used below; lower OR bits are unused.
    value_type difference = order.variation & 0x80000000u;
    if (!difference) {
        for (std::size_t i = 1; i < a.size(); ++i) difference |= a[i] ^ a[0];
    }'''
assert s.count(scan)==1;s=s.replace(scan,replacement,1)
start=s.index('// Exact B execution path.');end=s.index('\n} // namespace detail',start)
kernel=s[start:end]
kernel=kernel.replace('inline bool partition_and_sort(array_type& a, unsigned bits, unsigned shift) {','template<class MakeBuffer>\ninline bool partition_and_sort_impl(array_type& a, unsigned bits, unsigned shift, MakeBuffer make_buffer) {',1)
assert kernel.count('    array_type temporary(a.size());')==1
kernel=kernel.replace('    array_type temporary(a.size());','    auto owner = make_buffer(a.size());\n    auto& temporary = owner.get();',1)
providers='''// Storage selection is compile-time; no workspace branch in element loops.
struct owned_buffer {
    array_type values;
    explicit owned_buffer(std::size_t n) : values(n) {}
    array_type& get() noexcept { return values; }
};
struct borrowed_buffer {
    array_type& values;
    array_type& get() noexcept { return values; }
};
struct make_owned_buffer {
    owned_buffer operator()(std::size_t n) const { return owned_buffer(n); }
};
struct make_workspace_buffer {
    workspace& ws;
    borrowed_buffer operator()(std::size_t n) const {
        return {workspace_access::prepare(ws, n)};
    }
};

'''
wrappers='''
inline bool partition_and_sort(array_type& a, unsigned bits, unsigned shift) {
    return partition_and_sort_impl(a, bits, shift, make_owned_buffer{});
}
inline bool partition_and_sort_workspace(array_type& a, unsigned bits, unsigned shift, workspace& ws) {
    return partition_and_sort_impl(a, bits, shift, make_workspace_buffer{ws});
}
'''
s=s[:start]+providers+kernel+wrappers+s[end:]
dup_start=s.index('// Experimental overload:');dup_end=s.index('inline void sort(std::vector<std::uint32_t>& values, workspace& ws)',dup_start)
s=s[:dup_start]+'// Repeated calls may retain caller-owned mixed-path temporary storage.\n'+s[dup_end:]
assert s.count('for (const auto value : a) {\n        const auto b = (value >> shift) & mask;')==1
(r/'include/abw/abw.hpp').write_text(s,encoding='utf-8')
(r/'tests/reference/v013.hpp').write_text(old.replace('namespace abw {','namespace baseline {',1),encoding='utf-8')
test=Path('work/abw_workspace/safety.cpp').read_text().replace('#include "A.hpp"','#include "reference/v013.hpp"')
(r/'tests/workspace.cpp').write_text(test,encoding='utf-8')
# Reuse exact frequency/certificate safety coverage against the integrated header.
cert=Path('work/abw_width_certificate/safety.cpp').read_text().replace('#include "A.hpp"','#include "reference/v013.hpp"').replace('#include "S.hpp"','#include <abw/abw.hpp>').replace('variant_B::','baseline::').replace('variant_D::','abw::')
(r/'tests/certificate.cpp').write_text(cert,encoding='utf-8')
cm=(r/'CMakeLists.txt').read_text().replace('VERSION 0.1.3','VERSION 0.2.0')
cm=cm.replace('    add_test(NAME abw_frequency COMMAND abw_frequency)','''    add_test(NAME abw_frequency COMMAND abw_frequency)
    foreach(test workspace certificate repeated)
        add_executable(abw_${test} tests/${test}.cpp)
        target_link_libraries(abw_${test} PRIVATE abw::abw Threads::Threads)
        add_test(NAME abw_${test} COMMAND abw_${test})
    endforeach()''')
(r/'CMakeLists.txt').write_text(cm,encoding='utf-8')
ci=(r/'.github/workflows/ci.yml').read_text()
ci+='''
      - name: Record Linux repeated-call diagnostics (no timing gate)
        if: runner.os == 'Linux'
        run: |
          ./build/abw_repeated > linux-repeated.jsonl
          cat linux-repeated.jsonl
          uname -a > linux-environment.txt
          lscpu >> linux-environment.txt
          ${{ matrix.cxx }} --version >> linux-environment.txt
      - name: Save Linux diagnostic records
        if: runner.os == 'Linux'
        uses: actions/upload-artifact@v4
        with:
          name: linux-repeated-${{ matrix.compiler }}
          path: |
            linux-repeated.jsonl
            linux-environment.txt
'''
(r/'.github/workflows/ci.yml').write_text(ci,encoding='utf-8')
provenance=dict(base_commit='3797feafb7bd3e2b230e815fd1aa69df16cf0141',base_version='v0.1.3',workspace_prototype_sha256=hashlib.sha256(prototype.encode()).hexdigest(),candidate_header_sha256=hashlib.sha256((r/'include/abw/abw.hpp').read_bytes()).hexdigest(),changes=['caller-owned workspace API','exact sampled bit31 width certificate','one shared templated partition body with owned/borrowed buffer factories'],unchanged=['dispatch seeds/thresholds','histogram counts and selection','purity/count/scatter/internal pdqsort/copy','one-argument API with per-call owned temporary'],release=False)
(w/'provenance.json').write_text(json.dumps(provenance,indent=2))
print('Prepared separate v0.2.0 candidate repository; shared partition core, no release')
