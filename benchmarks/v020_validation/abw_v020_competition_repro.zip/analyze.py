from pathlib import Path
import json,csv,statistics as st,math,itertools,sys
o=Path(sys.argv[1]) if len(sys.argv)>1 else Path('outputs/abw_v020_competition');p=json.loads((o/'protocol.json').read_text());raw=[json.loads(l) for s in range(3) for l in (o/f'session{s}.jsonl').read_text().splitlines()];assert len(raw)==396
gm=lambda xs:math.exp(st.mean(math.log(x) for x in xs));methods=['W_reuse','W_fresh','v020_default','v013','pdq','spread','CAFS_u32','CAFS_i32','counting'];med={};pm={};session_rows=[];blocks=[]
for x in raw:
 n=x['name'];mode=x['mode'];s=x['session'];r=x['result']['runs'];assert x['result']['verified']
 for method in methods:
  vals=[t['ms'] for t in r if t['method']==method]
  if not vals:continue
  med[mode,n,s,method]=st.median(vals);session_rows.append(dict(mode=mode,name=n,session=s,method=method,median_ms=st.median(vals)))
 for pair in sorted({t['pair'] for t in r}):
  for method in ['W_reuse',pair]:pm[mode,n,s,pair,method]=st.median(t['ms'] for t in r if t['pair']==pair and t['method']==method)
  for k in range(4):
   a=st.mean(t['ms'] for t in r if t['pair']==pair and t['block']==k and t['method']=='W_reuse');b=st.mean(t['ms'] for t in r if t['pair']==pair and t['block']==k and t['method']==pair);blocks.append(dict(mode=mode,name=n,session=s,pair=pair,block=k,reuse_ms=a,other_ms=b,reuse_over_other=a/b))
rows=[]
for mode,c in itertools.product(p['modes'],p['cases']):
 n=c['name'];r=next(x['result'] for x in raw if x['mode']==mode and x['name']==n);row=dict(mode=mode,name=n,group=c['evaluation_group'],active=r['active'],mixed=r['mixed'],direct=r['direct'],route=r['route'],bits=r['bits'],shift=r['shift'],n=c['n'],retained_bytes=r['retained_bytes'],release_ms=st.median(x['result']['release_ms'] for x in raw if x['mode']==mode and x['name']==n))
 for method in c['competition_methods']:
  row[method+'_ms']=st.median(med[mode,n,s,method] for s in range(3))
  row[method+'_speedup_pdq']=st.median(med[mode,n,s,'pdq']/med[mode,n,s,method] for s in range(3))
  if method=='W_reuse':continue
  ratios=[pm[mode,n,s,method,'W_reuse']/pm[mode,n,s,method,method] for s in range(3)];row['reuse_over_'+method]=st.median(ratios);row['reuse_'+method+'_sessions']=ratios;row['block_reuse_over_'+method]=st.median(st.median(t['reuse_over_other'] for t in blocks if t['mode']==mode and t['name']==n and t['session']==s and t['pair']==method) for s in range(3))
 row['default_over_CAFS_u32']=st.median(med[mode,n,k,'v020_default']/med[mode,n,k,'CAFS_u32'] for k in range(3))
 row['default_v013_sessions']=[med[mode,n,k,'v020_default']/med[mode,n,k,'v013'] for k in range(3)];row['default_over_v013']=st.median(row['default_v013_sessions'])
 row['winner']=min(c['competition_methods'],key=lambda m:row[m+'_ms']);non=[m for m in c['competition_methods'] if m not in ['W_reuse','W_fresh','v020_default','v013']];row['best_non_ABW']=min(non,key=lambda m:row[m+'_ms']);row['reuse_over_best_non_ABW']=row['reuse_over_'+row['best_non_ABW']];row['clear_reuse_vs_non_ABW']=all(row['reuse_over_'+m]<.95 for m in non)
 rows.append(row)
groups={}
for mode in p['modes']:
 for label,ns in [(g,[c['name'] for c in p['cases'] if c['evaluation_group']==g]) for g in ['development_real','new_real','synthetic','ctu_ipv4']]+[('all60',[c['name'] for c in p['cases'] if c['evaluation_group']!='ctu_ipv4']),('all66',[c['name'] for c in p['cases']])]:
  rr=[x for x in rows if x['mode']==mode and x['name'] in ns];g={}
  for m in methods:
   rs=[x for x in rr if m+'_ms' in x];g[m]=dict(eligible=len(rs),gm_speedup_pdq=gm([x[m+'_speedup_pdq'] for x in rs]) if rs else None)
   if m!='W_reuse' and rs:g[m].update(gm_reuse_over_method=gm([x['reuse_over_'+m] for x in rs]),gm_block_reuse_over_method=gm([x['block_reuse_over_'+m] for x in rs]))
  groups[mode+'_'+label]=g
summary=dict(groups=groups,nominal_reuse_winners=[dict(mode=x['mode'],name=x['name']) for x in rows if x['winner']=='W_reuse'],clear_reuse_non_ABW_winners=[dict(mode=x['mode'],name=x['name']) for x in rows if x['clear_reuse_vs_non_ABW']],all_input_results=rows)
for name,data in [('input_results.csv',rows),('session_medians.csv',session_rows),('paired_blocks.csv',blocks)]:
 keys=list(dict.fromkeys(k for x in data for k in x))
 with (o/name).open('w',newline='') as f:wr=csv.DictWriter(f,fieldnames=keys);wr.writeheader();wr.writerows(data)
(o/'summary.json').write_text(json.dumps(summary,indent=2))
path_groups={}
for mode in p['modes']:
 for label,rs in [('mixed',[x for x in rows if x['mode']==mode and x['mixed']]),('direct',[x for x in rows if x['mode']==mode and x['direct']]),('native_or_skip',[x for x in rows if x['mode']==mode and not x['active']])]:
  path_groups[mode+'_'+label]=dict(n=len(rs),gm_reuse_over_v013=gm([x['reuse_over_v013'] for x in rs]),gm_block_ratio=gm([x['block_reuse_over_v013'] for x in rs]))
summary['path_groups']=path_groups
summary['worst_vs_v013']={mode:sorted([x for x in rows if x['mode']==mode],key=lambda x:x['reuse_over_v013'],reverse=True)[:5] for mode in p['modes']}
summary['winner_counts']={mode:{m:sum(x['winner']==m for x in rows if x['mode']==mode) for m in methods} for mode in p['modes']}
(o/'summary.json').write_text(json.dumps(summary,indent=2))

summary['default_groups']={}
for mode in p['modes']:
 for label in ['development_real','new_real','synthetic','ctu_ipv4','all60','all66']:
  rs=[x for x in rows if x['mode']==mode and (label=='all66' or label=='all60' and x['group']!='ctu_ipv4' or x['group']==label)]
  summary['default_groups'][mode+'_'+label]=dict(n=len(rs),default_over_v013=gm([x['default_over_v013'] for x in rs]),reuse_over_default=gm([x['reuse_over_v020_default'] for x in rs]),default_over_CAFS_u32=gm([x['default_over_CAFS_u32'] for x in rs]))
summary['worst_default_vs_v013']={mode:sorted([x for x in rows if x['mode']==mode],key=lambda x:x['default_over_v013'],reverse=True)[:5] for mode in p['modes']}
(o/'summary.json').write_text(json.dumps(summary,indent=2))
