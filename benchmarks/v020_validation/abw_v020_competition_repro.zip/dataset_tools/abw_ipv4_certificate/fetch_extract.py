from pathlib import Path
import urllib.request,json,hashlib,csv,socket,concurrent.futures,sys,time,subprocess
import numpy as np
w=Path('work/abw_ipv4_certificate');o=Path('outputs/abw_ipv4_certificate');w.mkdir(exist_ok=True);o.mkdir(exist_ok=True)
raw=w/'sources';raw.mkdir(exist_ok=True);inputs=w/'inputs';inputs.mkdir(exist_ok=True)
plan=[dict(scenario=i,capture=c,date=d,url=f'https://mcfp.felk.cvut.cz/publicDatasets/CTU-Malware-Capture-Botnet-{c}/detailed-bidirectional-flow-labels/capture{d}.binetflow') for i,c,d in [(1,42,'20110810'),(2,43,'20110811'),(3,44,'20110812')]]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
selection=dict(frozen_before_download=True,selection='First three CTU-13 scenarios in published order; all IPv4 values of SrcAddr and DstAddr, in original record order. No performance selection, truncation, replication, shuffle or hashing.',dataset='CTU-13, CTU University 2011, university background/normal traffic plus intentionally infected botnet hosts; captured flows rather than synthetic random keys',license='Official Stratosphere datasets overview identifies CTU-13 as Creative Commons CC-BY, version unspecified. Capture README permits use with project/author attribution.',attribution='Garcia, Sebastian. Malware Capture Facility Project. https://stratosphereips.org ; Garcia, Grill, Stiborek, Zunino, An empirical comparison of botnet detection methods, Computers & Security45 (2014),100-123.',source_page='https://www.stratosphereips.org/datasets-ctu13',license_page='https://www.stratosphereips.org/datasets-overview',plan=plan,conversion='IPv4 a.b.c.d -> (a<<24)|(b<<16)|(c<<8)|d, lossless network-order numeric value; stored as little-endian uint32 for harness. No remapping. IPv6/ARP/non-IPv4 per-column entries excluded and counted; duplicates/order of retained records preserved.',scope='Only same frozen v0.1.3 versus exact width-certificate candidate and identical-function controls; no code/policy changes or release')
(o/'selection.json').write_text(json.dumps(selection,indent=2))
def fetch(p):
 dst=raw/(f"ctu{p['scenario']}_{p['date']}.binetflow")
 if not dst.exists():
  print('download started',p['scenario'],p['url'],flush=True)
  # Windows curl uses the native trusted certificate store; TLS validation stays enabled.
  cmd=['curl.exe','--fail','--location','--retry','2','--max-time','900','--dump-header',str(raw/(dst.name+'.headers.txt')),'--output',str(dst),p['url']]
  result=subprocess.run(cmd,capture_output=True,text=True)
  (raw/(dst.name+'.download.json')).write_text(json.dumps(dict(command=cmd,exit_code=result.returncode,stderr=result.stderr),indent=2))
  if result.returncode:raise RuntimeError('download failed '+str(p['scenario']))
 print('download complete',p['scenario'],dst.stat().st_size,flush=True)
 return dst
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 files=list(pool.map(fetch,plan))
records=[]
for p,path in zip(plan,files):
 columns=['SrcAddr','DstAddr'];buffers={c:[] for c in columns};outpaths={c:inputs/f"ctu{p['scenario']}_{c.lower()}_ipv4.bin" for c in columns};handles={c:q.open('xb') for c,q in outpaths.items()};total=0;excluded={c:dict(ipv6=0,other=0) for c in columns}
 try:
  with path.open(newline='',encoding='utf-8') as f:
   reader=csv.DictReader(f);assert all(c in reader.fieldnames for c in columns)
   for row in reader:
    total+=1
    for c in columns:
     value=row[c].strip()
     try:
      if ':' in value:raise ValueError('non IPv4')
      # inet_pton rejects shortened/overflow forms; exact dotted IPv4 only.
      packed=socket.inet_pton(socket.AF_INET,value);v=int.from_bytes(packed,'big')
     except (OSError,ValueError):
      try:socket.inet_pton(socket.AF_INET6,value);category='ipv6'
      except OSError:category='other'
      excluded[c][category]+=1;continue
     buffers[c].append(v)
     if len(buffers[c])>=65536:np.asarray(buffers[c],dtype='<u4').tofile(handles[c]);buffers[c].clear()
    if total%1000000==0:print('extract',p['scenario'],total,'rows',flush=True)
  for c in columns:
   if buffers[c]:np.asarray(buffers[c],dtype='<u4').tofile(handles[c])
 finally:
  for h in handles.values():h.close()
 for c in columns:
  q=outpaths[c];a=np.fromfile(q,dtype='<u4');assert len(a)>0;unique=len(np.unique(a));expected=q.with_name(q.stem+'.expected.bin');np.sort(a).tofile(expected)
  records.append(dict(name=q.stem,group='ctu_ipv4',evaluation_group='ctu_ipv4',scenario=p['scenario'],capture=p['capture'],source_url=p['url'],source_sha256=sha(path),source_bytes=path.stat().st_size,source_rows=total,column=c,n=len(a),unique=unique,duplicate_ratio=1-unique/len(a),minimum=int(a.min()),maximum=int(a.max()),low_half_count=int(np.count_nonzero(a<0x80000000)),high_half_count=int(np.count_nonzero(a>=0x80000000)),excluded=excluded[c],input_directory=str(inputs.resolve()),sha256=sha(q),expected_sha256=sha(expected),order='original file record order, IPv4 entries only',conversion=selection['conversion']))
  print('column',q.stem,'n',len(a),'distinct',unique,'excluded',excluded[c],flush=True)
(o/'input_manifest.json').write_text(json.dumps(dict(selection=selection,cases=records),indent=2));print('EXTRACTION COMPLETE',len(records),'unchanged IPv4 columns',flush=True)
