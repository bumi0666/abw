import pathlib,urllib.request,time,hashlib,json,concurrent.futures
root=pathlib.Path('work/ABW_realworld/downloads')
targets=[('NASA_access_log_Jul95.gz','https://ita.ee.lbl.gov/traces/NASA_access_log_Jul95.gz'),('covertype.zip','https://archive.ics.uci.edu/static/public/31/covertype.zip'),('us_census_1990.zip','https://archive.ics.uci.edu/static/public/116/us+census+data+1990.zip')]
def get(t):
 name,url=t;p=root/name
 if p.exists():return name,p.stat().st_size,'cached'
 start=time.time()
 with urllib.request.urlopen(url,timeout=60) as r, p.open('wb') as f:
  while True:
   b=r.read(1024*1024)
   if not b:break
   f.write(b)
 return name,p.stat().st_size,round(time.time()-start,2)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 for f in concurrent.futures.as_completed([ex.submit(get,t) for t in targets]):
  try:print(f.result(),flush=True)
  except Exception as e:print(type(e).__name__,str(e),flush=True)
