from pathlib import Path
import json,hashlib,subprocess,random,itertools,platform,shutil
w=Path('work/abw_v020');o=Path('outputs/abw_v020_competition')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
cases=json.loads(Path('outputs/abw_v013_first/protocol.json').read_text())['cases'];assert len(cases)==60
ipv4=json.loads(Path('outputs/abw_ipv4_certificate/input_manifest.json').read_text())['cases']
for c in ipv4:c.update(input_directory='work/abw_ipv4_certificate/inputs',evaluation_group='ctu_ipv4',cafs_i32_eligible=False,counting_eligible=False)
cases+=ipv4;assert len(cases)==66
for c in cases:c['competition_methods']=['W_reuse','W_fresh','v020_default','v013','pdq','spread','CAFS_u32']+(['CAFS_i32'] if c['cafs_i32_eligible'] else [])+(['counting'] if c['counting_eligible'] else [])

sources=[Path('outputs/abw_v020_candidate/include/abw/abw.hpp'),w/'A.hpp',w/'benchmark.cpp',w/'benchmark.exe',Path('work/ABW_realworld/vendor/cafs.hpp'),Path('work/ABW_realworld/vendor/cafs2.hpp'),Path('outputs/abw/include/abw/abw.hpp')]
p=dict(cases=cases,sessions=3,modes=['warm','perturbed'],blocks=4,timed_calls=sum((len(c['competition_methods'])-1)*16*6 for c in cases),source_hashes={str(p):sha(p) for p in sources},build=json.loads((w/'build.json').read_text()),environment=dict(cpu='Intel Core i5-14500',os=platform.platform(),compiler='LLVM-MinGW Clang23.1.5/libc++ UCRT Boost1.90.0 C++20 O3 NDEBUG AVX2 BMI static pthread; first allowed CPU affinity'),scope='Integrated public candidate; exact certificate + shared partition core + workspace. Full unchanged66: original real9, new real9, synthetic42. No dispatch/threshold/histogram changes; no performance-based input selection; no main/release changes.',measurement='Same prior competition competition. Fixed u32 scratch/common noinline timer; CAFS i32 separate exact-value signed scratch, conversion excluded. Restore -> optional64MiB sequential sum -> timer -> full sorting API -> stop -> full equality. Warmup/target setup/path audit/load outside. W_fresh constructs and destroys workspace inside each call, W_reuse prewarmed per-input workspace retained with final free separately recorded; other APIs original per-call lifecycles. Anchor W_reuse/comparator four ABBA/BAAB blocks, shuffled pair order, three fresh processes per input/mode. Both modes allocate same64MiB harness buffer. No alias control in competition.',estimators='Primary reuse/comparator time ratio same-pair method medians per process, median3 processes/input, geometric mean equal-weight input groups. Displayed times pool calls/method; pdq speedups use same-process pooled medians. Separate groups original9/new9/synthetic42/CTU_IPv4_6/all60/all66, optional execution-path subgroups. No outlier filtering or estimator selection after results.',eligibility='Same60 manifest: CAFS i32 exact nonnegative int32 support; Counting runtime dense uint64 histogram<=64MiB counters. Unsupported omitted with denominators.',memory='Capacity-derived retained workspace bytes only; native/direct per-input processes retain0, mixed retains4n here. Other-sorter peak/RSS unmeasured; retained buffer coexists with comparator calls.64MiB disturbance memory is harness allocation. Each process repeats one input; not a variable-size stream.')
(o/'protocol.json').write_text(json.dumps(p,indent=2));print('Frozen66 inputs;396 processes;',p['timed_calls'],'timed calls',flush=True)
def verify():
 assert all(sha(Path(path))==h for path,h in p['source_hashes'].items())
 for c in cases:
  for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(Path(c['input_directory'])/(c['name']+ext))==c[key]
verify()
for session in range(3):
 jobs=list(itertools.product(p['modes'],cases));random.Random(928321+session).shuffle(jobs)
 with (o/f'session{session}.jsonl').open('x') as f:
  for i,(mode,c) in enumerate(jobs):
   d=Path(c['input_directory']);q=subprocess.run([str((w/'benchmark.exe').resolve()),str(d/(c['name']+'.bin')),str(d/(c['name']+'.expected.bin')),str(562172+session),str(int(c['cafs_i32_eligible'])),str(int(c['counting_eligible'])),mode],capture_output=True,text=True,check=True);v=json.loads(q.stdout)
   assert v['verified'] and len(v['runs'])==(len(c['competition_methods'])-1)*16 and v['capacity_after_release']==0 and v['mode']==mode
   assert (v['eviction_sink']!=0)==(mode=='perturbed')
   assert bool(v['retained_bytes'])==v['mixed']
   f.write(json.dumps(dict(name=c['name'],group=c['evaluation_group'],mode=mode,session=session,n=c['n'],result=v))+'\n');f.flush();print(session+1,i+1,'/132',mode,c['name'],'mixed',v['mixed'],'direct',v['direct'],flush=True)
verify()
for name in ['prepare_competition.py','run.py','benchmark.cpp','A.hpp','build.json']:shutil.copyfile(w/name,o/name)
shutil.copytree(Path('outputs/abw_v020_candidate/include'),o/'include',dirs_exist_ok=True)
print('COMPLETE396 processes',p['timed_calls'],'correct timed sorts; all full arrays/choices/active intervals/direct/mixed/retained/hash checks pass',flush=True)
