#include "A.hpp"
#include <abw/abw.hpp>
#include <fstream>
#include <iostream>
#include <stdexcept>
int main(int argc,char**argv){try{for(int j=1;j<argc;++j){std::ifstream f(argv[j],std::ios::binary|std::ios::ate);auto bytes=f.tellg();if(!f||bytes<0||bytes%4)throw std::runtime_error("input");std::vector<uint32_t>a(size_t(bytes)/4);f.seekg(0);f.read(reinterpret_cast<char*>(a.data()),bytes);if(!f)throw std::runtime_error("read");auto old=baseline::detail::choose(a);auto now=abw::detail::choose(a);if(int(old.selected)!=int(now.selected)||old.bits!=now.bits||old.shift!=now.shift)throw std::runtime_error("choice");bool omitted=false;uint32_t variation=0;bool ordered=false;if(a.size()>=100000){auto p=abw::detail::probe(a);variation=p.variation;ordered=p.ordered;omitted=!ordered&&(variation&0x80000000u);}std::cout<<"{\"file\":\""<<j<<"\",\"n\":"<<a.size()<<",\"variation\":"<<variation<<",\"ordered\":"<<(ordered?"true":"false")<<",\"scan_omitted\":"<<(omitted?"true":"false")<<"}\n";}}catch(const std::exception&e){std::cerr<<e.what();return 1;}}
