#include "A.hpp"
#include <abw/abw.hpp>
#include <boost/sort/spreadsort/spreadsort.hpp>
#include "cafs2.hpp"
#include <windows.h>
#include <chrono>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <random>
#include <stdexcept>
#include <string>
using U=uint32_t;using V=std::vector<U>;using I=std::vector<int32_t>;using Clock=std::chrono::steady_clock;
std::vector<uint64_t> eviction;volatile uint64_t eviction_sink=0;bool perturb=false;abw::workspace* current_ws=nullptr;
__attribute__((noinline))void disturb(){uint64_t sum=0;for(auto value:eviction)sum+=value;eviction_sink=sum;}
V load(const char*p){std::ifstream f(p,std::ios::ate|std::ios::binary);if(!f)throw std::runtime_error("load");auto n=f.tellg();if(n<0||n%4)throw std::runtime_error("size");V a(size_t(n)/4);f.seekg(0);f.read(reinterpret_cast<char*>(a.data()),n);if(!f)throw std::runtime_error("read");return a;}
void reused(V&a){abw::sort(a,*current_ws);}void fresh(V&a){abw::workspace ws;abw::sort(a,ws);}
void pdq(V&a){boost::sort::pdqsort(a.begin(),a.end());}void spread(V&a){boost::sort::spreadsort::integer_sort(a.begin(),a.end());}
void cafsu(V&a){cafs2::cafs_sort(a,[](auto&v){boost::sort::pdqsort(v.begin(),v.end());});}void cafsi(I&a){cafs2::cafs_sort(a,[](auto&v){boost::sort::pdqsort(v.begin(),v.end());});}
void counting(V&a){if(a.empty())return;auto mm=std::minmax_element(a.begin(),a.end());U lo=*mm.first,hi=*mm.second;uint64_t range=uint64_t(hi)-lo+1;if(range*8>67108864)throw std::runtime_error("counting cap");std::vector<uint64_t>counts(size_t(range),0);for(U v:a)counts[size_t(v-lo)]++;auto it=a.begin();for(size_t j=0;j<counts.size();j++){std::fill_n(it,counts[j],U(uint64_t(lo)+j));it+=counts[j];}}
using Fn=void(*)(V&);void candidate(V&a){abw::sort(a);}
Fn functions[]={&reused,&fresh,&candidate,&baseline::sort,&pdq,&spread,&cafsu,nullptr,&counting};
const char*names[]={"W_reuse","W_fresh","v020_default","v013","pdq","spread","CAFS_u32","CAFS_i32","counting"};
template<class T>__attribute__((noinline))double measured(void(*fn)(std::vector<T>&),const std::vector<T>&src,const V&expected,std::vector<T>&scratch){std::copy(src.begin(),src.end(),scratch.begin());if(perturb)disturb();auto t=Clock::now();fn(scratch);double ms=std::chrono::duration<double,std::milli>(Clock::now()-t).count();if(!std::equal(scratch.begin(),scratch.end(),expected.begin(),[](T x,U y){return uint32_t(x)==y;}))throw std::runtime_error("incorrect");return ms;}
int main(int argc,char**argv){try{
 if(argc!=7)throw std::runtime_error("input expected seed signed_ok counting_ok mode");DWORD_PTR p,s;if(!GetProcessAffinityMask(GetCurrentProcess(),&p,&s)||!SetProcessAffinityMask(GetCurrentProcess(),p&(~p+1)))throw std::runtime_error("affinity");
 perturb=std::string(argv[6])=="perturbed";if(!perturb&&std::string(argv[6])!="warm")throw std::runtime_error("mode");eviction.resize(64u*1024u*1024u/8);for(size_t i=0;i<eviction.size();++i)eviction[i]=uint64_t(i)*0x9e3779b97f4a7c15ull+17;
 abw::workspace ws;current_ws=&ws;auto a=load(argv[1]),e=load(argv[2]);if(a.size()!=e.size())throw std::runtime_error("sizes");bool signedok=std::stoi(argv[4])!=0,countok=std::stoi(argv[5])!=0;auto mm=std::minmax_element(a.begin(),a.end());if(signedok&&*mm.second>U(INT32_MAX))throw std::runtime_error("signed unsupported");if(countok&&(uint64_t(*mm.second)-*mm.first+1)*8>67108864)throw std::runtime_error("count unsupported");
 V scratch(a.size());I isrc,iscratch;if(signedok){isrc.assign(a.begin(),a.end());iscratch.resize(a.size());}auto uptr=scratch.data();auto iptr=iscratch.data();std::vector<int>others={1,2,3,4,5,6};if(signedok)others.push_back(7);if(countok)others.push_back(8);
 for(int kind=0;kind<3;++kind){V x(100000),tmp(x.size());std::mt19937 r(183+kind);for(size_t i=0;i<x.size();++i)x[i]=kind==0?r()%1024:kind==1?U(i):r()%8;auto ex=x;std::sort(ex.begin(),ex.end());I ix(x.begin(),x.end()),it(x.size());measured(functions[0],x,ex,tmp);for(int m:others){if(m==7)measured(&cafsi,ix,ex,it);else measured(functions[m],x,ex,tmp);}}
 auto call=[&](int m){double ms=m==7?measured(&cafsi,isrc,e,iscratch):measured(functions[m],a,e,scratch);if(scratch.data()!=uptr||iscratch.data()!=iptr)throw std::runtime_error("scratch moved");return ms;};
 call(0);for(int m:others)call(m);auto before=baseline::detail::choose(a);auto after=abw::detail::choose(a);if(int(before.selected)!=int(after.selected)||before.bits!=after.bits||before.shift!=after.shift)throw std::runtime_error("decision");
 bool active=before.selected==baseline::detail::strategy::active8||before.selected==baseline::detail::strategy::active12;
 bool direct=false;
 if(active){auto x=a,y=a;direct=baseline::detail::partition_and_sort(x,before.bits,before.shift);bool wd=abw::detail::partition_and_sort_workspace(y,after.bits,after.shift,ws);if(direct!=wd||x!=e||y!=e)throw std::runtime_error("direct/mixed audit");}
 const bool mixed=active&&!direct;
 const size_t retained=ws.retained_bytes();if(mixed?!retained:retained!=0)throw std::runtime_error("retained buffer/path mismatch");
 std::cout<<std::setprecision(15)<<"{\"verified\":true,\"mode\":\""<<argv[6]<<"\",\"route\":"<<int(before.selected)<<",\"bits\":"<<before.bits<<",\"shift\":"<<before.shift<<",\"active\":"<<(active?"true":"false")<<",\"mixed\":"<<(mixed?"true":"false")<<",\"direct\":"<<(direct?"true":"false")<<",\"retained_bytes\":"<<retained<<",\"runs\":[";bool first=true;std::mt19937 rng(unsigned(std::stoul(argv[3])));
 for(int block=0;block<4;++block){auto shuffled=others;std::shuffle(shuffled.begin(),shuffled.end(),rng);for(int m:shuffled){int order[4]={0,m,m,0};if(block%2){order[0]=m;order[1]=0;order[2]=0;order[3]=m;}for(int pos=0;pos<4;++pos){int who=order[pos];double ms=call(who);if(ws.retained_bytes()!=retained)throw std::runtime_error("workspace grew");if(!first)std::cout<<",";first=false;std::cout<<"{\"block\":"<<block<<",\"pair\":\""<<names[m]<<"\",\"position\":"<<pos<<",\"method\":\""<<names[who]<<"\",\"ms\":"<<ms<<"}";}}}
 auto t=Clock::now();ws.release();double release=std::chrono::duration<double,std::milli>(Clock::now()-t).count();if(ws.capacity())throw std::runtime_error("release");std::cout<<"],\"release_ms\":"<<release<<",\"eviction_sink\":"<<eviction_sink<<",\"capacity_after_release\":0}";
}catch(const std::exception&e){std::cerr<<e.what();return 1;}}
