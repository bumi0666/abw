from pathlib import Path
import json,subprocess,hashlib
w=Path('work/abw_v020');r=Path('outputs/abw_v020_candidate')
compiler=Path('work/F_toolchain/llvm-mingw-20261104-ucrt-x86_64/bin/clang++.exe').resolve()
boost=Path('work/F_vendor/boost_1_90_0').resolve()
cases=json.loads(Path('outputs/abw_v013_first/protocol.json').read_text())['cases']
ipv4=json.loads(Path('outputs/abw_ipv4_certificate/input_manifest.json').read_text())['cases']
for c in ipv4:c['input_directory']='work/abw_ipv4_certificate/inputs'
cases+=ipv4
records=[]
for name in ['conformance','frequency','workspace','certificate','repeated']:
 cmd=[str(compiler),'-std=c++17','-O3','-DNDEBUG','-mavx2','-mbmi','-static','-pthread','-I'+str(boost),'-I'+str((r/'include').resolve()),'-I'+str((r/'tests/reference').resolve()),str((r/f'tests/{name}.cpp').resolve()),'-o',str((w/f'{name}.exe').resolve())]
 q=subprocess.run(cmd,capture_output=True,text=True);assert q.returncode==0,q.stderr
 args=[str((w/f'{name}.exe').resolve())]
 if name in ['workspace','conformance']:args += [str(Path(c['input_directory'])/(c['name']+'.bin')) for c in cases]
 q=subprocess.run(args,capture_output=True,text=True);print(name,q.stdout,q.stderr,flush=True)
 records.append(dict(name=name,command=cmd,arguments=args[1:],returncode=q.returncode,stdout=q.stdout,stderr=q.stderr))
 assert q.returncode==0
(w/'checks.json').write_text(json.dumps(records,indent=2))
print('PASS local C++17 tests; all66 inputs plus boundary/collision/failure/concurrency cases')
