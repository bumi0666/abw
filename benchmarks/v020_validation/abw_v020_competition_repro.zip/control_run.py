from pathlib import Path
import json,subprocess,statistics as st,hashlib
w=Path('work/abw_v020');o=Path('outputs/abw_v020_competition');plan=json.loads((w/'control_plan.json').read_text());p=json.loads((o/'protocol.json').read_text());c=next(c for c in p['cases'] if c['name']==plan['input']);d=Path(c['input_directory'])
cmd=json.loads((w/'control_build.json').read_text())['command'];q=subprocess.run(cmd,capture_output=True,text=True);assert q.returncode==0,q.stderr
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(d/(c['name']+'.bin'))==c['sha256'];assert sha(d/(c['name']+'.expected.bin'))==c['expected_sha256']
records=[]
for session in range(plan['sessions']):
 for mode in plan['modes']:
  q=subprocess.run([str((w/'control.exe').resolve()),str(d/(c['name']+'.bin')),str(d/(c['name']+'.expected.bin')),str(821391+session),'0','0',mode],capture_output=True,text=True,check=True);v=json.loads(q.stdout);assert v['verified'] and not v['mixed'] and v['retained_bytes']==0
  ratios={m:st.median(t['ms'] for t in v['runs'] if t['pair']==m and t['method']==m)/st.median(t['ms'] for t in v['runs'] if t['pair']==m and t['method']=='A_v013') for m in ['alias_v013','v020_default','W_reuse']}
  records.append(dict(session=session,mode=mode,result=v,ratio_to_same_pair_baseline=ratios));print(session,mode,ratios,flush=True)
data=dict(plan=plan,source_sha256=sha(w/'control.cpp'),executable_sha256=sha(w/'control.exe'),input_sha256=c['sha256'],records=records,conclusion='Same exact baseline function pointer for A and alias. Descriptive control only; does not prove any other change is noise or identify a hardware cause.')
(o/'control.json').write_text(json.dumps(data,indent=2))
