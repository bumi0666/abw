# v0.2.0 candidate validation

This evidence measures the integrated public header: caller-owned workspace,
exact sampled bit31 certificate, one shared partition core. Sorting policy is
unchanged from v0.1.3. This is an unreleased candidate.

- [Full report and all input times](report.md)
- [Assessment, gains, regressions and limits](assessment.md)
- [Input-level CSV](input_results.csv)
- [Checks and CI record](validation.json)
- [Reproduction archive](abw_v020_competition_repro.zip)

396 processes /42,816 timed sorts, existing60 plus CTU IPv4 six. Full arrays,
choices, active intervals, direct paths and source/input hashes pass. Three
processes/input/condition, warm and64MiB-disturbed, same prior ABBA design.
Default/fresh-workspace/reused-workspace calls remain separate. No timing gate.

Reused workspace reduces all66 time by5.05%/5.15% versus v0.1.3 and3.46%/3.98%
versus the new default. Mixed27 reuse/default reduction7.73%/8.71%. New default
versus v0.1.3 reduction0.99%/1.18%. Existing60 and IPv4_6 are separately shown.
Default is0.46%/1.46% slower than CAFS u32 across66; reused is2.59%/2.79% faster
under its retained-buffer lifetime. On existing60 default remains2.18%/3.28%
slower, reused close. Do not present these as unconditional CAFS equivalence.

Regressions remain: default1M partial +7.12% warm; reuse1M partial +6.27% warm
and Census industry +5.69% disturbed. All three reuse Census processes are
slower. These native/direct paths do not use workspace; cause unconfirmed.

GCC/Clang/MSVC C++17 [CI](https://github.com/bumi0666/abw/actions/runs/43804878261)
passes. Linux repeated diagnostics on AMD/Intel hosted VMs pass, with some
small/no timing gain. They do not reproduce all66 performance on another CPU.
The archive contains raw sessions, source/input manifests, frozen headers,
competitor source/licenses, analysis, API contract and Linux logs. Dataset
binaries, Boost and compiler are not bundled. See REPRODUCE.md inside it.
