from pathlib import Path
import json,statistics as st,math,sys
o=Path(sys.argv[1]) if len(sys.argv)>1 else Path('outputs/abw_v020_competition');s=json.loads((o/'summary.json').read_text());p=json.loads((o/'protocol.json').read_text());rows=s['all_input_results'];groups=s['groups'];dg=s['default_groups']
methods=['W_reuse','W_fresh','v020_default','v013','pdq','spread','CAFS_u32','CAFS_i32','counting'];labels=['development_real','new_real','synthetic','ctu_ipv4','all60','all66']
gm=lambda a:math.exp(st.mean(math.log(x) for x in a))
report='''# Integrated v0.2.0 candidate: final66 validation

2026-11-16. Candidate based on released v0.1.3 commit
3797feafb7bd3e2b230e815fd1aa69df16cf0141. Adds caller-owned workspace and exact
sampled bit31 width certificate. Both overloads share one templated partition
body with owning/borrowing temporary factories. No dispatch seed/threshold,
histogram, purity, scatter, pdqsort or copy-policy change. This comparison uses
the actual integrated public candidate header; earlier prototype times are not
pooled. No main merge, tag or release is performed by this validation.

## Inputs and correctness

All original real9, new real9 and synthetic42 remain unchanged. Six CTU-13
IPv4 columns are added without selection by performance. Existing60 and IPv4
results are reported separately; the all66 average weights each input equally
and is not a production workload mixture. CTU columns are correlated from one
dataset, not six independent datasets. Address conversion is lossless network
numeric IPv4 to uint32; original retained row order preserved, no replication,
hashing or shuffle. IPv6/non-IPv4 entries were omitted as documented. See
reference/input manifests for extraction, source URLs, licenses and SHA256.

Every timed output is compared element-by-element with the hashed expected
array. Both ABW overloads agree with v0.1.3 on strategies, active intervals and
direct/mixed results. Source/executable/input/expected hashes are checked before
and after timing. Conformance, frequency collisions/bounds, exact certificates,
grow/shrink, move/release, injected bad_alloc and separate-workspace concurrency
are tested separately in C++17. Local all66 tests and GCC/Clang/MSVC CI results
are retained in validation files and CI logs. CI uses generated correctness
inputs; the external datasets are checked locally.

## Conditions and memory lifetimes

Intel i5-14500, Windows11 x64, 32GiB installed-class physical memory; exact
reported bytes in environment.json. LLVM-MinGW Clang23.1.5/libc++ UCRT,
Boost1.90.0, CAFS commit13488afef446ae88e7ad631ec6f862def896094a. All sorters
use C++20 -O3 -DNDEBUG -mavx2 -mbmi -static -pthread because CAFS needs C++20.
Public API and correctness matrix use C++17. First allowed CPU affinity.

One binary/shared fixed u32 scratch/common noinline pointer-call timer. i32
uses separate fixed signed scratch containing the exact same supported values;
conversion is outside timing. Input restore -> optional64MiB sequential read
into observable sink -> timer -> complete sorting API -> stop -> full equality.
Load/restore/disturbance/audits are excluded, sorting analysis/alloc/init/count/
scatter/internal sort/copy/free are included. Both conditions allocate the same
64MiB harness array. Disturbance does not guarantee an empty cache, a realistic
production stream or a lower/upper performance bound.

W_reuse prewarms and retains caller-owned mixed-path storage across calls;
release is separately logged. W_fresh constructs/destroys workspace inside each
call. v020_default and v013 keep per-call local temporary lifetimes. Competitors
use their original per-call APIs; competitor workspace reuse is not measured.
Each process repeats the same input; changing-content/size streams are unmeasured.
Repeated warm full-function medians are not first-application cold latency.
Retained workspace coexists with comparator allocations, so a near CAFS average
must always be accompanied by the default/fresh comparison. Direct/native/skip
do not use workspace; an earlier larger buffer can remain in a variable-size
application, outside these per-input timing processes.

Memory records are capacity payload (4*capacity), not total requested heap,
allocator overhead or peak RSS. Other per-sort allocations remain. No new
all-sorter peak-memory claim is made. Native/direct processes start empty and
retain0; mixed processes retain4n here. Growth policy and release/concurrency
contract are documented in docs/workspace.md.

CAFS i32 supports only24 exactly representable inputs. Frozen Counting uses
runtime min/max plus dense initialized uint64 counters capped at64MiB:26
eligible inputs. All IPv4 columns are unsupported by these two methods.
Unsupported means omitted, not a loss. Counting is this specific implementation,
not every optimized histogram sorter.

## Repetition and estimators

Three fresh processes/input/condition:396 processes. Four alternating ABBA/BAAB
blocks of W_reuse versus each eligible comparator; shuffled pair order and
randomized input/condition order. No outlier filtering, input removal or tuning.
Primary reuse/comparator ratio uses same-pair call medians/process, median3
process ratios/input, equal-input geometric mean. Block-paired ratios average
two calls/method/block and are retained alongside. Displayed method times pool
that method's calls/process, then median3 processes. pdq speedups and default/
v013 comparisons use same-process pooled medians; their ratios can differ from
primary pair estimates. No estimator is chosen by which favors ABW. Lowest
displayed median is nominal winner, not a statistical significance finding.

The separate Taxi payment A/A diagnostic uses the exact same baseline function
pointer under two names, three processes per condition and the same pair design.
It runs after the full comparison in a separate binary, does not establish the
cause of a regression and is not used to discard measurements.

## Results

'''
report+=f"All {p['timed_calls']:,} timed sorts in396 processes passed.\n\n"
def fmt(x):return 'unsupported' if x is None else f'{x:.5f}'
for mode in p['modes']:
 report+=f'### {mode}: geometric mean speedup over pdq\n\n| Method | Original9 | New9 | Synthetic42 | IPv4_6 | Existing60 | All66 |\n|---|---:|---:|---:|---:|---:|---:|\n'
 for m in methods:
  report+='| '+m+' | '+' | '.join(fmt(groups[mode+'_'+g][m]['gm_speedup_pdq'])+f" ({groups[mode+'_'+g][m]['eligible']})" for g in labels)+' |\n'
 report+='\n### '+mode+': time ratios (lower is faster)\n\n| Group | Default/v013 | Reuse/default | Reuse/v013 | Reuse/CAFS u32 | Default/CAFS u32 |\n|---|---:|---:|---:|---:|---:|\n'
 for g in labels:
  q=dg[mode+'_'+g];q2=groups[mode+'_'+g]
  report+='| '+g+' | '+' | '.join(fmt(x) for x in [q['default_over_v013'],q['reuse_over_default'],q2['v013']['gm_reuse_over_method'],q2['CAFS_u32']['gm_reuse_over_method'],q['default_over_CAFS_u32']])+' |\n'
 report+='\n### '+mode+': all input medians (ms)\n\n| Input | Path | Reuse | Fresh ws | Default | v013 | pdq | Spread | CAFS u32 | CAFS i32 | Counting | Lowest |\n|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|\n'
 for x in rows:
  if x['mode']==mode:report+='| '+x['name']+' | '+('mixed' if x['mixed'] else 'direct' if x['direct'] else 'native/skip')+' | '+' | '.join(fmt(x.get(m+'_ms')) for m in methods)+' | '+x['winner']+' |\n'
report+='\n## Largest regressions retained\n\n'
for mode in p['modes']:
 report+=f'### {mode}: reuse/v013\n\n| Input | Ratio | Block ratio | Three process ratios | Path |\n|---|---:|---:|---|---|\n'
 for x in s['worst_vs_v013'][mode]:report+='| '+x['name']+' | '+fmt(x['reuse_over_v013'])+' | '+fmt(x['block_reuse_over_v013'])+' | '+', '.join(fmt(v) for v in x['reuse_v013_sessions'])+' | '+('mixed' if x['mixed'] else 'direct' if x['direct'] else 'native/skip')+' |\n'
 report+=f'\n### {mode}: default/v013\n\n| Input | Ratio | Three process ratios |\n|---|---:|---|\n'
 for x in s['worst_default_vs_v013'][mode]:report+='| '+x['name']+' | '+fmt(x['default_over_v013'])+' | '+', '.join(fmt(v) for v in x['default_v013_sessions'])+' |\n'
report+='\n## Path subsets (primary reuse/default ratio)\n\n| Mode | Path | N | Ratio |\n|---|---|---:|---:|\n'
for mode in p['modes']:
 for label in ['mixed','direct','native/skip']:
  rs=[x for x in rows if x['mode']==mode and ('mixed' if x['mixed'] else 'direct' if x['direct'] else 'native/skip')==label]
  report+=f"| {mode} | {label} | {len(rs)} | {gm([x['reuse_over_v020_default'] for x in rs]):.5f} |\n"
report+='\n## CPU scope and limitations\n\nThe full66 performance comparison is one local Intel/Windows machine. GitHub\nUbuntu GCC13.3 on AMD EPYC7763 and Clang18.1 on Intel Xeon6975P-C pass repeated\ncall correctness with three generated1M inputs, plus growth/failure/thread\ntests. Those shared virtual machines use different compilers and environments;\nthe small diagnostics are not a full66 cross-CPU performance replication, a\ncompiler ranking, or a guarantee of workspace speedup. GCC mixed diagnostics\nshow little or no timing gain; all unfiltered records are included. Performance\nis not a CI pass condition. Existing competitive weaknesses, historical direct\npath successes, distribution selection and sample-based dispatch limitations\nremain. No change is automatically released.\n'
if (o/'audit.json').exists():
 audit=json.loads((o/'audit.json').read_text());report+='\n## Exact witness audit\n\nFull scan omitted on'+str(sum(x['scan_omitted'] for x in audit))+'/66 inputs:18 synthetic plus all six CTU IPv4 columns. Older real18 omit none. See audit.json.\n'
if (o/'control.json').exists():
 control=json.loads((o/'control.json').read_text());report+='\n## Separate Taxi payment control\n\n| Session | Mode | Same-function alias/v013 | Default/v013 | Reuse/v013 |\n|---|---|---:|---:|---:|\n'
 for x in control['records']:
  q=x['ratio_to_same_pair_baseline'];report+=f"| {x['session']} | {x['mode']} | {q['alias_v013']:.5f} | {q['v020_default']:.5f} | {q['W_reuse']:.5f} |\n"
 report+='\nAll288 control sorts pass. Separate binary, exact same baseline function pointer; not a causal explanation for another input or the main competition.\n'
(o/'report.md').write_text(report)
print('Wrote full report with all132 input/condition rows and separate lifetimes/groups')
