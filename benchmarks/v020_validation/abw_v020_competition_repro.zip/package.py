from pathlib import Path
import json,shutil,hashlib,zipfile
w=Path('work/abw_v020');o=Path('outputs/abw_v020_competition');r=Path('outputs/abw_v020_candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['analyze.py','report.py','replay.py','prepare.py','prepare_competition.py','run.py','benchmark.cpp','A.hpp','build.json','control.cpp','control_build.json','control_plan.json','control_run.py','audit.cpp','audit_build.json','checks.json','check.py','provenance.json','environment.json','gcc-ci.log','clang-ci.log','msvc-ci.log','package.py']:
 shutil.copyfile(w/name,o/name)
for compiler in ['gcc','clang']:shutil.copytree(w/('linux-'+compiler),o/('linux-'+compiler),dirs_exist_ok=True)
shutil.copytree(r/'include',o/'include',dirs_exist_ok=True)
shutil.copytree(r/'tests',o/'tests',dirs_exist_ok=True)
for name in ['LICENSE','THIRD_PARTY_NOTICES.md']:shutil.copyfile(r/name,o/name)
shutil.copyfile(r/'docs/workspace.md',o/'API.md')
(o/'reference').mkdir(exist_ok=True)
for src,dst in [('work/ABW_realworld/benchmark_manifest.json','original51_manifest.json'),('work/abw_new_real_v012/input_manifest.json','new9_manifest.json'),('work/abw_new_real_v012/sources.json','new9_sources.json'),('outputs/abw_ipv4_certificate/input_manifest.json','ipv4_manifest.json'),('outputs/abw_v013_first/protocol.json','prior60_manifest.json')]:shutil.copyfile(src,o/'reference'/dst)
(o/'vendor').mkdir(exist_ok=True)
for name in ['cafs.hpp','cafs2.hpp','cafs_LICENSE','cafs_README.md']:shutil.copyfile(Path('work/ABW_realworld/vendor')/name,o/'vendor'/name)
for folder,names in [('ABW_realworld',['download_data.py','extract_data.py','generate_synthetic.cjs']),('abw_new_real_v012',['download.py','prepare.py','sources.json']),('abw_ipv4_certificate',['fetch_extract.py'])]:
 d=o/'dataset_tools'/folder;d.mkdir(parents=True,exist_ok=True)
 for n in names:shutil.copyfile(Path('work')/folder/n,d/n)
checks=json.loads((w/'checks.json').read_text());assert all(x['returncode']==0 for x in checks)
validation=dict(candidate_commit='ce3ea678b1ca9515b8d807337a25fc1d6215dbe4',header_sha256=sha(r/'include/abw/abw.hpp'),ci_url='https://github.com/bumi0666/abw/actions/runs/43804878261',ci_jobs=[dict(id=i,compiler=c,conclusion='success') for i,c in [(133093240245,'GCC13.3 C++17'),(133093239803,'Clang18.1 C++17'),(133093239966,'MSVC19.51 C++17')]],local_checks=checks,linux_scope='Three generated1M forms on two hosted VMs; repeated calls, capacity stable, release; not full66 cross-CPU performance',timed_sorts=42816,processes=396,release=False)
(o/'validation.json').write_text(json.dumps(validation,indent=2))
(o/'REPRODUCE.md').write_text('''# Reproduction

The frozen sources, raw sessions, per-input CSV, analysis and CI diagnostics are
included. No previous raw experiment was modified. Protocol hashes every input,
expected array, source and measured executable. Results describe this exact
candidate, not an auto-updating main branch.

For Windows x64 LLVM-MinGW replay, put the66 unchanged input/expected pairs
in one flat directory. See reference manifests for filenames, hashes, source
URLs/licenses, exact extraction and eligibility. Original source downloads,
large input binaries, Boost headers and compiler are not in this small bundle.
dataset_tools preserves prior extraction/generation scripts; their original
work/... directory assumptions and numpy/pyarrow/Node dependencies remain.
CTU fetch_extract.py requires Windows curl for TLS and the original expected
work/abw_ipv4_certificate/inputs layout; it refuses overwriting extracted files.
Use a fresh extraction directory and verify hashes. The protocol's absolute
compiler paths document the measured machine; replay accepts explicit paths.

```
python replay.py --inputs C:/data/abw66 --boost C:/deps/boost_1_90_0 --cxx C:/llvm-mingw/bin/clang++.exe --out C:/results/abw66-replay
python report.py C:/results/abw66-replay
```

replay.py builds all methods with the recorded common C++20 options and runs
three sessions/two conditions, then analyzes them. It requires a new output
directory and refuses different input hashes. For the original published data,
`python analyze.py .` recomputes CSV/summary from the existing three JSONL files.
`python report.py .` regenerates the report from bundled results; pass a replay
directory instead of `.` to report new results.
The benchmark uses Windows affinity APIs. Portable Linux correctness and small
repeated-call diagnostics are built by the candidate's CMake/Actions instead.

For library correctness on any supported toolchain:
```
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DABW_BOOST_INCLUDE_DIR=/path/to/boost_1_90_0
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```
Run these from the candidate repository, not this evidence-only archive.
No timing value is a CI pass/fail gate. See API.md for workspace ownership and
memory lifetime; compare default/fresh/reused rows separately.
''')
manifest={str(p.relative_to(o)):sha(p) for p in o.rglob('*') if p.is_file() and p.name!='package_manifest.json'}
(o/'package_manifest.json').write_text(json.dumps(manifest,indent=2))
zip_path=Path('outputs/abw_v020_competition_repro.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for p in o.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(o))
print('Packaged',len(manifest)+1,'files',zip_path.stat().st_size,'bytes; SHA256',sha(zip_path))
