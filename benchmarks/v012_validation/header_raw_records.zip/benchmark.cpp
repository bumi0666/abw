#include <abw/abw.hpp>
#include "candidate.hpp"
#include <windows.h>
#include <chrono>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <random>
#include <stdexcept>
#include <string>
using V=std::vector<uint32_t>;using Fn=void(*)(V&);using Clock=std::chrono::steady_clock;
V load(const char*p){std::ifstream f(p,std::ios::ate|std::ios::binary);if(!f)throw std::runtime_error("load");auto n=f.tellg();if(n<0||n%4)throw std::runtime_error("size");V a(size_t(n)/4);f.seekg(0);f.read(reinterpret_cast<char*>(a.data()),n);if(!f)throw std::runtime_error("read");return a;}
__attribute__((noinline)) double run(Fn fn,const V&src,const V&expected,V&scratch){std::copy(src.begin(),src.end(),scratch.begin());auto t=Clock::now();fn(scratch);double ms=std::chrono::duration<double,std::milli>(Clock::now()-t).count();if(scratch!=expected)throw std::runtime_error("incorrect");return ms;}
int main(int argc,char**argv){try{if(argc!=4)throw std::runtime_error("input expected seed");DWORD_PTR p,s;if(!GetProcessAffinityMask(GetCurrentProcess(),&p,&s)||!SetProcessAffinityMask(GetCurrentProcess(),p&(~p+1)))throw std::runtime_error("affinity");auto a=load(argv[1]),e=load(argv[2]);V scratch(a.size());Fn funcs[]={&abw::sort,&candidate::sort,&abw::sort};if(funcs[0]!=funcs[2])throw std::runtime_error("control functions differ");auto original_address=scratch.data();auto d=abw::detail::choose(a);auto c=candidate::detail::choose(a);
 for(int kind=0;kind<3;kind++){V w(100000),sw(100000);std::mt19937 rr(183+kind);for(size_t j=0;j<w.size();j++)w[j]=kind==0?rr()%1024:kind==1?uint32_t(j):rr()%8;auto ex=w;std::sort(ex.begin(),ex.end());for(int m=0;m<3;m++)run(funcs[m],w,ex,sw);}for(int m=0;m<3;m++)run(funcs[m],a,e,scratch);
 std::mt19937 rng(unsigned(std::stoul(argv[3])));std::cout<<std::setprecision(15)<<"{\"verified\":true,\"same_control_fn\":true,\"scratch_mod4096\":"<<(uintptr_t(scratch.data())%4096)<<",\"A_fn\":"<<uintptr_t(funcs[0])<<",\"candidate_fn\":"<<uintptr_t(funcs[1])<<",\"A_route\":"<<int(d.selected)<<",\"A_bits\":"<<d.bits<<",\"A_shift\":"<<d.shift<<",\"candidate_route\":"<<int(c.selected)<<",\"candidate_bits\":"<<c.bits<<",\"candidate_shift\":"<<c.shift<<",\"runs\":[";bool first=true;
 for(int block=0;block<2;block++){int whichFirst=rng()%2;for(int k=0;k<2;k++){int pair=(whichFirst+k)%2;int other=pair==0?1:2;bool flip=(block%2)!=0;int order[4]={0,other,other,0};if(flip){order[0]=other;order[1]=0;order[2]=0;order[3]=other;}for(int pos=0;pos<4;pos++){int m=order[pos];double ms=run(funcs[m],a,e,scratch);if(scratch.data()!=original_address)throw std::runtime_error("scratch moved");if(!first)std::cout<<",";first=false;std::cout<<"{\"block\":"<<block<<",\"pair\":\""<<(pair==0?"candidate":"control")<<"\",\"position\":"<<pos<<",\"method\":\""<<(m==0?"A":m==1?"candidate":"A_alias")<<"\",\"ms\":"<<ms<<"}";}}}
 std::cout<<"]}";}catch(const std::exception&e){std::cerr<<e.what();return 1;}return 0;}
