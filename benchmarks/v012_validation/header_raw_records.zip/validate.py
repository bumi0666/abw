from pathlib import Path
import subprocess,json,hashlib,statistics,random,time
r=Path('outputs/abw'); w=Path('work/abw_v012');o=r/'benchmarks/v012_validation'
compiler=Path('work/F_toolchain/llvm-mingw-20261104-ucrt-x86_64/bin/clang++.exe').resolve()
boost=Path('work/F_vendor/boost_1_90_0').resolve()
flags=[str(compiler),'-std=c++17','-O3','-DNDEBUG','-static','-pthread','-I'+str((r/'include').resolve()),'-I'+str(boost)]
logs=[]
def call(args):
 p=subprocess.run(list(map(str,args)),capture_output=True,text=True,check=True);logs.append({'command':list(map(str,args)),'stdout':p.stdout,'stderr':p.stderr});return p.stdout
call(flags+[r/'tests/conformance.cpp','-o',w/'conformance.exe'])
cases=json.loads(Path('work/ABW_realworld/benchmark_manifest.json').read_text())['cases'];base=Path('work/ABW_realworld/inputs').resolve()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(base/(c['name']+ext))==c[key]
conf=call([(w/'conformance.exe').resolve()]+[base/(c['name']+'.bin') for c in cases]);print(conf,flush=True)
# Same fixed-buffer and common-callsite ABBA harness, now public header vs frozen candidate.
src=Path('work/abw_paired_check/benchmark.cpp').read_text().replace('block<8','block<2')
(w/'benchmark.cpp').write_text(src)
(w/'candidate.hpp').write_bytes(Path('work/abw_competition_v012/candidate.hpp').read_bytes())
call(flags+['-mavx2','-mbmi',w/'benchmark.cpp','-o',w/'benchmark.exe'])
rows=[]
with (o/'header_raw.jsonl').open('x') as f:
 for c in cases:
  result=json.loads(call([(w/'benchmark.exe').resolve(),base/(c['name']+'.bin'),base/(c['name']+'.expected.bin'),'12853']))
  assert result['verified'] and result['A_route']==result['candidate_route'] and result['A_bits']==result['candidate_bits'] and result['A_shift']==result['candidate_shift']
  q={'name':c['name'],'group':c['group'],'result':result};f.write(json.dumps(q)+'\n');f.flush();rows.append(q)
ratios=[]
for row in rows:
 v=row['result']['runs'];a=statistics.median(x['ms'] for x in v if x['pair']=='candidate' and x['method']=='A');b=statistics.median(x['ms'] for x in v if x['method']=='candidate');ratios.append({'name':row['name'],'group':row['group'],'public_ms':a,'candidate_ms':b,'ratio':a/b})
(o/'header_results.json').write_text(json.dumps(ratios,indent=2))
(o/'packaging_validation.json').write_text(json.dumps({'conformance':conf.strip(),'cases':51,'timed_calls':len(rows)*16,'source_equivalent_except_namespace_and_comment':True,'public_header_sha256':sha(r/'include/abw/abw.hpp'),'frozen_candidate_sha256':sha(w/'candidate.hpp'),'input_hashes_verified':True,'routes_bits_shifts_match':True,'logs':logs[:3]},indent=2))
for p in ['benchmark.cpp','validate.py']:(o/p).write_bytes((w/p).read_bytes())
print('PASS header correctness, all 51 routes and 816 packaging timings',flush=True)
