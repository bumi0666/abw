from pathlib import Path
import json,csv,hashlib,subprocess,random,shutil
r=Path('work/abw_paired_full');o=Path('outputs/abw_paired_full');o.mkdir(exist_ok=True);cases={c['name']:c for c in json.loads(Path('work/ABW_realworld/benchmark_manifest.json').read_text())['cases']};names=sorted(cases);base=Path('work/ABW_realworld/inputs').resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();proto=dict(previous_harness='already same binary/process Latin interleaving; this tightens pairing rather than newly introducing within-process comparison',selection='all original9 real+42 synthetic inputs, no exclusions; exact same executable/source as preceding13-input paired check',cases=[cases[n] for n in names],sessions=3,blocks=8,design='same fixed scratch buffer; ABBA/BAAB within each pair; same-function A/A_alias control; 64 timed calls/process',source_hashes={str(p):sha(p) for p in [r/'candidate.hpp',r/'benchmark.cpp',r/'benchmark.exe',Path('outputs/abw/include/abw/abw.hpp')]},build=json.loads((r/'build.json').read_text()))
(o/'protocol.json').write_text(json.dumps(proto,indent=2))
for n in names:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(base/(n+ext))==cases[n][key]
for session in range(3):
 jobs=names.copy();random.Random(8173+session).shuffle(jobs)
 with (o/f'session{session}.jsonl').open('x') as out:
  for n in jobs:
   p=subprocess.run([str((r/'benchmark.exe').resolve()),str(base/(n+'.bin')),str(base/(n+'.expected.bin')),str(912738+session)],capture_output=True,text=True,check=True);q=json.loads(p.stdout);assert q['verified'] and q['same_control_fn'] and len(q['runs'])==64;out.write(json.dumps(dict(name=n,session=session,result=q))+'\n');out.flush();print(session+1,n,flush=True)
assert all(sha(Path(p))==h for p,h in proto['source_hashes'].items())
for p in ['candidate.hpp','benchmark.cpp','build.json','run.py']:shutil.copyfile(r/p,o/p)

for n in names:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(base/(n+ext))==cases[n][key]
print('COMPLETE 9792 timed calls; source, binary and inputs unchanged',flush=True)
