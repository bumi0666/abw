from pathlib import Path
import json,csv,statistics as st,math,shutil
r=Path('outputs/abw_paired_full');raw=[json.loads(l) for f in r.glob('session[012].jsonl') for l in f.read_text().splitlines()];assert len(raw)==153
proto=json.loads((r/'protocol.json').read_text());cases={c['name']:c for c in proto['cases']};blocks=[];processes=[]
for x in raw:
 v=x['result'];q=dict(name=x['name'],group=cases[x['name']]['group'],n=cases[x['name']]['n'],session=x['session'],scratch_mod4096=v['scratch_mod4096'],baseline_route=v['A_route'],candidate_route=v['candidate_route'],baseline_bits=v['A_bits'],candidate_bits=v['candidate_bits'],baseline_shift=v['A_shift'],candidate_shift=v['candidate_shift'])
 for pair,other in [('candidate','candidate'),('control','A_alias')]:
  ratios=[];deltas=[];aa=[];bb=[]
  for b in range(8):
   z=[t for t in v['runs'] if t['block']==b and t['pair']==pair];a=st.mean(t['ms'] for t in z if t['method']=='A');c=st.mean(t['ms'] for t in z if t['method']==other);ratios.append(c/a);deltas.append(c-a);aa+= [t['ms'] for t in z if t['method']=='A'];bb+= [t['ms'] for t in z if t['method']==other];blocks.append(dict(name=x['name'],group=q['group'],n=q['n'],session=x['session'],pair=pair,block=b,A_ms=a,other_ms=c,ratio=c/a,delta_ms=c-a))
  q[pair+'_ratio']=st.median(ratios);q[pair+'_delta_ms']=st.median(deltas);q[pair+'_A_ms']=st.median(aa);q[pair+'_other_ms']=st.median(bb)
 processes.append(q)
summary=[]
for name in sorted(cases):
 ps=[x for x in processes if x['name']==name];assert len(ps)==3;d=ps[0];q={k:d[k] for k in ['name','group','n','baseline_route','candidate_route','baseline_bits','candidate_bits','baseline_shift','candidate_shift']};q['choice_changed']=q['baseline_route']!=q['candidate_route']
 for pair in ['candidate','control']:
  for field in ['ratio','delta_ms','A_ms','other_ms']:q[pair+'_'+field]=st.median(x[pair+'_'+field] for x in ps)
  q[pair+'_process_min']=min(x[pair+'_ratio'] for x in ps);q[pair+'_process_max']=max(x[pair+'_ratio'] for x in ps)
 q['all_three_over_5pct']=all(x['candidate_ratio']>1.05 for x in ps);summary.append(q)
for fn,data in [('block_pairs.csv',blocks),('process_summary.csv',processes),('input_results.csv',summary)]:
 with (r/fn).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
metrics={}
for label,s in [('real',[x for x in summary if x['group']=='real']),('synthetic',[x for x in summary if x['group']!='real']),('all',summary)]:
 worst=max(s,key=lambda x:x['candidate_ratio']);best=min(s,key=lambda x:x['candidate_ratio']);metrics[label]=dict(inputs=len(s),gm_candidate_over_v011=math.exp(st.mean(math.log(x['candidate_ratio']) for x in s)),gm_control=math.exp(st.mean(math.log(x['control_ratio']) for x in s)),worst=worst,best=dict(name=best['name'],ratio=best['candidate_ratio']),regressions_over_5pct=[x['name'] for x in s if x['candidate_ratio']>1.05],all_three_over_5pct=[x['name'] for x in s if x['all_three_over_5pct']])
print(json.dumps(metrics,indent=2))
print('FOCUS AND REGRESSIONS')
for x in summary:
 if x['name'] in ['census_industry','census_sex','covtype_cover','covtype_elevation','nasa_status','census_caseid'] or x['candidate_ratio']>1.03:print(x)
(r/'summary.json').write_text(json.dumps(metrics,indent=2))
text='''# Full51 paired release-candidate check

Date: 2026-11-13. The candidate, public v0.1.1 and paired benchmark executable are unchanged from the preceding 13-input check, verified byte-for-byte by SHA-256 before execution. The executable was copied, not rebuilt. Only the input list expands to all original nine real and 42 synthetic inputs. No tuning, new optimization, GitHub edit or release.

Measurement remains the exact same fixed-buffer, common noinline function-pointer call site, eight alternating ABBA/BAAB blocks for candidate comparison plus eight exact same-function A/A_alias control blocks in each process. Candidate/control block order is randomized. One original-value reset into the same scratch data pointer precedes every call, outside timing. Full-array comparison with unchanged expected files follows every call, outside timing. Sort-owned analysis, allocation, zeroing, merge, sort/output and free remain inside. Original warmup families and actual-input warmup retained. All control function pointers are identical and each scratch address is checked stable.

51 inputs x3 fresh processes x64 timed calls = **9,792 timed calls**, consisting of 4,896 candidate-comparison calls (2,448 candidate and 2,448 baseline) plus 4,896 identical-function control calls. These repeated calls are not 9,792 independent datasets. Input and expected hashes are checked before/after; source and binary hashes before/after. All calls pass exact output correctness. Same Intel i5-14500 Windows x64 first-permitted-CPU affinity; LLVM-MinGW Clang23.1.5, Boost1.90.0, C++20/O3/NDEBUG/AVX2/BMI/static/pthread. No memory profiling or offset sweeps.

Estimator: average the two candidate and two baseline times in each ABBA block, take their ratio, median eight block ratios per process, then median the three process ratios per input. Group geometric means use these input-level ratios. Times below are medians of process medians; time quotients may differ from paired ratios. No outlier filtering. Process min/max are descriptive ranges, not confidence intervals. The existing 5% descriptive column is a reporting label, not a requirement that every process must win. One performance CPU and one existing synthetic data seed remain limitations.

## Aggregates

```json\n'''+json.dumps(metrics,indent=2)+'\n```\n'
text+='\n## Every input\n\n| Input | v011 ms | Candidate ms | Candidate/v011 | Additional ms | Process ratio range | Exact control range | Routes A/C |\n|---|---:|---:|---:|---:|---|---|---|\n'
for x in summary:text+=f"| {x['name']} | {x['candidate_A_ms']:.4f} | {x['candidate_other_ms']:.4f} | {x['candidate_ratio']:.4f} | {x['candidate_delta_ms']:+.4f} | {x['candidate_process_min']:.4f}..{x['candidate_process_max']:.4f} | {x['control_process_min']:.4f}..{x['control_process_max']:.4f} | {x['baseline_route']}/{x['candidate_route']} |\n"
text+='\nRoutes:0=native,1=skip,2=active8,3=active12. Raw session0..2.jsonl retains all times/addresses; block_pairs.csv, process_summary.csv and input_results.csv provide every aggregation level. No measurement from earlier runs is substituted or pooled.\n'
(r/'report.md').write_text(text,encoding='utf8');shutil.copyfile('work/abw_paired_full/analyze.py',r/'analyze.py')
