from pathlib import Path
import json,statistics as st,csv
r=Path('outputs/abw_paired_check');raw=[json.loads(l) for f in r.glob('session[1234567890]*.jsonl') for l in f.read_text().splitlines()];assert len(raw)==39
blocks=[];procs=[]
for x in raw:
 v=x['result'];q=dict(name=x['name'],session=x['session'],scratch_mod4096=v['scratch_mod4096'])
 for pair,other in [('candidate','candidate'),('control','A_alias')]:
  ratios=[]
  for b in range(8):
   z=[t for t in v['runs'] if t['block']==b and t['pair']==pair];a=st.mean(t['ms'] for t in z if t['method']=='A');c=st.mean(t['ms'] for t in z if t['method']==other);ratio=c/a;ratios.append(ratio);blocks.append(dict(name=x['name'],session=x['session'],pair=pair,block=b,A_ms=a,other_ms=c,ratio=ratio))
  q[pair+'_ratio']=st.median(ratios);q[pair+'_min']=min(ratios);q[pair+'_max']=max(ratios)
 procs.append(q)
for fn,data in [('block_pairs.csv',blocks),('process_summary.csv',procs)]:
 with (r/fn).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
for name in sorted({x['name'] for x in procs}):
 z=[x for x in procs if x['name']==name];print(name,'candidate',[round(x['candidate_ratio'],4) for x in z],'control',[round(x['control_ratio'],4) for x in z],'buffer',[x['scratch_mod4096'] for x in z])
