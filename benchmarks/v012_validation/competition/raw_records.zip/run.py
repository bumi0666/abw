from pathlib import Path
import json,hashlib,random,subprocess,shutil
r=Path('work/abw_competition_v012');o=Path('outputs/abw_competition_v012');o.mkdir(exist_ok=True);base=Path('work/ABW_realworld/inputs').resolve();cases=json.loads(Path('work/ABW_realworld/benchmark_manifest.json').read_text())['cases'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for c in cases:
 c['methods']=['candidate','v011','pdq','spread','CAFS_u32']+(['CAFS_i32'] if c['cafs_i32_eligible'] else [])+(['counting'] if c['counting_eligible'] else [])
proto=dict(objective='Current candidate competitive position, no implementation or policy changes',cases=cases,sessions=3,blocks_per_competitor=4,measurement='same fixed unsigned scratch buffer for all u32 sorts; separate fixed exact-value signed buffer for supported CAFS_i32, conversion outside timing; common noinline templated function-pointer timer; candidate/competitor ABBA then BAAB, randomized pair order; all calls full equality checked',timing_scope='input restore/loading/warmup/conversion/checks excluded; sort-owned initialization, allocation, all analysis, output/free included',counting='unchanged uint64 dense histogram including runtime min/max; prior64MiB cap retained',eligibility='CAFS_i32 only exact nonnegative representable values, no remapping; Counting only prior range cap; no excluded case counted as loss/win',source_hashes={str(p):sha(p) for p in [r/'candidate.hpp',r/'benchmark.cpp',r/'benchmark.exe',Path('outputs/abw/include/abw/abw.hpp'),Path('work/ABW_realworld/vendor/cafs.hpp'),Path('work/ABW_realworld/vendor/cafs2.hpp')]},build=json.loads((r/'build.json').read_text()),environment='same Intel i5-14500 Windows x64 first-allowed CPU, LLVM-MinGW Clang23.1.5/libc++/UCRT, Boost1.90.0, C++20 O3 NDEBUG AVX2 BMI static pthread',prior_results='not pooled with this run; no timing acceptance cutoff and no outlier filtering')
(o/'protocol.json').write_text(json.dumps(proto,indent=2))
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(base/(c['name']+ext))==c[key]
print('input hashes verified; timed calls',sum((len(c['methods'])-1)*16*3 for c in cases),flush=True)
for session in range(3):
 jobs=cases.copy();random.Random(471293+session).shuffle(jobs)
 with (o/f'session{session}.jsonl').open('x') as f:
  for j,c in enumerate(jobs):
   p=subprocess.run([str((r/'benchmark.exe').resolve()),str(base/(c['name']+'.bin')),str(base/(c['name']+'.expected.bin')),str(813572+session),str(int(c['cafs_i32_eligible'])),str(int(c['counting_eligible']))],capture_output=True,text=True,check=True);v=json.loads(p.stdout);assert v['verified'] and len(v['runs'])==(len(c['methods'])-1)*16;f.write(json.dumps(dict(name=c['name'],group=c['group'],n=c['n'],session=session,result=v))+'\n');f.flush();print(session+1,j+1,'/51',c['name'],flush=True)
assert all(sha(Path(p))==h for p,h in proto['source_hashes'].items())
for c in cases:
 for ext,key in [('.bin','sha256'),('.expected.bin','expected_sha256')]:assert sha(base/(c['name']+ext))==c[key]
for name in ['candidate.hpp','benchmark.cpp','build.json','run.py']:shutil.copyfile(r/name,o/name)
print('COMPLETE; sources and inputs preserved',flush=True)
