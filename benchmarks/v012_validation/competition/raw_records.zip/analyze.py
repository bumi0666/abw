from pathlib import Path
import json,csv,statistics as st,math,shutil
r=Path('outputs/abw_competition_v012');proto=json.loads((r/'protocol.json').read_text());cases={x['name']:x for x in proto['cases']};raw=[json.loads(l) for f in r.glob('session[012].jsonl') for l in f.read_text().splitlines()];assert len(raw)==153
methods=['candidate','v011','pdq','spread','CAFS_u32','CAFS_i32','counting'];sessions=[];pairs=[];med={};pr={}
for x in raw:
 for m in cases[x['name']]['methods']:
  ts=[z['ms'] for z in x['result']['runs'] if z['method']==m];t=st.median(ts);med[(x['name'],x['session'],m)]=t;sessions.append(dict(name=x['name'],group=x['group'],n=x['n'],session=x['session'],method=m,ms=t))
 for m in cases[x['name']]['methods'][1:]:
  ratios=[]
  for b in range(4):
   z=[v for v in x['result']['runs'] if v['pair']==m and v['block']==b];c=st.mean(v['ms'] for v in z if v['method']=='candidate');o=st.mean(v['ms'] for v in z if v['method']==m);ratios.append(o/c);pairs.append(dict(name=x['name'],session=x['session'],method=m,block=b,candidate_ms=c,other_ms=o,speedup=o/c))
  pr[(x['name'],x['session'],m)]=st.median(ratios)
summary=[]
for name,c in cases.items():
 q=dict(name=name,group=c['group'],n=c['n']);src=next(x['result'] for x in raw if x['name']==name);q['baseline_route']=src['baseline_route'];q['candidate_route']=src['candidate_route'];q['candidate_bits']=src['candidate_bits'];q['candidate_shift']=src['candidate_shift']
 for m in c['methods']:
  q[m]=st.median(med[(name,s,m)] for s in range(3));q[m+'_speedup_pdq']=st.median(med[(name,s,'pdq')]/med[(name,s,m)] for s in range(3))
  q['candidate_over_'+m]=st.median(med[(name,s,'candidate')]/med[(name,s,m)] for s in range(3));q['v011_over_'+m]=st.median(med[(name,s,'v011')]/med[(name,s,m)] for s in range(3))
  if m!='candidate':q['paired_speedup_vs_'+m]=st.median(pr[(name,s,m)] for s in range(3))
 q['winner']=min(c['methods'],key=lambda m:q[m]);q['candidate_clear_best']=all(q['candidate_over_'+m]<.95 for m in c['methods'] if m!='candidate');q['candidate_close_to_best']=q['candidate']/q[q['winner']]<=1.05;summary.append(q)
for filename,data in [('session_medians.csv',sessions),('paired_blocks.csv',pairs),('input_results.csv',summary)]:
 keys=list(dict.fromkeys(k for x in data for k in x))
 with (r/filename).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(data)
metrics={}
for label,subset in [('real',[x for x in summary if x['group']=='real']),('synthetic',[x for x in summary if x['group']!='real']),('all',summary)]:
 q={}
 for m in methods:
  s=[x for x in subset if m in x];q[m]=dict(eligible=len(s),gm_speedup_pdq=math.exp(st.mean(math.log(x[m+'_speedup_pdq']) for x in s)))
 q['candidate_winners']=[x['name'] for x in subset if x['winner']=='candidate'];q['candidate_clear_best']=[x['name'] for x in subset if x['candidate_clear_best']];q['candidate_near_best']=[x['name'] for x in subset if x['candidate_close_to_best']]
 for m in ['v011','pdq','spread','CAFS_u32','CAFS_i32','counting']:
  s=[x for x in subset if m in x];q['candidate_vs_'+m]=dict(n=len(s),gm_time_ratio=math.exp(st.mean(math.log(x['candidate_over_'+m]) for x in s)),baseline_gm_time_ratio=math.exp(st.mean(math.log(x['v011_over_'+m]) for x in s)),wins=sum(x['candidate_over_'+m]<.95 for x in s),ties=sum(.95<=x['candidate_over_'+m]<=1.05 for x in s),losses=sum(x['candidate_over_'+m]>1.05 for x in s),paired_gm_speedup=math.exp(st.mean(math.log(x['paired_speedup_vs_'+m]) for x in s)))
 for m in ['v011','pdq','spread','CAFS_u32','CAFS_i32','counting']:
  s=[x for x in subset if m in x];w=max(s,key=lambda x:x['candidate_over_'+m]);q['worst_vs_'+m]=dict(name=w['name'],ratio=w['candidate_over_'+m],candidate_ms=w['candidate'],other_ms=w[m])
 metrics[label]=q
(r/'summary.json').write_text(json.dumps(metrics,indent=2))
print('REAL METRICS',json.dumps(metrics['real'],indent=2));print('SYNTH GM',[(m,metrics['synthetic'][m]) for m in methods]);print('ALL candidate/v011',metrics['all']['candidate_vs_v011'])
for x in summary:
 if x['group']=='real':print(x['name'],[(m,round(x[m],4)) for m in cases[x['name']]['methods']],x['winner'])
text='''# ABW v0.1.2 candidate competitive comparison

Date: 2026-11-13. Current candidate is byte-identical to the full51 paired candidate. Public v0.1.1, Boost pdqsort/Spreadsort, CAFS and Counting implementations are unchanged. No optimization, policy adjustment, GitHub edit or release. Results are not pooled with historical measurements.

## Conditions

Existing nine real columns and42 synthetic files, original values/order/expected arrays and SHA-256 before/after. Same Intel i5-14500 Windows x64 first-allowed-CPU affinity; LLVM-MinGW Clang23.1.5/libc++/UCRT, Boost1.90.0, C++20/O3/NDEBUG/AVX2/BMI/static/pthread for all methods in one binary. CAFS pinned official commit13488afef446ae88e7ad631ec6f862def896094a and sources retain recorded hashes. Both supported scalar uint32 and specialized int32 APIs use the unchanged public pdqsort fallback. Counting is the unchanged uint64 dense histogram with runtime min/max inside timer, eligible only under the prior64MiB counter budget.

One fixed u32 scratch vector is shared by all u32 methods; values are restored before each timed call outside timing. CAFS_i32 uses a separate fixed int32 vector with exactly the same representable nonnegative values, converted outside timer; no reinterpret aliasing or value compression. Unsupported i32/range cases are omitted and denominators shown. One common noinline templated function-pointer timer; actual sort-owned analysis, allocations, initialization/merge/output/free inside timer; input load/restore/conversion, warmup and full output check outside. Scratch pointers are checked stable. One actual-input warmup per eligible method plus the original three100k warmup families.

Each competitor is paired against candidate in ABBA/BAAB blocks, with four blocks per competitor, pair order randomized each block; three fresh processes per input. Every call compares the complete output with the existing expected array. All51 source/input hashes rechecked. No outlier filtering. One CPU; process sessions are not independent hardware/dataset seeds. This experiment measures runtime, not a new memory/RSS profile.

'''
text+=f"Timed sorts: **{sum(len(x['result']['runs']) for x in raw)}** in153 processes. Repetition counts vary only with declared competitor eligibility.\n\n"
text+='''Primary tables use per-method median call time in each process, then median of three process medians per input. pdq speedups and competitor time ratios use median of paired same-process method-median ratios, followed by geometric mean across eligible inputs. Candidate appears in multiple anchored pairs; its median pools its calls within that process. The independent block-paired ratios are also retained in paired_blocks.csv/summary.json as a robustness view; those estimates need not numerically equal ratios of medians. No estimator is substituted after seeing results.

The raw-time winner is the smallest displayed input median. Clear-best requires candidate's input-level time ratio below0.95 against every eligible competitor; 'near best' is a descriptive5% band, not statistical significance. Unsupported methods are not counted as wins/losses. Comparisons involving CAFS_i32 or Counting over synthetic data use only6 and9 of42 cases respectively; these subset geometric means must not be treated as42-input totals.

## Geometric mean speedup relative to pdqsort

| Method | Real9 | Synthetic eligible subset | N synthetic |\n|---|---:|---:|---:|\n'''
for m in methods:text+=f"| {m} | {metrics['real'][m]['gm_speedup_pdq']:.4f} | {metrics['synthetic'][m]['gm_speedup_pdq']:.4f} | {metrics['synthetic'][m]['eligible']} |\n"
text+='\n## All real-column times (ms)\n\n| Input | Candidate | v0.1.1 | pdq | Spread | CAFS u32 | CAFS i32 | Counting | Lowest median |\n|---|---:|---:|---:|---:|---:|---:|---:|---|\n'
for x in summary:
 if x['group']=='real':text+='| '+x['name']+' | '+' | '.join(f"{x[m]:.4f}" for m in methods)+' | '+x['winner']+' |\n'
text+='\n## Every input, including synthetic regressions\n\n| Input | Candidate | v0.1.1 | pdq | Spread | CAFS u32 | CAFS i32 | Counting | Lowest median |\n|---|---:|---:|---:|---:|---:|---:|---:|---|\n'
for x in summary:text+='| '+x['name']+' | '+' | '.join(f"{x[m]:.4f}" if m in x else 'unsupported / budget' for m in methods)+' | '+x['winner']+' |\n'
text+='\n## Competitive aggregates and all losses\n\n```json\n'+json.dumps(metrics,indent=2)+'\n```\n'
text+='\nFull input-level time ratios, pdq speedups and paired block comparisons are in CSV/JSON. Raw session records preserve every measured call, with no exclusions beyond type/range eligibility. A primary time-ratio>1 means candidate is slower; pdq speedup>1 means the method is faster than pdq. Per-column ratios and group means may differ from displayed-time quotients. No production workload weighting or multi-CPU generality is implied.\n'
(r/'report.md').write_text(text,encoding='utf8');shutil.copyfile('work/abw_competition_v012/analyze.py',r/'analyze.py')
